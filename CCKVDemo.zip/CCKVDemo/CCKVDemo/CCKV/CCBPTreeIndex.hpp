//
//  CCBPTreeIndex.hpp
//  CCKVDemo
//
//  Created by yuan on 2020/2/19.
//  Copyright © 2020 yuan. All rights reserved.
//

#ifndef CCBPTreeIndex_hpp
#define CCBPTreeIndex_hpp

#include <stdio.h>
#include <string>
#include "CCType.h"
//#include "CCFileMap.hpp"

typedef CCUByte_t CCIndex_T;
//索引的长度,为0-255个字节
typedef CCUByte_t CCIndexSize_T;
//索引的value，必须是uint64_t
typedef CCUInt64_t CCIndexValue_T;

using namespace std;

class CCBPTreeIndex {
private:
    void *_ptrRBTreeIndexContext;
public:
    CCBPTreeIndex(const string &indexFile);
    
    CCBPTreeIndex(const string &indexFile, CCIndexSize_T indexLen);
    
    CCBPTreeIndex(const string &indexFile, CCUInt16_t pageNodeCount, CCIndexSize_T indexLen);
    
    virtual ~CCBPTreeIndex();
    
    //查
    int selectIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T *indexValue);
    //增
    int insertIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue);
    //删
    int deleteIndex(CCIndex_T *index, CCIndexSize_T indexLen);
    //改
    int updateIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue);
};

#endif /* CCBPTreeIndex_hpp */
