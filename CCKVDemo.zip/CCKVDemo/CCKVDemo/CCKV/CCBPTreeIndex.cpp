//
//  CCBPTreeIndex.cpp
//  CCKVDemo
//
//  Created by yuan on 2020/2/19.
//  Copyright © 2020 yuan. All rights reserved.
//

#include "CCBPTreeIndex.hpp"
#include "CCBuffer.h"
#include "CCMutableBuffer.h"
#include "CCFileMap.hpp"
#include "CCMacro.h"
#include "CCBase.h"
#include "CCArray.h"
#include "CCHashTable.h"
#include "CCDictionary.h"

//存储索引长度所占用的字节数(1字节)能表示索引长度为0-255
#define CCPAGE_NODE_IDX_SIZE_BYTES      (1)
#define CCPAGE_NODE_IDX_VALUE_BYTES     (8)
#define CCPAGE_OFFSET_BYTES             (8) //uint64_t 为8字节
#define CCPAGE_NODE_SIZE(PNODE)         ((PNODE)->indexSize + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES)
#define CCPAGE_NODE_OFFSET(PNODE)       ((PNODE)->indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES)
#define CCPAGE_NODE_END_OFFSET(PNODE)   ((PNODE)->indexOffset + (PNODE)->indexSize + CCPAGE_NODE_IDX_VALUE_BYTES)

#define CCPAGE_DEC_BUFFER(OFF,BF,BFType)    CCBuffer *BF = ctx->rootBuffer; \
                                            CCBufferType BFType = CCBufferTypeRoot; \
                                            if (OFF != ctx->rootOffset) { \
                                                CCMapBufferNode *MBN = NULL;\
                                                CCHashTableGetValueOfKeyIfPresent(ctx->bufferCache, (CCU64Ptr)OFF, (CCU64Ptr*)(&MBN));\
                                                if (MBN && MBN->buffer) { \
                                                    ++MBN->refCnt;\
                                                    BF = MBN->buffer; \
                                                    BFType = MBN->bufferType; \
                                                } \
                                                else { \
                                                    if (MBN == NULL) { \
                                                        MBN = (CCMapBufferNode *)calloc(1, sizeof(CCMapBufferNode)); \
                                                        CCHashTableSetValue(ctx->bufferCache, (CCU64Ptr)OFF, (CCU64Ptr)MBN);\
                                                    } \
                                                    BF = ctx->fileMap->createMapBuffer(OFF, ctx->pageSize, CC_F_RDWR); \
                                                    if (BF) BFType = CCBufferTypeCRT; \
                                                    MBN->refCnt = 1;\
                                                    MBN->buffer = BF;\
                                                    MBN->bufferType = BFType; \
                                                } \
                                            }

//这里为了避免重复的calloc MapBufferNode，在refCnt== 0时可以不释放，只是destroy buffer，
#define CCPAGE_FRE_BUFFER(OFF,RM)           if (OFF != ctx->rootOffset) { \
                                                CCMapBufferNode *MBN = NULL;\
                                                CCHashTableGetValueOfKeyIfPresent(ctx->bufferCache, (CCU64Ptr)OFF, (CCU64Ptr*)(&MBN));\
                                                if (MBN) { \
                                                    if (MBN->refCnt > 0) --MBN->refCnt;\
                                                    if (MBN->refCnt == 0) { \
                                                        ctx->fileMap->destroyMapBuffer(MBN->buffer); \
                                                        MBN->buffer = NULL;\
                                                        MBN->bufferType = CCBufferTypeNull;\
                                                        if (RM) CCHashTableRemoveValue(ctx->bufferCache, (CCU64Ptr)OFF); \
                                                    } \
                                                } \
                                            }

#define CCPAGE_SIZE_FROM_FLAG(FLAG)     (1 << (FLAG & 31))
#define CCPAGE_IS_LEAF(PAGE)            ((PAGE->pageType & CCPageTypeLeaf) == CCPageTypeLeaf)

#define CCPAGE_NODE_AT_IDX(PAGE,IDX)    ((CCPageNode*)CCArrayGetValueAtIndex(PAGE->pageNodeArray, IDX))
#define CCPAGE_SUB_AT_IDX(PAGE,IDX)      (((CCSubPage*)CCArrayGetValueAtIndex(PAGE->subPageArray, IDX)))

#define CCPAGE_NODE_FIRST(PAGE)         ((CCPageNode*)CCArrayGetFirstValue(PAGE->pageNodeArray))
#define CCPAGE_NODE_LAST(PAGE)          ((CCPageNode*)CCArrayGetLastValue(PAGE->pageNodeArray))

#define CCPAGE_SUB_FIRST(PAGE)         ((CCSubPage*)CCArrayGetFirstValue(PAGE->subPageArray))
#define CCPAGE_SUB_LAST(PAGE)          ((CCSubPage*)CCArrayGetLastValue(PAGE->subPageArray))


#define CCPAGE_CNT(PAGE)                CCArrayGetCount(PAGE->subPageArray)
#define CCNODE_CNT(PAGE)                CCArrayGetCount(PAGE->pageNodeArray)
#define IS_ROOT_OFF(OFF)                (OFF == ctx->rootOffset)
#define IS_ROOT_PAGE(PAGE)              IS_ROOT_OFF(PAGE->pageOffset)

//#define CCPage_Default_SIZE                 (16384)//16KB

static int16_t _CCBPTreeIndexHeaderLen_s    = 256;

//索引的长度,返回为0-255个字节
//typedef uint8_t CCIndexSize_T;
//page的size
typedef uint32_t CCPageSize_T;
//page的个数，最多由2^16-1个物理page页组成一个虚拟的page
typedef uint16_t CCPageCount_T;
//page中所含有的所有的node个数，最大为2^16-2
typedef uint16_t CCNodeCount_T;
//page相对整个文件的偏移量
typedef uint64_t CCPageOffset_T;
//索引的value，必须是uint64_t
//typedef uint64_t CCIndexValue_T;

static CCNodeCount_T _CCNodeListStepCnt_s = 128;
static CCPageCount_T _CCSubPageListStepCnt_s = 1;

typedef enum CCBufferType
{
    CCBufferTypeNull    = 0,
    //rootbuffer,不需要delete和destroy
    CCBufferTypeRoot    = (1 << 0),
//    //需要delete
//    CCBufferTypeNew     = (1 << 1),
    //需要detroy
    CCBufferTypeCRT     = (1 << 1),
//    //共享buffer
//    CCBufferTypeShared  = (1 << 3),
}CCBufferType_E;

typedef enum CCFindCode
{
    //查找错误
    CCFindCodeError     = -1,
    //查找OK
    CCFindCodeOK        = 0,
    //已经存在
    CCFindCodeExists    = 1,
}CCFindCode_E;

typedef enum CCHeaderOff
{
    CCHeaderOffVersion          = 0,
    CCHeaderOffPageNodeCnt      = 2,
    CCHeaderOffFlag             = 4,
    CCHeaderOffRootOffset       = 5,
    CCHeaderOffContentSize      = 13,
    CCHeaderOffFreePageOffset   = 21,
    CCHeaderOffEnd              = 29,
}CCHeaderOff_E;

typedef enum CCPageHeaderOff
{
    //next的offset(8)
    CCPageHeaderOffNext     = 0,
    //parent的offset(8),保留
    CCPageHeaderOffParent   = CCPageHeaderOffNext + CCPAGE_OFFSET_BYTES,
    //firstChild的offset(8)
    CCPageHeaderOffFChild   = CCPageHeaderOffParent + CCPAGE_OFFSET_BYTES,
    //brother的offset(8)
    CCPageHeaderOffBrother  = CCPageHeaderOffFChild + CCPAGE_OFFSET_BYTES,
    //copy-on-write next
//    CCPageHeaderOffCowNext  = CCPageHeaderOffBrother + CCPAGE_OFFSET_BYTES,
//    //copy-on-write prev
//    CCPageHeaderOffCowPrev  = CCPageHeaderOffCowNext + CCPAGE_OFFSET_BYTES,
//    //copy-on-write parent
//    CCPageHeaderOffCowParent = CCPageHeaderOffCowPrev + CCPAGE_OFFSET_BYTES,
//    //copy-on-write slotIdx
//    CCPageHeaderOffCowSlotIdx = CCPageHeaderOffCowParent + 2,
    //pageType的offset(1)
    CCPageHeaderOffPType    = CCPageHeaderOffBrother + CCPAGE_OFFSET_BYTES,
    //索引的offset
    CCPageHeaderOffIndex    = CCPageHeaderOffPType + sizeof(CCIndexSize_T),
}CCPageHeaderOff_E;

typedef enum CCPageType{
    CCPageTypeNone  = 0,
    CCPageTypeLeaf  = 1 << 0,
    CCPageTypeRoot  = 1 << 1,
    CCPageTypeIndex = 1 << 2,
    //copy-on-write
    CCPageTypeCow   = 1 << 3,
    //copy-on-write remote
    CCPageTypeCowR  = 1 << 4,
}CCPageType_E;

//struct CCPage;

typedef struct CCMapBufferNode {
    CCBuffer *buffer;
    CCCount refCnt;
    CCBufferType bufferType;
}CCMapBufferNode_S;

typedef struct CCPageNode {
    CCPageSize_T indexOffset;
    CCIndexSize_T indexSize;
    //如果是叶子节点，value的值就是存储的data，否则就是孩子节点的位置
    CCIndexValue_T value;
}CCPageNode_S;

typedef struct CCSubPage
{
    CCNodeCount_T sIdx;
    CCNodeCount_T eIdx;
    CCPageSize_T remSize;
    CCPageOffset_T offset;
}CCSubPage_S;

typedef struct CCPathNode {
    CCPageOffset_T offset;
    CCNodeCount_T parentSlotIdx;
    struct CCPathNode *parent;
}CCPathNode_S;

/*page的header
 *|---8字节(next,8字节(pageOffset))---|
 *|---8字节(parent,8字节(pageOffset))---|
 *|---8字节(firstChild,8字节(pageOffset))---|
 *|---8字节(brother,8字节(pageOffset))---|
 *|---1字节(pageType)---|
 *|---剩余是索引---|
*/
typedef struct CCPage{
    CCPageType_E pageType;
    //这个nodeCnt是总数
//    CCNodeCount_T nodeCnt;
    //这个pageCnt是指含有多少个物理页
//    CCPageCount_T pageCnt;
    //subPageList的大小
//    CCPageCount_T subPageListSize;
    //pageNodeList的大小
//    CCNodeCount_T pageNodeListSize;
    //在父类中的idx
    CCNodeCount_T parentNodeSlotIdx;
    //当前page的offset
    CCPageOffset_T pageOffset;
    //父page，保留
    CCPageOffset_T parent;
    //兄弟page
    CCPageOffset_T brother;
    //第一个孩子page
    CCPageOffset_T firstChild;
    
//    struct CCPage *ptr_parent;
    struct CCPathNode *pNode;
    
    //所有的pageNode的数组
//    struct CCPageNode *pageNodeList;
    PCCArray_S pageNodeArray;
    //所有的subPage的数据
    PCCArray_S subPageArray;
//    struct CCSubPage *subPageList;
}CCPage_S;

typedef struct CCPageFind {
    //nodeIdx为-1表示已经存在这个索引
    CCFindCode_E fcd;
    CCNodeCount_T nodeIdx;
    CCPageCount_T subPageIdx;
    CCIndexValue_T value;
    struct CCPage *page;
}CCPageFind_S;


/*B+树索引的header
*|---2字节(version)---|---2字节(pageNodeCnt)---|---1字节flag(其中最低5表示组成的值表示pageSize的2^exp,如是16，那么pageSize=2^16=32KB,高3位组成的值表示B+树有多少+1层，如果值是5，表示有6层，最大可以表示8层)---|
*|---8字节(rootOffset的位置)---|---8字节(contentSize)---|---8字节(freePageOffset的位置)---|
*
*/
typedef struct CCBPTreeIndexContext
{
    uint16_t version;
    CCNodeCount_T pageNodeCnt;
    CCPageSize_T pageSize;
//    uint8_t level;
    uint8_t flag;
//    bool destroyRootBuffer;
    CCPageOffset_T rootOffset;
    CCPageOffset_T contentSize;
    CCPageOffset_T freePageOffset;
    CCFileMap *fileMap;
    struct CCPage *root;
//    struct CCPage *current;
    CCBuffer *headBuffer;
    CCBuffer *rootBuffer;
    PCCDictionary bufferCache;
}CCBPTreeIndexContext_S, *PCCBPTreeIndexContext_S;

static inline CCCount expandArrayCapacity(PCCArray_S array, CCCount curCnt, CCCount addCnt, CCCount maxCnt) {
    CCCount cap = array ? CCArrayGetCapacity(array) : 0;
    CCCount featureCnt = cap;
    if (curCnt >= cap) {
        featureCnt = curCnt + addCnt;
    }
    return MIN(featureCnt, maxCnt);
}

static inline void arrayValueRelease(void *target, CCU64Ptr value) {
    void *ft = (void*)value;
    if (ft) {
        free(ft);
    }
}

static inline PCCArray_S createArray(CCCount capacity, void *isa)
{
    CCArrayContext ctx;
    ctx.retain = NULL;
    ctx.release = arrayValueRelease;
    ctx.equal = NULL;
    CCArrayOption_U option;
    option.option = 0;
    PCCArray_S array = CCArrayCreate(NULL, NULL, 0, &ctx, option);
    CCArraySetCapacity(array, capacity);
    CCBase *base = (CCBase*)array;
    base->isa = isa;
    return array;
}

//static inline void destroyArray(PCCArray_S array) {
//    CCArrayDeallocate(array);
//}

static inline void resizePageNodeArray(CCBPTreeIndexContext_S *ctx, CCPage_S *page, bool shrink)
{
    if (page->pageNodeArray) {
        PCCArray_S array = page->pageNodeArray;
        CCCount curCnt = CCArrayGetCount(array);
        CCCount capacity = CCArrayGetCapacity(array);
        CCNodeCount_T featureCnt = expandArrayCapacity(array, curCnt, _CCNodeListStepCnt_s, ctx->pageNodeCnt);
        if ((shrink && featureCnt < capacity) || featureCnt > capacity) {
            CCArraySetCapacity(array, featureCnt);
        }
    }
    else {
        page->pageNodeArray = createArray(_CCNodeListStepCnt_s, ctx);
    }
}

static inline void resizeSubPageArray(CCBPTreeIndexContext_S *ctx, CCPage_S *page, bool shrink)
{
    if (page->subPageArray) {
        PCCArray_S array = page->subPageArray;
        CCCount curCnt = CCArrayGetCount(array);
        CCCount capacity = CCArrayGetCapacity(array);
        CCPageCount_T featureCnt = expandArrayCapacity(array, curCnt, _CCSubPageListStepCnt_s, CCCountMax);
        if ((shrink && featureCnt < capacity) || featureCnt > capacity) {
            CCArraySetCapacity(array, featureCnt);
        }
    }
    else {
        page->subPageArray = createArray(_CCSubPageListStepCnt_s, ctx);
    }
}

static inline bool bufferCacheKeyEqual(void *target, CCU64Ptr value1, CCU64Ptr value2) {
    return value1 == value2;
}

static inline CCHashCode bufferCacheKeyhash(void *target, CCU64Ptr key) {
    return key;
}

static inline void bufferCacheValueRelease(void *target, CCU64Ptr value) {
    CCBase *base = (CCBase*)target;
    CCBPTreeIndexContext_S *ctx = (CCBPTreeIndexContext_S *)base->isa;
    CCMapBufferNode *mapBufferNode = (CCMapBufferNode*)value;
    if (mapBufferNode) {
        if (mapBufferNode->buffer) {
            ctx->fileMap->destroyMapBuffer(mapBufferNode->buffer);
        }
        free(mapBufferNode);
    }
}

static inline void createBufferCache(CCBPTreeIndexContext_S *ctx, CCCount capacity) {
    struct CCDictionaryKeyFunc keyFunc = {NULL, NULL, bufferCacheKeyEqual, bufferCacheKeyhash};
    struct CCDictionaryValueFunc valueFunc = {NULL, bufferCacheValueRelease, NULL};
    ctx->bufferCache = CCDictionaryCreate(NULL, NULL, NULL, 0, &keyFunc, &valueFunc, CCHashTableStyleLinear);
    if (ctx->bufferCache) {
        CCBase *base = (CCBase*)ctx->bufferCache;
        base->isa = ctx;
        CCHashTableSetCapacity(ctx->bufferCache, capacity);
    }
}

static inline void destroyBufferCache(CCBPTreeIndexContext_S *ctx) {
    if (ctx->bufferCache) {
        CCDictionaryDeallocate(ctx->bufferCache);
        ctx->bufferCache = nil;
    }
}

static void readNextPage(CCBPTreeIndexContext_S *ctx, CCPage_S *page, CCNodeCount_T fromIdx, CCPageOffset_T next)
{
    if (next <= 0) {
        return;
    }
    CCPageSize_T pageSize = ctx->pageSize;
    
    CCPAGE_DEC_BUFFER(next, buffer, bufferType);
    buffer->seekTo(CCPageHeaderOffNext);
    CCPageOffset_T nextTmp = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffIndex);
    CCPageSize_T cur = (CCPageSize_T)buffer->currentSeek();
    CCPageSize_T rem = pageSize - cur;
    PCCArray_S pageNodeArray = page->pageNodeArray;
    while (rem > 0) {
        CCIndexSize_T size = buffer->readByte();
        if (size == 0) {
            break;
        }
        
        CCPageNode_S *node = (CCPageNode_S*)calloc(1, sizeof(CCPageNode_S));
        if (!node) {
            break;
        }
        
        node->indexSize = size;
        CCPageSize_T offset = (CCPageSize_T)buffer->currentSeek();
        node->indexOffset = offset;
        buffer->seekTo(offset + size);
        node->value = buffer->readLittleEndian64();
        rem = pageSize - (CCPageSize_T)buffer->currentSeek();
        
        if (CCArrayGetCount(pageNodeArray) >= CCArrayGetCapacity(pageNodeArray)) {
            resizePageNodeArray(ctx, page, false);
        }
        else {
            CCArrayAppendValue(pageNodeArray, (CCU64Ptr)node);
        }

    }
    CCPAGE_FRE_BUFFER(next, false);
    
    CCSubPage_S *subPage = (CCSubPage_S*)calloc(1, sizeof(CCSubPage_S));
    if (!subPage) {
        return;
    }
    CCNodeCount_T nodeCnt = CCArrayGetCount(page->pageNodeArray);
    subPage->sIdx = fromIdx;
    subPage->eIdx = nodeCnt > 0 ? nodeCnt - 1 : 0;
    subPage->remSize = rem;
    subPage->offset = next;
    
    resizeSubPageArray(ctx, page, false);
    
    CCArrayAppendValue(page->subPageArray, (CCU64Ptr)subPage);

    if (nextTmp > 0) {
        readNextPage(ctx, page, nodeCnt, nextTmp);
    }
}

static void readPageNode(CCBPTreeIndexContext_S *ctx, CCPage_S *page, CCBuffer *buffer, CCPageOffset_T next)
{
    resizePageNodeArray(ctx, page, false);
    CCPageSize_T rem = (CCPageSize_T)buffer->remSize();
    PCCArray_S pageNodeArray = page->pageNodeArray;
    while (rem > 0) {
        CCIndexSize_T size = buffer->readByte();
        if (size == 0) {
            break;
        }
        
        CCPageNode_S *node = (CCPageNode_S*)calloc(1, sizeof(CCPageNode_S));
        if (!node) {
            break;
        }
        
        node->indexSize = size;
        CCPageSize_T offset = (CCPageSize_T)buffer->currentSeek();
        node->indexOffset = offset;
        buffer->seekTo(offset + size);
        node->value = buffer->readLittleEndian64();
        rem = (CCPageSize_T)buffer->remSize();
        
        if (CCArrayGetCount(pageNodeArray) >= CCArrayGetCapacity(pageNodeArray)) {
            resizePageNodeArray(ctx, page, false);
        }
        else {
            CCArrayAppendValue(pageNodeArray, (CCU64Ptr)node);
        }
    }

    CCSubPage_S *subPage = (CCSubPage_S*)calloc(1, sizeof(CCSubPage_S));
    if (!subPage) {
        return;
    }
    CCNodeCount_T nodeCnt = CCArrayGetCount(pageNodeArray);
    subPage->sIdx = 0;
    subPage->eIdx = nodeCnt > 0 ? nodeCnt - 1 : 0;
    subPage->remSize = rem;
    subPage->offset = page->pageOffset;
    
    resizeSubPageArray(ctx, page, false);
    
    CCArrayAppendValue(page->subPageArray, (CCU64Ptr)subPage);

    if (next > 0) {
        readNextPage(ctx, page, (CCNodeCount_T)nodeCnt, next);
    }
}

static CCPage_S *readPage(CCBPTreeIndexContext_S *ctx, CCPageOffset_T offset, bool readNode)
{
    CCPage_S *page = (CCPage_S *)calloc(1, sizeof(CCPage_S));;
    if (page == NULL) {
        return NULL;
    }
    CCPAGE_DEC_BUFFER(offset, buffer, bufferType);

    page->pageOffset = offset;
    buffer->seekTo(CCPageHeaderOffNext);
    CCPageOffset_T next = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffParent);
    page->parent = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffFChild);
    page->firstChild = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffBrother);
    page->brother = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffPType);
    page->pageType = (CCPageType_E)buffer->readByte();
    if (readNode) {
        buffer->seekTo(CCPageHeaderOffIndex);
        readPageNode(ctx, page, buffer, next);
    }
    CCPAGE_FRE_BUFFER(offset, false);
    
    return page;
}

void freePagePathNode(CCPathNode_S *pNode) {
    if (pNode) {
        freePagePathNode(pNode->parent);
        pNode->parent = NULL;
        free(pNode);
    }
}

void freePage(CCBPTreeIndexContext_S *ctx, CCPage_S *page, BOOL root)
{
    if (IS_ROOT_PAGE(page) && root == false) {
        return;
    }
    if (page && page->pageNodeArray) {
        CCArrayDeallocate(page->pageNodeArray);
        page->pageNodeArray = NULL;
    }
    if (page && page->subPageArray) {
        CCArrayDeallocate(page->subPageArray);
        page->subPageArray = NULL;
    }
    
    if (page) {
        freePagePathNode(page->pNode);
        free(page);
    }
}

static void readRootPage(CCBPTreeIndexContext_S *ctx)
{
    CCPageOffset_T rootOffset = ctx->rootOffset;
    if (ctx->rootBuffer == NULL) {
        CCPageSize_T pageSize = ctx->pageSize;
        ctx->rootBuffer = ctx->fileMap->createMapBuffer(rootOffset, pageSize, CC_F_RDWR);
        if (ctx->rootBuffer == nullptr) {
            return;
        }
    }
    ctx->root = readPage(ctx, rootOffset, true);
}

static PCCBPTreeIndexContext_S CCBPTreeIndexContextCreate(PCCAllocator_S allocator, const string &indexFile, CCPageCount_T pageNodeCnt, CCPageSize_T pageSize)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S *)calloc(1, sizeof(CCBPTreeIndexContext_S));
    CCFileMap *fileMap = new CCFileMap(indexFile);
    ctx->fileMap = fileMap;
    fileMap->open(CC_F_RDWR);
    
    int64_t fileSize = ctx->fileMap->fileSize();
    CCPageSize_T headerLen = MAX(_CCBPTreeIndexHeaderLen_s,pageSize);
    
    CCBuffer *header = fileMap->createMapBuffer(0, headerLen, CC_F_RDWR);
    if (header == nullptr) {
        return nullptr;
    }
    ctx->headBuffer = header;
    
    if (fileSize > 0) {
        ctx->version = header->readLittleEndian16();
        ctx->pageNodeCnt = header->readLittleEndian16();
        uint8_t flag = header->readByte();
        ctx->flag = flag;
        ctx->pageSize = CCPAGE_SIZE_FROM_FLAG(flag);
        ctx->rootOffset = header->readLittleEndian64();
        ctx->contentSize = header->readLittleEndian64();
        ctx->freePageOffset = header->readLittleEndian64();
    }
    else {
        CCPageSize_T pageSize = (CCPageSize_T)header->bufferSize();
        uint8_t flag = TYPEUINT_BITS_N(pageSize);
        ctx->version = 1.0;
        ctx->pageNodeCnt = pageNodeCnt;
        ctx->flag = flag;
        ctx->pageSize = CCPAGE_SIZE_FROM_FLAG(flag);
        ctx->rootOffset = header->bufferSize();
        ctx->contentSize = header->bufferSize();
        ctx->freePageOffset = 0;
        
        header->seekTo(CCHeaderOffVersion);
        header->writeLittleEndian16(ctx->version);
        header->seekTo(CCHeaderOffPageNodeCnt);
        header->writeLittleEndian16(ctx->pageNodeCnt);
        header->seekTo(CCHeaderOffFlag);
        header->writeByte(ctx->flag);
        header->seekTo(CCHeaderOffRootOffset);
        header->writeLittleEndian64(ctx->rootOffset);
        header->seekTo(CCHeaderOffContentSize);
        header->writeLittleEndian64(ctx->contentSize);
        header->seekTo(CCHeaderOffFreePageOffset);
        header->writeLittleEndian64(ctx->freePageOffset);
    }
    
    createBufferCache(ctx, 4);
    
    readRootPage(ctx);
    
    return ctx;
}

static CCPageFind_S lookupPage(CCBPTreeIndexContext_S *ctx, CCPathNode_S *pNode, CCPageOffset_T offset, CCIndex_T *index, CCIndexSize_T indexLen, bool leaf)
{
    CCPage_S *page = nullptr;
    if (offset == 0 || IS_ROOT_OFF(offset)) {
        page = ctx->root;
    }
    if (!page) {
        page = readPage(ctx, offset, true);
    }
    page->pNode = pNode;
    CCPageFind f;
    f.page = page;
    f.nodeIdx = 0;
    PCCArray_S pageNodeArray = page->pageNodeArray;
    CCCount nodeCnt = CCArrayGetCount(pageNodeArray);
    if (nodeCnt == 0) {
        return f;
    }
    
    PCCArray_S subPageArray = page->subPageArray;
    CCCount subPageCnt = CCArrayGetCount(subPageArray);
    
    CCPageCount_T ps = 0;
    CCPageCount_T pe = subPageCnt-1;
    while (ps <= pe) {
        CCPageCount_T pIdx = (ps + pe)/2;
        CCSubPage *subPage = (CCSubPage*)CCArrayGetValueAtIndex(subPageArray, pIdx);;
        const CCPageOffset_T offset = subPage->offset;
        
        CCPAGE_DEC_BUFFER(offset, buffer, bufferType);
        uint8_t *ptr = buffer->bytes();
        
        CCPageNode_S *ns = (CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, subPage->sIdx);
        int r = memcmp(index, ptr + ns->indexOffset, MIN(indexLen, ns->indexSize));
        
        //index < ns->index
        if (r < 0 || (r == 0 && indexLen < ns->indexSize)) {
            pe = pIdx - 1;
        }
        //index == ns->index
        else if (r == 0 && indexLen == ns->indexSize) {
            f.fcd = CCFindCodeExists;
            f.nodeIdx = subPage->sIdx;
            f.subPageIdx = pIdx;
            CCPAGE_FRE_BUFFER(offset, false);
            break;
        }
        //index > ns->index
        else {
            CCPageNode_S *ne = (CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, subPage->eIdx);
            r = memcmp(index, ptr + ne->indexOffset, MIN(indexLen, ne->indexSize));
            if (r < 0 || (r == 0 && indexLen < ns->indexSize)) {
                //就在此page中寻找
                f.subPageIdx = pIdx;
                CCNodeCount_T i = subPage->sIdx;
                CCNodeCount_T j = subPage->eIdx;
                while (i <= j) {
                    CCNodeCount_T m = (i + j)/2;
                    CCPageNode *t = (CCPageNode*)CCArrayGetValueAtIndex(pageNodeArray, m);
                    r = memcmp(index, ptr + t->indexOffset, MIN(indexLen, t->indexSize));
                    if (r < 0 || (r == 0 && indexLen < t->indexSize)) {
                        j = m - 1;
                    }
                    else if (r == 0 && indexLen == t->indexSize) {
                        f.fcd = CCFindCodeExists;
                        f.nodeIdx = m;
                        break;
                    }
                    else {
                        i = m + 1;
                    }
                    //当i>=j时break
                    if (i >= j) {
                        if (i == j) {
                            ++i;
                        }
                        f.fcd = CCFindCodeOK;
                        f.nodeIdx = i;
                        break;
                    }
                }
                CCPAGE_FRE_BUFFER(offset, false);
                break;
            }
            else if (r == 0 && indexLen == ne->indexSize) {
                f.fcd = CCFindCodeExists;
                f.nodeIdx = subPage->eIdx;
                f.subPageIdx = pIdx;
                CCPAGE_FRE_BUFFER(offset, false);
                break;
            }
            else {
                ps = pIdx + 1;
            }
            //当ps>=pe时break
            if (ps >= pe) {
                if (ps == pe) {
                    ++ps;
                }
                f.fcd = CCFindCodeOK;
                f.nodeIdx = ((CCSubPage_S*)CCArrayGetValueAtIndex(subPageArray, ps))->sIdx;
                f.subPageIdx = ps;
                CCPAGE_FRE_BUFFER(offset, false);
                break;
            }
        }
        CCPAGE_FRE_BUFFER(offset, false);
    }
    
    CCPageOffset_T nextPageOffset = 0;
    CCNodeCount_T slotIdx = 0;
    if (f.fcd == CCFindCodeOK) {
        if (f.nodeIdx >= 1) {
            slotIdx = f.nodeIdx;
            nextPageOffset = ((CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, f.nodeIdx-1))->value;
        }
        else {
            slotIdx = 0;
            nextPageOffset = page->firstChild;
        }
    }
    else {
        slotIdx = f.nodeIdx;
        nextPageOffset = ((CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, f.nodeIdx))->value;
    }
    f.value = nextPageOffset;
    
    if (leaf && nextPageOffset > 0 && (page->pageType & CCPageTypeLeaf) != CCPageTypeLeaf) {
        struct CCPathNode *pInfoTmp = (CCPathNode_S*)malloc(sizeof(CCPathNode_S));
        if (pInfoTmp) {
            pInfoTmp->offset = page->pageOffset;
            pInfoTmp->parentSlotIdx = slotIdx;
            pInfoTmp->parent = pNode;
            return lookupPage(ctx, pInfoTmp, nextPageOffset, index, indexLen, leaf);
        }
    }
    return f;
}

static inline CCPageOffset_T createNewPageOffset(CCBPTreeIndexContext_S *ctx)
{
    if (ctx->freePageOffset > 0) {
        const CCPageOffset_T freePageOffset = ctx->freePageOffset;
        CCPAGE_DEC_BUFFER(freePageOffset, buffer, bufferType);
        buffer->seekTo(CCPageHeaderOffNext);
        CCPageOffset_T next = buffer->readLittleEndian64();
        memset(buffer->bytes(), 0, ctx->pageSize);
        CCPAGE_FRE_BUFFER(freePageOffset, false);
        
        ctx->freePageOffset = next;
        ctx->headBuffer->seekTo(CCHeaderOffFreePageOffset);
        ctx->headBuffer->writeLittleEndian64(ctx->freePageOffset);
        return freePageOffset;
    }
    CCPageOffset_T newPageOffset = ctx->contentSize;
    ctx->contentSize += ctx->pageSize;
    ctx->headBuffer->seekTo(CCHeaderOffContentSize);
    ctx->headBuffer->writeLittleEndian64(ctx->contentSize);
    return newPageOffset;
}

static inline void addFreePageOffset(CCBPTreeIndexContext_S *ctx, CCPageOffset_T freeOffset)
{
    if (freeOffset <= 0) {
        return;
    }
    //将freeOffset 设置在上一个freepage的前面
    CCPAGE_DEC_BUFFER(freeOffset, buffer, bufferType);
    CCPageOffset_T prevFreePageOffset = ctx->freePageOffset;
    buffer->seekTo(CCPageHeaderOffNext);
    buffer->writeLittleEndian64(prevFreePageOffset);
    CCPAGE_FRE_BUFFER(freeOffset, false);
    ctx->freePageOffset = freeOffset;
    ctx->headBuffer->seekTo(CCHeaderOffFreePageOffset);
    ctx->headBuffer->writeLittleEndian64(freeOffset);
}

static inline CCPageCount_T getPageIdxFromNodeIdx(CCBPTreeIndexContext_S *ctx, CCPage *page, CCNodeCount_T nodeIdx)
{
    CCPageCount_T pageIdx = 0;
    CCPageCount_T pageCnt = CCPAGE_CNT(page);
    if (pageCnt == 1) {
        return 0;
    }
    for (pageIdx = 0; pageIdx < pageCnt; ++pageIdx) {
        CCSubPage *sub = CCPAGE_SUB_AT_IDX(page, pageIdx);
        if (nodeIdx >= sub->sIdx && nodeIdx <= sub->eIdx) {
            return pageIdx;
        }
    }
    return pageIdx;
}

//这个函数不能保证subPage的remSize一定>=needSize，如果不满足的话，nextSubPage的前面一定存在needSize的空间
static inline bool ensureSubPageRemSize(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCPageSize_T needSize, CCNodeCount_T maxMoveIdx, CCPageSize_T newPagePrevFreeSize)
{
    CCPageSize_T pageSize = ctx->pageSize;
    CCSubPage *sub = CCPAGE_SUB_AT_IDX(page, subPageIdx);
    const CCPageOffset_T subOffset = sub->offset;
    //1.判断本sub是否有足够的剩余空间
    if (sub->remSize >= needSize) {
        return true;
    }
    CCPageCount_T endIdx = sub->eIdx;
    //2.计算需要从后面copy几个index，value出去
    CCPageSize_T cpSize = 0;
    CCPageSize_T addSize = 0;
    CCNodeCount_T copyItemCnt = 0;
    CCPageSize_T remSize = sub->remSize;
    
    //3.计算需要copy的size
    while (remSize < needSize && endIdx >= maxMoveIdx) {
        CCPageNode *pageNode = CCPAGE_NODE_AT_IDX(page, endIdx);
        addSize = CCPAGE_NODE_SIZE(pageNode);
        cpSize += addSize;
        remSize += addSize;
        --endIdx;
        ++copyItemCnt;
    }
    
    CCPageNode *endNode = CCPAGE_NODE_AT_IDX(page, endIdx + 1);
    CCPageSize_T copyFrom = CCPAGE_NODE_OFFSET(endNode);
    CCPageSize_T newSize = cpSize;
    CCPageSize_T nextSubIndexOffset = CCPageHeaderOffIndex;
    //如果此subPage还是不足needSize，则将下一个subPage前面预留needSize的大小
    if (remSize < needSize) {
        newSize = cpSize + needSize;
        nextSubIndexOffset += needSize;
    }
    
    bool result = false;
    bool createNewPage = true;
    CCPageOffset_T nextOffset = 0;
    CCPageCount_T nextSubPageIdx = subPageIdx + 1;
    CCPageCount_T pageCnt = CCPAGE_CNT(page);
    CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
    /*如果下一个subPage不是最后一个page，并且有newSize的剩余空间，
     *直接将前面的subPage从后面拷贝过来，不创建新的subPage
     */
    if (nextSubPageIdx < pageCnt) {
        CCSubPage *nextSub = CCPAGE_SUB_AT_IDX(page, nextSubPageIdx);
        CCPageSize_T nextSubPageRemSize = nextSub->remSize;
        if (nextSubPageRemSize > newSize) {
            createNewPage = false;
            const CCPageOffset_T nextSubOffset = nextSub->offset;
            CCPAGE_DEC_BUFFER(nextSubOffset, nextBuffer, nextBufferType);
            uint8_t *ptr = nextBuffer->bytes() + CCPageHeaderOffIndex;
            memmove(ptr + newSize, ptr, pageSize - nextSub->remSize - CCPageHeaderOffIndex);
            memset(ptr, 0, newSize);
            nextBuffer->seekTo(nextSubIndexOffset);
            nextBuffer->writeBuffer(buffer->bytes() + copyFrom, cpSize);
            memset(buffer->bytes() + copyFrom, 0, cpSize);
            CCPAGE_FRE_BUFFER(nextSubOffset, false);
            nextSub->remSize -= newSize;
            nextSub->sIdx -= copyItemCnt;
        }
        else {
            //需要创建一个新的subPage
            nextOffset = nextSub->offset;
        }
    }
    sub->eIdx = endIdx;
    sub->remSize = remSize;
    
    if (createNewPage) {
        const CCPageOffset_T nextNewPageOffset = createNewPageOffset(ctx);
        //修改当前subPage的next
        buffer->seekTo(CCPageHeaderOffNext);
        buffer->writeLittleEndian64(nextNewPageOffset);
        
        //更改新的subPage的next
        CCPAGE_DEC_BUFFER(nextNewPageOffset, nextBuffer, nextBufferType);
        
        nextBuffer->seekTo(CCPageHeaderOffNext);
        nextBuffer->writeLittleEndian64(nextOffset);
        nextBuffer->seekTo(nextSubIndexOffset);
        nextBuffer->writeBuffer(buffer->bytes() + copyFrom, cpSize);
        memset(buffer->bytes() + copyFrom, 0, cpSize);
        CCPAGE_FRE_BUFFER(nextNewPageOffset, false);
        
        resizeSubPageArray(ctx, page, false);
        CCSubPage *subPage = (CCSubPage*)calloc(1, sizeof(CCSubPage));
        if (!subPage) {
            goto  ENSURE_SUBPAGE_REMSIZE_END;
        }
        subPage->sIdx = endIdx + 1;
        subPage->eIdx = endIdx + copyItemCnt;
        subPage->remSize = pageSize - newSize - CCPageHeaderOffIndex;
        subPage->offset = nextNewPageOffset;
        CCArrayInsertValueAtIndex(page->subPageArray, nextSubPageIdx, (CCU64Ptr)subPage);
    }

    result = true;
ENSURE_SUBPAGE_REMSIZE_END:
    CCPAGE_FRE_BUFFER(subOffset, false);
    return result;
}

static void insertIndexIntoNotFullPage(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCNodeCount_T nodeIdx, CCIndexValue_T prevIndexValue, CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    CCNodeCount_T pageNodeCnt = CCNODE_CNT(page);
    if (pageNodeCnt >= ctx->pageNodeCnt) {
        return;
    }
    
    CCSubPage *sub = CCPAGE_SUB_AT_IDX(page, subPageIdx);
    CCNodeCount_T endIdx = sub->eIdx;
    CCPageOffset_T offset = sub->offset;
    CCPageSize_T needSize = indexLen + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES;
    
    //确保本subPage有足够的剩余空间，如果不足，取下一个subPage
    ensureSubPageRemSize(ctx, page, subPageIdx, needSize, nodeIdx, needSize);
    bool remSizeEnough = true;
    if (sub->remSize < needSize) {
        remSizeEnough = false;
        offset = CCPAGE_SUB_AT_IDX(page, subPageIdx + 1)->offset;
    }
    
    CCPAGE_DEC_BUFFER(offset, buffer, bufType);
    
    //如果是rootPage，并且pageType== CCPageTypeNone，修改为CCPageTypeRoot | CCPageTypeLeaf
    if (IS_ROOT_OFF(offset) && ctx->root->pageType == CCPageTypeNone) {
        ctx->root->pageType = (CCPageType_E)(CCPageTypeRoot | CCPageTypeLeaf);
        buffer->seekTo(CCPageHeaderOffPType);
        buffer->writeByte(ctx->root->pageType);
    }
    
    /*（在进行分裂时，向上产生了一个新的page，此时prevIndexValue就是有值的）
    * 如果前面的indexValue有值，此prevIndexValue就是firstChild
     */
    if (prevIndexValue > 0 && nodeIdx == 0) {
        /*如果向上分裂的page存在node的时候，而插入的indexValue是为0，说明新插入的indexValue就是本page的firstChild
         */
        if (indexValue == 0) {
            indexValue = page->firstChild;
        }
        page->firstChild = prevIndexValue;
        buffer->seekTo(CCPageHeaderOffFChild);
        buffer->writeLittleEndian64(prevIndexValue);
    }
    
    CCPageSize_T endOff = 0;
    if (remSizeEnough) {
        endIdx = sub->eIdx;
        endOff = endIdx == 0 ? CCPageHeaderOffIndex : CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, endIdx));
        if (endIdx >= nodeIdx && endIdx > 0) {
            CCPageSize_T offsetTmp = CCPAGE_NODE_OFFSET(CCPAGE_NODE_AT_IDX(page, nodeIdx));
            uint8_t *ptr = buffer->bytes() + offsetTmp;
            CCPageSize_T move = endOff - offsetTmp;
            memmove(ptr + needSize, ptr, move);
            buffer->seekTo(offsetTmp);
        }
        else {
            buffer->seekTo(endOff);
        }
        
        buffer->writeByte(indexLen);
        buffer->writeBuffer(index, indexLen);
        buffer->writeLittleEndian64(indexValue);
    }
    else {
        endOff = CCPageHeaderOffIndex;
        buffer->seekTo(CCPageHeaderOffIndex);
        buffer->writeByte(indexLen);
        buffer->writeBuffer(index, indexLen);
        buffer->writeLittleEndian64(indexValue);
    }

    CCPAGE_FRE_BUFFER(offset, false);
    if (page == ctx->root) {
        CCPageNode *insert = (CCPageNode*)calloc(1, sizeof(CCPageNode));
        if (!insert) {
            return;
        }
        insert->indexOffset = endOff;
        insert->indexSize = indexLen;
        insert->value = indexValue;
        CCArrayInsertValueAtIndex(page->pageNodeArray, nodeIdx, (CCU64Ptr)insert);
    }
}

static int insertIndexWithPathNode(CCBPTreeIndexContext_S *ctx, CCPathNode_S *pathNode, CCIndexValue_T prevIndexValue, CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    CCPage_S *page = NULL;
    CCNodeCount_T nodeCnt = 0;
    CCNodeCount_T findNodeIdx = 0;
    CCPageCount_T findSubPageIdx = 0;
    PCCArray_S pageNodeArray = NULL;
    if (pathNode) {
        struct CCPageFind find = lookupPage(ctx, NULL, pathNode->offset, index, indexLen, false);
        if (find.fcd == CCFindCodeExists) {
            return find.fcd;
        }
        if (find.page == NULL) {
            return -1;
        }
        page = find.page;
        pageNodeArray = page->pageNodeArray;
        nodeCnt = CCArrayGetCount(pageNodeArray);
        findNodeIdx = find.nodeIdx;
        findSubPageIdx = find.subPageIdx;
    }
    else {
        page = ctx->root;
    }

    if (nodeCnt < ctx->pageNodeCnt) {
        insertIndexIntoNotFullPage(ctx, page, findSubPageIdx, findNodeIdx, prevIndexValue, index, indexLen, indexValue);
        freePage(ctx, page, false);
    }
    else {
        //进行分裂
        CCPageCount_T pageCnt = CCPAGE_CNT(page);
        PCCArray_S subPageArray = page->subPageArray;
        bool isLeafPage = (page->pageType & CCPageTypeLeaf) == CCPageTypeLeaf;
        CCNodeCount_T mid = ctx->pageNodeCnt >> 1;
        CCNodeCount_T prevCnt = mid;
        CCNodeCount_T insertIntoParentIdx = prevCnt;
        bool copyFromPrev = false;
        bool isInsertPrev = false;
        //1.找出分裂的位置
        /*
         *如果是奇数个，偶数个时进行分裂
         *1、如果是叶子节点分裂的话，两边各一半，将左边最大的index copy到父节点
         *2、如果是索引节点分裂，左边pageNodeCnt/2-1，右边pageNodeCnt/2，将左边最大的index移动到父节点
         */
        if (IS_ODD_NUM(ctx->pageNodeCnt)) {
            if (findNodeIdx < mid) {
                isInsertPrev = true;
            }
            else {
                prevCnt += 1;
            }
            insertIntoParentIdx = prevCnt - 1;
            copyFromPrev = true;
        }
        else {
            /*
             *如果是偶数个，奇数时进行分裂
             *1、如果是叶子节点分裂的话，左边pageNodeCnt/2，右边是ctx->pageNodeCnt - pageNodeCnt/2,将右边的最小索引copy到父节点
             *2、如果是索引节点分裂的话，左右两边都是pageNodeCnt/2，将中间的节点移动到父节点中
             */
            if (findNodeIdx < mid) {
                prevCnt -= 1;
                isInsertPrev = true;
            }
            insertIntoParentIdx = prevCnt;
        }
        
        //2. 计算父类的offset
        CCPageOffset_T parent = 0;
        bool newParentOffset = false;
        if (pathNode->parent) {
            parent = pathNode->parent->offset;
        }
        if (parent == 0) {
            newParentOffset = true;
            parent = createNewPageOffset(ctx);
        }

        //3. 修改当前的page
        const CCPageOffset_T curPageOffset = page->pageOffset;
        CCPAGE_DEC_BUFFER(curPageOffset, buffer, bufferType);

        //3.1修改pageType
        //如果pageType就是root，那就是修改为index
        if (page->pageType == CCPageTypeRoot) {
            page->pageType = CCPageTypeIndex;
            buffer->seekTo(CCPageHeaderOffPType);
            buffer->writeByte(page->pageType);
        }
        //如果pageType包含root，那么这个page就即使root也是leaf(叶子)，那么就将该page修改leaf page
        else if (page->pageType & CCPageTypeRoot) {
            page->pageType = CCPageTypeLeaf;
            buffer->seekTo(CCPageHeaderOffPType);
            buffer->writeByte(page->pageType);
        }
        
        //3.2修改page的brother
        bool newBrotherOffset = false;
        CCPageOffset_T brother = 0;
        //兄弟节点的next
        CCPageOffset_T brotherNextOffset = 0;
        //取prevCnt（要分裂出去的）所在的pageIdx
        CCPageCount_T nextSubPageIdx = getPageIdxFromNodeIdx(ctx, page, prevCnt);
        CCSubPage *split = CCPAGE_SUB_AT_IDX(page,nextSubPageIdx);
        if (split->sIdx == prevCnt) {
            brother = split->offset;
        }
        else {
            newBrotherOffset = true;
            brother = createNewPageOffset(ctx);
            CCPageCount_T nextSubPageIdxTmp = nextSubPageIdx + 1;
            if (nextSubPageIdxTmp < CCPAGE_CNT(page)) {
                brotherNextOffset = CCPAGE_SUB_AT_IDX(page, nextSubPageIdxTmp)->offset;
            }
        }
        //如果是B*树，都有brother
        if (isLeafPage) {
            buffer->seekTo(CCPageHeaderOffBrother);
            buffer->writeLittleEndian64(brother);
        }
        
        //3.3修改page的next为0
        CCPageOffset_T prevOffsetTmp = 0;
        CCSubPage *prevSubPage = NULL;
        /*如果是新建brother，则split就是第一个subPage
         *否则prevSubPageIdx就是第一个subPage
         */
        if (newBrotherOffset) {
            prevOffsetTmp = split->offset;
            prevSubPage = split;
        }
        else {
            CCPageCount_T prevSubPageIdx = 0;
            //在这里,这个nextSubPageIdx肯定会大于0
            if (nextSubPageIdx >= 1) {
                prevSubPageIdx = nextSubPageIdx - 1;
            }
            else {
                printf("error\n");
            }
            CCSubPage *prev = CCPAGE_SUB_AT_IDX(page, prevSubPageIdx);
            prevOffsetTmp = prev->offset;
            prevSubPage = prev;
        }

        //创建prevBuffer，将prevPage的最后一个subPage的next设置为0；
        const CCPageOffset_T prevSubOffset = prevOffsetTmp;
        CCPAGE_DEC_BUFFER(prevSubOffset, prevBuffer, prevBufferType);

        prevBuffer->seekTo(CCPageHeaderOffNext);
        prevBuffer->writeLittleEndian64(0);
        
        //4.修改brother的page
        //索引节点第一个孩子节点
        const CCPageOffset_T brotherOffset = brother;
        CCPageOffset_T brotherFirstChild = indexValue;
        CCPAGE_DEC_BUFFER(brotherOffset, brotherBuffer, brotherBufferType);
        
        //4.1 copy 需要插入到parent的index，value
        bool useCurIndex = false;
        CCPageSize_T insertIntoParentIndexSize = 0;
        if (insertIntoParentIdx == findNodeIdx) {
            useCurIndex = true;
            insertIntoParentIndexSize = indexLen;
        }
        else {
            insertIntoParentIndexSize = CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx)->indexSize;
        }
        insertIntoParentIndexSize += CCPAGE_NODE_IDX_VALUE_BYTES;
        CCMutableBuffer insertIntoParentIndex = CCMutableBuffer(insertIntoParentIndexSize);
        if (useCurIndex) {
            insertIntoParentIndex.writeBuffer(index, indexLen);
            insertIntoParentIndex.writeLittleEndian64(indexValue);
        }
        else {
            uint8_t *ptr = prevBuffer->bytes() + CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx)->indexOffset;
            insertIntoParentIndex.writeBuffer(ptr, insertIntoParentIdx);
            if (!isLeafPage) {
                memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, insertIntoParentIndexSize + CCPAGE_NODE_IDX_SIZE_BYTES);
            }
            CCPageOffset_T off = insertIntoParentIndexSize - CCPAGE_NODE_IDX_VALUE_BYTES;
            insertIntoParentIndex.seekTo(off);
            brotherFirstChild = insertIntoParentIndex.readLittleEndian64();
            //修改插入到parentPage的索引value为brother
            insertIntoParentIndex.seekTo(off);
            insertIntoParentIndex.writeLittleEndian64(brother);
        }
        if (isLeafPage == false) {
            brotherBuffer->seekTo(CCPageHeaderOffFChild);
            brotherBuffer->writeLittleEndian64(brotherFirstChild);
        }
        brotherBuffer->seekTo(CCPageHeaderOffBrother);
        brotherBuffer->writeLittleEndian64(page->brother);
        brotherBuffer->seekTo(CCPageHeaderOffPType);
        brotherBuffer->writeByte(page->pageType);
        page->brother = brother;
        
        if (newBrotherOffset) {
            //4.1 计算需要copy到insertIntoParentIndex的数据
            CCPageCount_T cpIdx = prevCnt;
            if (useCurIndex == false && !isLeafPage) {
                cpIdx = prevCnt + 1;
            }
            
            brotherBuffer->bzero();
            brotherBuffer->seekTo(CCPageHeaderOffNext);
            brotherBuffer->writeLittleEndian64(brotherNextOffset);
            
            //判断是否有数据需要copy到brotherBuffer
            if (cpIdx <= prevSubPage->eIdx) {
                CCPageSize_T sOff = CCPAGE_NODE_OFFSET(CCPAGE_NODE_AT_IDX(page, cpIdx));
                CCPageSize_T eOff = CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, split->eIdx));
                if (eOff > sOff) {
                    CCPageSize_T cp = eOff - sOff;
                    uint8_t *ptr = prevBuffer->bytes() + sOff;
                    brotherBuffer->seekTo(CCPageHeaderOffIndex);
                    brotherBuffer->writeBuffer(ptr, cp);
                    memset(ptr, 0, cp);
                }
            }
        }
        else {
            //如果不是新的brother，那就是原来的split的subPage
            if (useCurIndex == false && !isLeafPage && !copyFromPrev && insertIntoParentIdx < split->eIdx) {
                //将后面的往前面移动
                uint8_t *ptr = brotherBuffer->bytes() + CCPageHeaderOffIndex;
                CCPageSize_T cpSize = CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, split->eIdx)) - CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx));
                memmove(ptr, ptr + insertIntoParentIndexSize, cpSize);
                memset(ptr + cpSize, 0, ctx->pageSize - cpSize);
            }
        }
        
        CCPAGE_FRE_BUFFER(curPageOffset, false);
        CCPAGE_FRE_BUFFER(prevSubOffset, false);
        CCPAGE_FRE_BUFFER(brotherOffset, false);
        
        //5 来到parent进行插入
        
        //如果是叶子节点或者插入的和移动到parent的不是同一个，就需要插入
        if (isLeafPage || useCurIndex == false) {
            //在前半段插入
           if (isInsertPrev) {
               CCNodeCount_T r = nodeCnt - prevCnt;
               CCArrayRemoveValuesAtRange(pageNodeArray, CCRangeMake(prevCnt, r));
               r = pageCnt - nextSubPageIdx;
               CCArrayRemoveValuesAtRange(subPageArray, CCRangeMake(nextSubPageIdx, r));
               CCPageCount_T subPageIdx = getPageIdxFromNodeIdx(ctx, page, findNodeIdx);
               insertIndexIntoNotFullPage(ctx, page, subPageIdx, findNodeIdx, 0, index, indexLen, indexValue);
           }
           else {
               //在后半段插入
               CCArrayRemoveValuesAtRange(pageNodeArray, CCRangeMake(0, prevCnt));
               CCArrayRemoveValuesAtRange(subPageArray, CCRangeMake(0, nextSubPageIdx));
               CCPageCount_T subPageIdx = getPageIdxFromNodeIdx(ctx, page, findNodeIdx) - nextSubPageIdx;
               insertIndexIntoNotFullPage(ctx, page, subPageIdx, findNodeIdx, 0, index, indexLen, indexValue);
           }
        }
        
        freePage(ctx, page, false);
        //如果分裂的是root节点，修改ctx的root，rootOffset，rootBuffer
        if (curPageOffset == ctx->rootOffset) {
            ctx->rootOffset = parent;
            ctx->headBuffer->seekTo(CCHeaderOffRootOffset);
            ctx->headBuffer->writeLittleEndian64(ctx->rootOffset);
            readRootPage(ctx);
        }
        
        //在父节点中插入
        if (useCurIndex) {
            insertIndexWithPathNode(ctx, pathNode->parent, curPageOffset, index, indexLen, brother);
        }
        else {
            uint8_t *indexTmp = insertIntoParentIndex.bytes();
            CCIndexSize_T indexLenTmp = insertIntoParentIndexSize - CCPAGE_NODE_IDX_VALUE_BYTES;
            insertIndexWithPathNode(ctx, pathNode->parent, curPageOffset, indexTmp, indexLenTmp, brother);
        }
    }
    return 0;
}

static int insertIndex(CCBPTreeIndexContext_S *ctx, CCPageOffset_T pageOffset, CCIndexValue_T prevIndexValue, CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    struct CCPageFind find = lookupPage(ctx, nullptr, pageOffset, index, indexLen, true);
    if (find.fcd == CCFindCodeExists) {
        return find.fcd;
    }
    if (find.page == NULL) {
        return -1;
    }
    CCPage_S *page = find.page;
    int r = insertIndexWithPathNode(ctx, page->pNode, prevIndexValue, index, indexLen, indexValue);
    freePage(ctx, page, false);
    return r;
#if 0
    PCCArray_S pageNodeArray = page->pageNodeArray;
    CCNodeCount_T nodeCnt = CCArrayGetCount(pageNodeArray);
    if (nodeCnt < ctx->pageNodeCnt) {
        insertIndexIntoNotFullPage(ctx, page, find.subPageIdx, find.nodeIdx, prevIndexValue, index, indexLen, indexValue);
        freePage(ctx, page);
    }
    else {
        //进行分裂
        CCPageCount_T pageCnt = CCPAGE_CNT(page);
        PCCArray_S subPageArray = page->subPageArray;
        bool isLeafPage = (page->pageType & CCPageTypeLeaf) == CCPageTypeLeaf;
        CCNodeCount_T mid = ctx->pageNodeCnt >> 1;
        CCNodeCount_T prevCnt = mid;
        CCNodeCount_T insertIntoParentIdx = prevCnt;
        bool copyFromPrev = false;
        bool isInsertPrev = false;
        //1.找出分裂的位置
        /*
         *如果是奇数个，偶数个时进行分裂
         *1、如果是叶子节点分裂的话，两边各一半，将左边最大的index copy到父节点
         *2、如果是索引节点分裂，左边pageNodeCnt/2-1，右边pageNodeCnt/2，将左边最大的index移动到父节点
         */
        if (IS_ODD_NUM(ctx->pageNodeCnt)) {
            if (find.nodeIdx < mid) {
                isInsertPrev = true;
            }
            else {
                prevCnt += 1;
            }
            insertIntoParentIdx = prevCnt - 1;
            copyFromPrev = true;
        }
        else {
            /*
             *如果是偶数个，奇数时进行分裂
             *1、如果是叶子节点分裂的话，左边pageNodeCnt/2，右边是ctx->pageNodeCnt - pageNodeCnt/2,将右边的最小索引copy到父节点
             *2、如果是索引节点分裂的话，左右两边都是pageNodeCnt/2，将中间的节点移动到父节点中
             */
            if (find.nodeIdx < mid) {
                prevCnt -= 1;
                isInsertPrev = true;
            }
            insertIntoParentIdx = prevCnt;
        }
        
        //2. 计算父类的offset
        CCPageOffset_T parent = 0;
        bool newParentOffset = false;
        if (page->pNode) {
            parent = page->pNode->offset;
        }
        if (parent == 0) {
            newParentOffset = true;
            parent = createNewPageOffset(ctx);
        }

        //3. 修改当前的page
        const CCPageOffset_T curPageOffset = page->pageOffset;
        CCPAGE_DEC_BUFFER(curPageOffset, buffer, bufferType);
//        if (buffer == NULL) {
//            freePage(ctx, page);
//            if (newParentOffset) {
//                addFreePageOffset(ctx, parent);
//            }
//            return -1;
//        }
        
        //3.1修改pageType
        //如果pageType就是root，那就是修改为index
        if (page->pageType == CCPageTypeRoot) {
            page->pageType = CCPageTypeIndex;
            buffer->seekTo(CCPageHeaderOffPType);
            buffer->writeByte(page->pageType);
        }
        //如果pageType包含root，那么这个page就即使root也是leaf(叶子)，那么就将该page修改leaf page
        else if (page->pageType & CCPageTypeRoot) {
            page->pageType = CCPageTypeLeaf;
            buffer->seekTo(CCPageHeaderOffPType);
            buffer->writeByte(page->pageType);
        }
        
        //3.2修改page的brother
        bool newBrotherOffset = false;
        CCPageOffset_T brother = 0;
        //兄弟节点的next
        CCPageOffset_T brotherNextOffset = 0;
        //取prevCnt（要分裂出去的）所在的pageIdx
        CCPageCount_T nextSubPageIdx = getPageIdxFromNodeIdx(ctx, page, prevCnt);
        CCSubPage *split = CCPAGE_SUB_AT_IDX(page,nextSubPageIdx);
        if (split->sIdx == prevCnt) {
            brother = split->offset;
        }
        else {
            newBrotherOffset = true;
            brother = createNewPageOffset(ctx);
            CCPageCount_T nextSubPageIdxTmp = nextSubPageIdx + 1;
            if (nextSubPageIdxTmp < CCPAGE_CNT(page)) {
                brotherNextOffset = CCPAGE_SUB_AT_IDX(page, nextSubPageIdxTmp)->offset;
            }
        }
        //如果是B*树，都有brother
        if (isLeafPage) {
            buffer->seekTo(CCPageHeaderOffBrother);
            buffer->writeLittleEndian64(brother);
        }
        
        //3.3修改page的next为0
        CCPageOffset_T prevOffsetTmp = 0;
        CCSubPage *prevSubPage = NULL;
        /*如果是新建brother，则split就是第一个subPage
         *否则prevSubPageIdx就是第一个subPage
         */
        if (newBrotherOffset) {
            prevOffsetTmp = split->offset;
            prevSubPage = split;
        }
        else {
            CCPageCount_T prevSubPageIdx = 0;
            //在这里,这个nextSubPageIdx肯定会大于0
            if (nextSubPageIdx >= 1) {
                prevSubPageIdx = nextSubPageIdx - 1;
            }
            else {
                printf("error\n");
            }
            CCSubPage *prev = CCPAGE_SUB_AT_IDX(page, prevSubPageIdx);
            prevOffsetTmp = prev->offset;
            prevSubPage = prev;
        }

        //创建prevBuffer，将prevPage的最后一个subPage的next设置为0；
        const CCPageOffset_T prevSubOffset = prevOffsetTmp;
        CCPAGE_DEC_BUFFER(prevSubOffset, prevBuffer, prevBufferType);
//        if (prevBuffer == nullptr) {
//            if (newBrotherOffset) {
//                addFreePageOffset(ctx, brother);
//            }
//            if (newParentOffset) {
//                addFreePageOffset(ctx, parent);
//            }
//            CCPAGE_FRE_BUFFER(pageOffset, false);
//            return -1;
//        }
        prevBuffer->seekTo(CCPageHeaderOffNext);
        prevBuffer->writeLittleEndian64(0);
        
        //4.修改brother的page
        //索引节点第一个孩子节点
        const CCPageOffset_T brotherOffset = brother;
        CCPageOffset_T brotherFirstChild = indexValue;
        CCPAGE_DEC_BUFFER(brotherOffset, brotherBuffer, brotherBufferType);
//        if (brotherBuffer == NULL) {
//            if (newBrotherOffset) {
//                addFreePageOffset(ctx, brother);
//            }
//            if (newParentOffset) {
//                addFreePageOffset(ctx, parent);
//            }
//            CCPAGE_FRE_BUFFER(buffer, bufferType);
//            CCPAGE_FRE_BUFFER(prevBuffer, prevBufferType);
//            return -1;
//        }
        
        //4.1 copy 需要插入到parent的index，value
        bool useCurIndex = false;
        CCPageSize_T insertIntoParentIndexSize = 0;
        if (insertIntoParentIdx == find.nodeIdx) {
            useCurIndex = true;
            insertIntoParentIndexSize = indexLen;
        }
        else {
            insertIntoParentIndexSize = CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx)->indexSize;
        }
        insertIntoParentIndexSize += CCPAGE_NODE_IDX_VALUE_BYTES;
        CCMutableBuffer insertIntoParentIndex = CCMutableBuffer(insertIntoParentIndexSize);
        if (useCurIndex) {
            insertIntoParentIndex.writeBuffer(index, indexLen);
            insertIntoParentIndex.writeLittleEndian64(indexValue);
        }
        else {
            uint8_t *ptr = prevBuffer->bytes() + CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx)->indexOffset;
            insertIntoParentIndex.writeBuffer(ptr, insertIntoParentIdx);
            if (!isLeafPage) {
                memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, insertIntoParentIndexSize + CCPAGE_NODE_IDX_SIZE_BYTES);
            }
            CCPageOffset_T off = insertIntoParentIndexSize - CCPAGE_NODE_IDX_VALUE_BYTES;
            insertIntoParentIndex.seekTo(off);
            brotherFirstChild = insertIntoParentIndex.readLittleEndian64();
            //修改插入到parentPage的索引value为brother
            insertIntoParentIndex.seekTo(off);
            insertIntoParentIndex.writeLittleEndian64(brother);
        }
        if (isLeafPage == false) {
            brotherBuffer->seekTo(CCPageHeaderOffFChild);
            brotherBuffer->writeLittleEndian64(brotherFirstChild);
        }
        brotherBuffer->seekTo(CCPageHeaderOffBrother);
        brotherBuffer->writeLittleEndian64(page->brother);
        brotherBuffer->seekTo(CCPageHeaderOffPType);
        brotherBuffer->writeByte(page->pageType);
        page->brother = brother;
        
        if (newBrotherOffset) {
            //4.1 计算需要copy到insertIntoParentIndex的数据
            CCPageCount_T cpIdx = prevCnt;
            if (useCurIndex == false && !isLeafPage) {
                cpIdx = prevCnt + 1;
            }
            
            brotherBuffer->bzero();
            brotherBuffer->seekTo(CCPageHeaderOffNext);
            brotherBuffer->writeLittleEndian64(brotherNextOffset);
            
            //判断是否有数据需要copy到brotherBuffer
            if (cpIdx <= prevSubPage->eIdx) {
                CCPageSize_T sOff = CCPAGE_NODE_OFFSET(CCPAGE_NODE_AT_IDX(page, cpIdx));
                CCPageSize_T eOff = CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, split->eIdx));
                if (eOff > sOff) {
                    CCPageSize_T cp = eOff - sOff;
                    uint8_t *ptr = prevBuffer->bytes() + sOff;
                    brotherBuffer->seekTo(CCPageHeaderOffIndex);
                    brotherBuffer->writeBuffer(ptr, cp);
                    memset(ptr, 0, cp);
                }
            }
        }
        else {
            //如果不是新的brother，那就是原来的split的subPage
            if (useCurIndex == false && !isLeafPage && !copyFromPrev && insertIntoParentIdx < split->eIdx) {
                //将后面的往前面移动
                uint8_t *ptr = brotherBuffer->bytes() + CCPageHeaderOffIndex;
                CCPageSize_T cpSize = CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, split->eIdx)) - CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx));
                memmove(ptr, ptr + insertIntoParentIndexSize, cpSize);
                memset(ptr + cpSize, 0, ctx->pageSize - cpSize);
            }
        }
        
        CCPAGE_FRE_BUFFER(curPageOffset, false);
        CCPAGE_FRE_BUFFER(prevSubOffset, false);
        CCPAGE_FRE_BUFFER(brotherOffset, false);
        
        //5 来到parent进行插入
        
        //如果是叶子节点或者插入的和移动到parent的不是同一个，就需要插入
        if (isLeafPage || useCurIndex == false) {
            //在前半段插入
           if (isInsertPrev) {
               CCNodeCount_T r = nodeCnt - prevCnt;
               CCArrayRemoveValuesAtRange(pageNodeArray, CCRangeMake(prevCnt, r));
               r = pageCnt - nextSubPageIdx;
               CCArrayRemoveValuesAtRange(subPageArray, CCRangeMake(nextSubPageIdx, r));
               CCPageCount_T subPageIdx = getPageIdxFromNodeIdx(ctx, page, find.nodeIdx);
               insertIndexIntoNotFullPage(ctx, page, subPageIdx, find.nodeIdx, 0, index, indexLen, indexValue);
           }
           else {
               //在后半段插入
               CCArrayRemoveValuesAtRange(pageNodeArray, CCRangeMake(0, prevCnt));
               CCArrayRemoveValuesAtRange(subPageArray, CCRangeMake(0, nextSubPageIdx));
               CCPageCount_T subPageIdx = getPageIdxFromNodeIdx(ctx, page, find.nodeIdx) - nextSubPageIdx;
               insertIndexIntoNotFullPage(ctx, page, subPageIdx, find.nodeIdx, 0, index, indexLen, indexValue);
           }
        }
        
        freePage(ctx, page);
        //如果分裂的是root节点，修改ctx的root，rootOffset，rootBuffer
        if (curPageOffset == ctx->rootOffset) {
            ctx->rootOffset = parent;
            ctx->headBuffer->seekTo(CCHeaderOffRootOffset);
            ctx->headBuffer->writeLittleEndian64(ctx->rootOffset);
            readRootPage(ctx);
        }
        
        //在父节点中插入
        if (useCurIndex) {
            insertIndex(ctx, parent, curPageOffset, index, indexLen, brother, false);
        }
        else {
            uint8_t *indexTmp = insertIntoParentIndex.bytes();
            CCIndexSize_T indexLenTmp = insertIntoParentIndexSize - CCPAGE_NODE_IDX_VALUE_BYTES;
            insertIndex(ctx, parent, curPageOffset, indexTmp, indexLenTmp, brother, false);
        }
    }
    return 0;
#endif
}

//返回left的brother的offset，通过rightBrother返回rightBrother
static CCPageOffset_T findBrother(CCBPTreeIndexContext_S *ctx, CCPageOffset_T parent, CCNodeCount_T slotIdx, CCPageOffset_T *rightBrother, CCPage_S **ptr_parentPage)
{
    if (parent == 0) {
        return 0;
    }
    CCPageOffset_T lBrother = 0;
    CCPageOffset_T rBrother = 0;
    CCPage *parentPage = ctx->root;
    
    CCPAGE_DEC_BUFFER(parent, buffer, bufType)
    if (!IS_ROOT_OFF(parent)) {
        parentPage = readPage(ctx, parent, true);
    }
    CCNodeCount_T cnt = CCNODE_CNT(parentPage);
    if (slotIdx == 0) {
        lBrother = 0;
        if (cnt > 0) {
            rBrother = CCPAGE_NODE_AT_IDX(parentPage, 0)->value;
        }
    }
    else {
        CCNodeCount_T lIdx = slotIdx - 1;
        if (lIdx == 0) {
            lBrother = parentPage->firstChild;
        }
        else if (lIdx > 0 && lIdx <= cnt) {
            lBrother = CCPAGE_NODE_AT_IDX(parentPage, lIdx - 1)->value;
        }
        
        if (slotIdx >= 0 && slotIdx < cnt) {
            rBrother = CCPAGE_NODE_AT_IDX(parentPage, slotIdx)->value;
        }
    }
    CCPAGE_FRE_BUFFER(parent, false);
    if (rightBrother) {
        *rightBrother = rBrother;
    }
    
    if (ptr_parentPage) {
        *ptr_parentPage = parentPage;
    }
    freePage(ctx, parentPage, false);
    return lBrother;
}

static inline void updateIndexFromPage(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCNodeCount_T nodeIdx, CCIndex_T *index, CCIndexSize_T indexSize, CCIndexValue_T indexValue, bool updateIndexValue)
{
    CCPageSize_T pageSize = ctx->pageSize;
    CCSubPage *sub = CCPAGE_SUB_AT_IDX(page, subPageIdx);
    const CCPageOffset_T subOffset = sub->offset;
    CCPageNode_S *node = CCPAGE_NODE_AT_IDX(page, nodeIdx);
    CCIndexSize_T indexSizeOld = node->indexSize;
    CCPageSize_T indexOffset = node->indexOffset;
    
    if (indexSizeOld == indexSize) {
        CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);

        buffer->seekTo(indexOffset);
        buffer->writeBuffer(index, indexSize);
        if (updateIndexValue) {
            buffer->writeLittleEndian64(indexValue);
        }
        CCPAGE_FRE_BUFFER(subOffset, false);
    }
    else if (indexSizeOld > indexSize) {
        CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
        CCPageSize_T diff = indexSizeOld - indexSize;
        CCPageSize_T off = indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES;
        CCPageSize_T endOff = indexOffset + indexSizeOld + CCPAGE_NODE_IDX_VALUE_BYTES;
        uint8_t *endPtr = buffer->bytes() + endOff;
        CCIndexValue_T indexValueTmp = indexValue;
        if (!updateIndexValue) {
            buffer->seekTo(off + CCPAGE_NODE_IDX_SIZE_BYTES + indexSizeOld);
            indexValueTmp = buffer->readLittleEndian64();
            uint8_t *ptr = buffer->bytes() + off;
            memset(ptr, 0, CCPAGE_NODE_IDX_SIZE_BYTES + indexSizeOld + CCPAGE_NODE_IDX_VALUE_BYTES);
        }
        buffer->seekTo(off);
        buffer->writeByte(indexSize);
        buffer->writeBuffer(index, indexSize);
        buffer->writeLittleEndian64(indexValueTmp);
        CCPageSize_T mvCnt = pageSize - sub->remSize - endOff;
        if (mvCnt > 0) {
            memmove(endPtr - diff, endPtr, mvCnt);
            memset(endPtr + mvCnt - diff, 0, diff);
        }
        
        CCPAGE_FRE_BUFFER(subOffset, false);
    }
    else {
        CCPageSize_T diff = indexSize - indexSizeOld;
        CCPageSize_T needSize = CCPAGE_NODE_IDX_SIZE_BYTES + indexSize + CCPAGE_NODE_IDX_VALUE_BYTES;
        ensureSubPageRemSize(ctx, page, subPageIdx, needSize, nodeIdx, diff);
        bool remSizeEnough = true;
        CCPageOffset_T subOffTmp = subOffset;
        if (sub->remSize < needSize) {
            remSizeEnough = false;
            subOffTmp = CCPAGE_SUB_AT_IDX(page, nodeIdx + 1)->offset;
        }
        
        const CCPageOffset_T subOffsetNew = subOffTmp;
        CCPAGE_DEC_BUFFER(subOffsetNew, buffer, bufType);
        
        CCIndexValue_T indexValueTmp = indexValue;
        
        if (remSizeEnough) {
            if (!updateIndexValue) {
                buffer->seekTo(indexOffset + indexSizeOld);
                indexValueTmp = buffer->readLittleEndian64();
            }
            CCPageSize_T endOff = pageSize - sub->remSize;
            CCPageSize_T nodeEndOff = indexOffset + indexSizeOld + CCPAGE_NODE_IDX_VALUE_BYTES;
            uint8_t *ptr = nullptr;
            if (endOff > nodeEndOff) {
                ptr = buffer->bytes() + nodeEndOff;
                memmove(ptr + diff, ptr, endOff - nodeEndOff);
            }
            ptr = buffer->bytes() + indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES;
            memset(ptr, 0, CCPAGE_NODE_IDX_SIZE_BYTES + indexSize + CCPAGE_NODE_IDX_VALUE_BYTES);
            buffer->seekTo(indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES);
            buffer->writeByte(indexSize);
            buffer->writeBuffer(index, indexSize);
            buffer->writeLittleEndian64(indexValueTmp);
        }
        else {
            buffer->seekTo(CCPageHeaderOffIndex);
            buffer->writeByte(indexSize);
            buffer->writeBuffer(index, indexSize);
            buffer->writeLittleEndian64(indexValueTmp);
        }
        CCPAGE_FRE_BUFFER(subOffsetNew, false);
    }
}

static int updateIndex(CCBPTreeIndexContext_S *ctx, CCPageOffset_T pageOffset, CCIndex_T *index, CCIndexSize_T indexSize, CCIndexValue_T indexValue)
{
    struct CCPageFind find = lookupPage(ctx, nullptr, pageOffset, index, indexSize, true);
    if (find.fcd != CCFindCodeExists) {
        //表示不存在
        return CCFindCodeOK;
    }
    if (find.page == nullptr) {
        return CCFindCodeOK;
    }
    CCPage_S *page = find.page;
    
    updateIndexFromPage(ctx, page, find.subPageIdx, find.nodeIdx, index, indexSize, indexValue, true);
    return CCFindCodeOK;
}

static inline void deleteIndexFromPage(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCNodeCount_T nodeIdx)
{
    CCPageSize_T pageSize = ctx->pageSize;
    CCSubPage *sub = CCPAGE_SUB_AT_IDX(page, subPageIdx);
    const CCPageOffset_T subOffset = sub->offset;
    CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
    
    if (nodeIdx == 0) {
        page->firstChild = CCPAGE_NODE_AT_IDX(page, nodeIdx)->value;
        const CCPageOffset_T offsetTmp = page->pageOffset;
        CCPAGE_DEC_BUFFER(offsetTmp, pageBuffer, pageBufType);
        pageBuffer->seekTo(CCPageHeaderOffFChild);
        pageBuffer->writeLittleEndian64(page->firstChild);
        CCPAGE_FRE_BUFFER(offsetTmp, false);
    }
    
    CCPageNode *node = CCPAGE_NODE_AT_IDX(page, nodeIdx);
    CCPageSize_T size = CCPAGE_NODE_SIZE(node);
    CCPageSize_T offset = CCPAGE_NODE_OFFSET(node);
    CCPageSize_T endOffset = pageSize - sub->remSize;
    uint8_t *ptr = buffer->bytes() + offset;
    memset(ptr, 0, size);
    CCPageSize_T mvSize = endOffset - size - offset;
    if (mvSize > 0) {
        memmove(ptr, ptr + size, mvSize);
        memset(ptr + mvSize, 0, size);
    }

    if (IS_ROOT_PAGE(page)) {
        CCArrayRemoveValueAtIndex(page->pageNodeArray, nodeIdx);
    }

    CCPAGE_FRE_BUFFER(subOffset, bufType);
}

int deleteIndex(CCBPTreeIndexContext_S *ctx, CCPageOffset_T pageOffset, CCIndex_T *index, CCIndexSize_T indexLen, bool leaf)
{
    struct CCPageFind find = lookupPage(ctx, nullptr, pageOffset, index, indexLen, leaf);
    if (find.fcd != CCFindCodeExists) {
        //表示不存在
        return CCFindCodeOK;
    }
    if (find.page == nullptr) {
        return CCFindCodeOK;
    }
    CCPage_S *page = find.page;
    CCNodeCount_T minCnt = (ctx->pageNodeCnt + 1)/2;
    if (CCNODE_CNT(page) > minCnt) {
        deleteIndexFromPage(ctx, page, find.subPageIdx, find.nodeIdx);
        freePage(ctx, page, false);
    }
    else {
        //1. 获取是否叶子节点
        bool isLeafPage = CCPAGE_IS_LEAF(page);
        //2. 获取父节点
        CCNodeCount_T slotIdx = 0;
        CCPageOffset_T parent = 0;
        bool findBrother = false;
        if (page->pNode) {
            parent = page->pNode->offset;
            slotIdx = page->pNode->parentSlotIdx;
            findBrother = true;
        }
        //3. 查找左右兄弟节点
        CCPageOffset_T rBrother = 0;
        CCPageOffset_T lBrother = 0;
        CCPage_S *parentPage = nullptr;
        if (findBrother) {
            lBrother = ::findBrother(ctx, parent, slotIdx, &rBrother, &parentPage);
        }
        //4. 删除当前节点
        deleteIndexFromPage(ctx, page, find.subPageIdx, find.nodeIdx);
        
        CCNodeCount_T parentNodeIdx = slotIdx > 0 ? slotIdx - 1 : 0;
        CCPageCount_T parentSubPageIdx = getPageIdxFromNodeIdx(ctx, parentPage, parentNodeIdx);
        //5. 判断兄弟节点的情况
        if (lBrother > 0) {
            CCPage *lPage = readPage(ctx, lBrother, true);
            CCSubPage *lastSub = (CCSubPage*)CCArrayGetLastValue(lPage->subPageArray);
            const CCPageOffset_T lastOffset = lastSub->offset;
            CCPAGE_DEC_BUFFER(lastOffset, lastBuffer, lastBufferType);
            //5.1如果兄弟节点有富裕，从兄弟节点借一个节点过来，否则和兄弟节点合并
            CCNodeCount_T lNodeCnt = CCNODE_CNT(lPage);
            if (lNodeCnt > minCnt) {
                CCNodeCount_T eIdx = lNodeCnt - 1;
                /*
                 *5.1.1如果是叶子节点，
                 * (1)、将兄弟最后一个节点插入到本page第一位；
                 * (2)、将父节点的索引值更新为借过来兄弟节点的索引;
                 * (3)、将从兄弟节点借过来的节点清空
                 *5.1.2如果是索引节点
                 * (1)、将父节点的索引值更新到本page的第一位；
                 * (2)、将兄弟节点的最后一个节点索引替换父节点的索引
                 * (3)、将兄弟节点的最后一个节点清空
                 */
                if (isLeafPage) {
                    //(1)、将兄弟最后一个节点插入到本page第一位
                    CCPageNode *lNode = CCPAGE_NODE_AT_IDX(lPage, eIdx);
                    CCIndexSize_T indexSize = lNode->indexSize;
                    CCPageSize_T indexOffset = lNode->indexOffset;
                    CCIndexValue_T indexValue = lNode->value;
                    uint8_t *ptr = lastBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, 0, 0, 0, ptr, indexSize, indexValue);
                    //(2)、更新父节点的index的值
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    //(3)、将兄弟节点借过来的index清空
                    memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, indexSize + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES);
                }
                else {
                    //(1)将父节点的索引值更新到本page的第一位；
//                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    const CCPageOffset_T parentSubOff = CCPAGE_SUB_AT_IDX(parentPage, parentSubPageIdx)->offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    
                    CCPageNode *pNode = CCPAGE_NODE_AT_IDX(parentPage, parentNodeIdx);
                    CCIndexSize_T indexSize = pNode->indexSize;
                    CCPageSize_T indexOffset = pNode->indexOffset;
                    
                    CCIndexValue_T indexValue = page->firstChild;
                    
//                    CCIndexValue_T prevIndexValue = lPage->pageNodeList[eIdx].value;
                    CCIndexValue_T prevIndexValue = CCPAGE_NODE_AT_IDX(lPage, eIdx)->value;
                    
                    uint8_t *ptr = parentSubBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, 0, 0, prevIndexValue, ptr, indexSize, indexValue);
                    
                    //(2)将兄弟节点的最后一个节点索引替换父节点的索引
                    CCPageNode *lNode = CCPAGE_NODE_AT_IDX(lPage, eIdx);
                    indexSize = lNode->indexSize;
                    indexOffset = lNode->indexOffset;
                    ptr = lastBuffer->bytes() + indexOffset;
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    //(3)将兄弟节点的最后一个节点清空
                    memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, indexSize + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES);
                    
                    CCPAGE_FRE_BUFFER(parentSubOff, false);
                }
                
                //如果最后一个page没有节点后,将最后的一个page回收
                CCPageCount_T lPageCnt = CCPAGE_CNT(lPage);
                if (lastSub->eIdx == lastSub->sIdx && lPageCnt > 1) {
                    CCSubPage *last = CCPAGE_SUB_AT_IDX(lPage, lPageCnt - 2);
                    const CCPageOffset_T lastOffset = last->offset;
                    CCPAGE_DEC_BUFFER(lastOffset, lastTmp, lastType);
                    lastTmp->seekTo(CCPageHeaderOffNext);
                    lastTmp->writeLittleEndian64(0);
                    CCPAGE_FRE_BUFFER(lastOffset, false);
                    addFreePageOffset(ctx, last->offset);
                }
                --lastSub->eIdx;
            }
            else {
                //5.2 进行合并
                /*
                 *5.2.1如果是叶子节点，
                 * (1)、将当前节点和兄弟节点合并为一个page
                 * (2)、将父节点删除;
                 *5.2.2如果是索引节点
                 * (1)、将父节点下移
                 * (2)、将当前节点、父节点和兄弟节点合并为一个page
                 * (3)、将父节点清空
                 */
                
                if (isLeafPage) {
                    //(1)、将当前节点和兄弟节点合并为一个page
                    lastBuffer->seekTo(CCPageHeaderOffNext);
                    lastBuffer->writeLittleEndian64(page->pageOffset);
                    
                    const CCPageOffset_T lOffset = lPage->pageOffset;
                    CCPAGE_DEC_BUFFER(lPage->pageOffset, firstBuffer, firstBufferType);
                    firstBuffer->seekTo(CCPageHeaderOffBrother);
                    firstBuffer->writeLittleEndian64(page->brother);
                    CCPAGE_FRE_BUFFER(lOffset, false);
                    //(2)、将父节点删除
                    CCPageNode *pNode = CCPAGE_NODE_AT_IDX(parentPage, parentNodeIdx);
                    CCIndexSize_T parentIndexSize = pNode->indexSize;
                    CCPageSize_T parentIndexOffset = pNode->indexOffset;

                    const CCPageOffset_T parentSubOff = CCPAGE_SUB_AT_IDX(parentPage, parentSubPageIdx)->offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    CCIndex_T *parentIndex = parentSubBuffer->bytes() + parentIndexOffset;
                    deleteIndex(ctx, parent, parentIndex, parentIndexSize, NO);
                    CCPAGE_FRE_BUFFER(parentSubOff, false);
                    //TODO：修改内存数据
                }
                else {
                    const CCPageOffset_T parentSubOff = CCPAGE_SUB_AT_IDX(parentPage, parentSubPageIdx)->offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentBufferType);
                    
                    //(1)、将父节点下移；
                    CCPageNode *pNode = CCPAGE_NODE_AT_IDX(parentPage, parentNodeIdx);
                    CCIndexSize_T indexSize = pNode->indexSize;
                    CCPageSize_T indexOffset = pNode->indexOffset;
                    CCIndexValue_T indexValue = page->firstChild;
                    uint8_t *ptr = parentSubBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, lPage, CCPAGE_CNT(lPage) - 1, CCNODE_CNT(lPage), 0, ptr, indexSize, indexValue);
                    
                    CCPAGE_FRE_BUFFER(parentSubOff, false);
                    
                    //(2)、将当前节点、父节点和兄弟节点合并为一个page
                    lastBuffer->seekTo(CCPageHeaderOffNext);
                    lastBuffer->writeLittleEndian64(page->pageOffset);
                    
                    //(3)、将父节点清空
                    deleteIndex(ctx, parent, ptr, indexSize, NO);


                    //TODO：修改内存数据
                }
                //如果父节点没有节点后，将父节点回收，当前节点为叶子节点和root节点
                if (CCNODE_CNT(parentPage) == 0) {
                    addFreePageOffset(ctx, parentPage->pageOffset);
                    lPage->pageType = (CCPageType_E)(CCPageTypeLeaf | CCPageTypeRoot);

                    const CCPageOffset_T lOffset = lPage->pageOffset;
                    CCPAGE_DEC_BUFFER(lOffset, tmpBuf, tmpBufType);
                    tmpBuf->seekTo(CCPageHeaderOffPType);
                    tmpBuf->writeByte(lPage->pageType);
                    CCPAGE_FRE_BUFFER(lOffset, false);
                }
            }
            CCPAGE_FRE_BUFFER(lastOffset, false);
            freePage(ctx, lPage, false);
        }
        else {
            //6.判断右兄弟节点的情况
            CCPage *rPage = readPage(ctx, rBrother, true);
            CCSubPage *firstSub = (CCSubPage*)CCArrayGetFirstValue(rPage->subPageArray);
            const CCPageOffset_T firstOffset = firstSub->offset;
            CCPAGE_DEC_BUFFER(firstOffset, firstBuffer, firstBufferType);
            //6.1如果兄弟节点有富裕，从兄弟节点借一个节点过来，否则和兄弟节点合并
            if (CCNODE_CNT(rPage) > minCnt) {
                CCNodeCount_T sIdx = 0;
                CCPageCount_T pIdx = CCPAGE_CNT(page) - 1;//page->pageCnt - 1;
                CCNodeCount_T nIdx = CCNODE_CNT(page) - 1;//page->nodeCnt - 1;
                /*
                 *6.1.1如果是叶子节点，
                 * (1)、将兄弟第一个节点插入到本page最后一位；
                 * (2)、将父节点的索引值更新为借过来兄弟节点的索引;
                 * (3)、将从兄弟节点借过来的节点清空
                 *6.1.2如果是索引节点
                 * (1)、将父节点的索引值更新到本page的最后一位；
                 * (2)、将兄弟节点的第一个节点索引替换父节点的索引
                 * (3)、将兄弟节点的第一个节点清空
                 */
                if (isLeafPage) {
                    //(1)、将兄弟第一个节点插入到本page最后一位；
                    CCPageNode *rNode = CCPAGE_NODE_AT_IDX(rPage, sIdx);
                    CCIndexSize_T indexSize = rNode->indexSize;
                    CCPageSize_T indexOffset = rNode->indexOffset;
                    CCIndexValue_T indexValue = rNode->value;
                    uint8_t *ptr = firstBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, pIdx, nIdx, 0, ptr, indexSize, indexValue);
                    //(2)、将父节点的索引值更新为借过来兄弟节点的索引;
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    //(3)、将从兄弟节点借过来的节点清空
                    deleteIndexFromPage(ctx, rPage, 0, 0);
                }
                else {
                    //(1)、将父节点的索引值更新到本page的最后一位；
//                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    const CCPageOffset_T parentSubOff = CCPAGE_SUB_AT_IDX(parentPage, parentSubPageIdx)->offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    
                    CCPageNode *pNode = CCPAGE_NODE_AT_IDX(parentPage, parentNodeIdx);
                    CCIndexSize_T indexSize = pNode->indexSize;
                    CCPageSize_T indexOffset = pNode->indexOffset;
                    CCIndexValue_T indexValue = page->firstChild;
                    
                    uint8_t *ptr = parentSubBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, pIdx, nIdx, 0, ptr, indexSize, indexValue);
                    //(2)、将兄弟节点的第一个节点索引替换父节点的索引
                    CCPageNode *rNode = CCPAGE_NODE_AT_IDX(rPage, 0);
                    indexSize = rNode->indexSize;
                    indexOffset = rNode->indexOffset;
                    ptr = firstBuffer->bytes() + indexOffset;
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    CCPAGE_FRE_BUFFER(parentSubOff, false);
                    
                    //(3)、将兄弟节点的第一个节点清空
                    deleteIndexFromPage(ctx, rPage, 0, 0);
                }
                
                //如果第一个page没有节点后,将第一个page回收，也可以不回收，不进行回收，因为有可能前面page的brother指向此firstPage
                ++firstSub->sIdx;
//                if (firstSub->sIdx > firstSub->eIdx) {
//                    CCSubPage *first = &rPage->subPageList[1];
//                    CCPAGE_DEC_BUFFER(first->offset, firstSubBuffer, fistType);
//                    CCPAGE_FRE_BUFFER(firstSubBuffer, fistType);
//                }
            }
            else {
                //6.2 进行合并
                /*
                 *6.2.1如果是叶子节点，
                 * (1)、将当前节点和兄弟节点合并为一个page
                 * (2)、将父节点删除
                 *6.2.2如果是索引节点
                 * (1)、将父节点下移
                 * (2)、将当前节点、父节点和兄弟节点合并为一个page
                 * (3)、将父节点删除
                 */
                const CCPageOffset_T lastSubOff = ((CCSubPage*)CCArrayGetLastValue(page->subPageArray))->offset;
                if (isLeafPage) {
                    // (1)、将当前节点和兄弟节点合并为一个page
//                    CCPageOffset_T off = page->subPageList[0].offset;
                    const CCPageOffset_T off =  CCPAGE_SUB_FIRST(page)->offset;
                    CCPAGE_DEC_BUFFER(off, bufferTmp, bufferTmpType);
                    bufferTmp->seekTo(CCPageHeaderOffBrother);
                    bufferTmp->writeLittleEndian64(rPage->brother);

                    if (off == lastSubOff) {
                        bufferTmp->seekTo(CCPageHeaderOffNext);
                        bufferTmp->writeLittleEndian64(rPage->pageOffset);
                        CCPAGE_FRE_BUFFER(off, false);
                    }
                    else {
                        CCPAGE_FRE_BUFFER(off, false);
                        CCPAGE_DEC_BUFFER(lastSubOff, lastSubBuffer, lastSubBufferType);
                        lastSubBuffer->seekTo(CCPageHeaderOffNext);
                        lastSubBuffer->writeLittleEndian64(rPage->pageOffset);
                        CCPAGE_FRE_BUFFER(lastSubOff, false);
                    }

                    //(2)、将父节点删除
                    const CCPageOffset_T parentSubOff = CCPAGE_SUB_AT_IDX(parentPage, parentSubPageIdx)->offset;
                    CCPageNode *pNode = CCPAGE_NODE_AT_IDX(parentPage, parentNodeIdx);
                    CCIndexSize_T parentIndexSize = pNode->indexSize;
                    CCPageSize_T parentIndexOffset = pNode->indexOffset;
                    
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    
                    CCIndex_T *parentIndex = parentSubBuffer->bytes() + parentIndexOffset;
                    deleteIndex(ctx, parent, parentIndex, parentIndexSize, NO);
                    
                    CCPAGE_FRE_BUFFER(parentSubOff, false);
                }
                else {
                    const CCPageOffset_T parentSubOff = CCPAGE_SUB_AT_IDX(parentPage, parentSubPageIdx)->offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentBuffer, parentBufferType);
                    // (1)、将父节点下移
                    CCPageNode *pNode = CCPAGE_NODE_AT_IDX(parentPage, parentNodeIdx);
                    CCIndexSize_T indexSize = pNode->indexSize;
                    CCPageSize_T indexOffset = pNode->indexOffset;
                    CCIndexValue_T indexValue = page->firstChild;
                    uint8_t *ptr = parentBuffer->bytes() + indexOffset;
                    
                    insertIndexIntoNotFullPage(ctx, page, CCPAGE_CNT(page) - 1, CCNODE_CNT(page), 0, ptr, indexSize, indexValue);
                    CCPAGE_FRE_BUFFER(parentSubOff, false);

                    //(2)、将当前节点、父节点和兄弟节点合并为一个page
                    CCPAGE_DEC_BUFFER(lastSubOff, lastSubBuffer, lastSubBufferType);
                    lastSubBuffer->seekTo(CCPageHeaderOffNext);
                    lastSubBuffer->writeLittleEndian64(rPage->pageOffset);
                    CCPAGE_FRE_BUFFER(lastSubOff, false);
                    
                    //(3)、将父节点删除
                    deleteIndex(ctx, parent, ptr, indexSize, NO);
                }
                
                if (CCNODE_CNT(parentPage) == 0) {
                    addFreePageOffset(ctx, parentPage->pageOffset);
                    page->pageType = (CCPageType_E)(CCPageTypeLeaf | CCPageTypeRoot);

                    const CCPageOffset_T tmpOffset = page->pageOffset;
                    CCPAGE_DEC_BUFFER(tmpOffset, tmpBuf, tmpBufType);
                    tmpBuf->seekTo(CCPageHeaderOffPType);
                    tmpBuf->writeByte(page->pageType);
                    CCPAGE_FRE_BUFFER(tmpOffset, false);
                }
            }
            CCPAGE_FRE_BUFFER(firstOffset, false);
            freePage(ctx, rPage, false);
        }
        freePage(ctx, parentPage, false);
    }
    return 0;
}

CCBPTreeIndex::CCBPTreeIndex(const string &indexFile)
{
    _ptrRBTreeIndexContext = CCBPTreeIndexContextCreate(nullptr, indexFile, 1024, 0);
}

CCBPTreeIndex::CCBPTreeIndex(const string &indexFile, CCIndexSize_T indexLen)
{
    CCNodeCount_T nodeCnt = 1024;
    CCPageSize_T pageSize = nodeCnt * indexLen;
    pageSize = MAX(pageSize, defaultPageSize_g);
    _ptrRBTreeIndexContext = CCBPTreeIndexContextCreate(nullptr, indexFile, nodeCnt, pageSize);
}

CCBPTreeIndex::CCBPTreeIndex(const string &indexFile, CCUInt16_t pageNodeCount, CCIndexSize_T indexLen)
{
    CCPageSize_T pageSize = pageNodeCount * indexLen;
    pageSize = MAX(pageSize, defaultPageSize_g);
    _ptrRBTreeIndexContext = CCBPTreeIndexContextCreate(nullptr, indexFile, pageNodeCount, pageSize);
}

CCBPTreeIndex::~CCBPTreeIndex()
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    if (ctx) {
        destroyBufferCache(ctx);
        
        if (ctx->headBuffer) {
            ctx->fileMap->destroyMapBuffer(ctx->headBuffer);
            ctx->headBuffer = NULL;
        }

        if (ctx->rootBuffer) {
            ctx->fileMap->destroyMapBuffer(ctx->rootBuffer);
            ctx->rootBuffer = NULL;
        }
        
        if (ctx->fileMap) {
            ctx->fileMap->close();
            delete ctx->fileMap;
            ctx->fileMap = NULL;
        }
        if (ctx->root) {
            freePage(ctx, ctx->root, true);
            ctx->root = NULL;
        }
        
        free(ctx);
        _ptrRBTreeIndexContext = nullptr;
    }
}

int CCBPTreeIndex::selectIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T *indexValue)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    struct CCPageFind find = lookupPage(ctx, nullptr, ctx->rootOffset, index, indexLen, true);
    if (indexValue) {
        *indexValue = find.value;
    }
    return find.fcd == CCFindCodeExists ? 0 : 1;
}

int CCBPTreeIndex::insertIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    return ::insertIndex(ctx, ctx->rootOffset, 0, index, indexLen, indexValue);
}

int CCBPTreeIndex::deleteIndex(CCIndex_T *index, CCIndexSize_T indexLen)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    ::deleteIndex(ctx, ctx->rootOffset, index, indexLen, true);
    return 0;
}

int CCBPTreeIndex::updateIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    ::updateIndex(ctx, ctx->rootOffset, index, indexLen, indexValue);
    return 0;
}



