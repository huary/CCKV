//
//  CCMMFileContext.h
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCMMFile.h"
#import "CCAESCryptor.h"
#import "CCMacro.h"

const int32_t CCMMFHeaderSize_g           = 128;
const int32_t CCMMFContentHeaderSize_g    = 128;

typedef enum CCMMFHeaderOffset {
    CCMMFHeaderOffsetVersion             = 0,
    CCMMFHeaderOffsetDataSize            = 2,
    CCMMFHeaderOffsetCryptor             = 10,
    CCMMFHeaderOffsetKeyHash             = 11,
}CCMMFHeaderOffset_E;

/**********************************************************************
 *
 *|---128字节的头部信息---|---content---|
 *
 ***********************************************************************/

/**********************************************************************
 *
 *|---2字节(version)---|---8字节(size)---|---1字节(cryptor)---|
 *|---32字节keyHash(sha256)---|---85字节(保留)---|
 *
 *其中---1字节(cryptor)---如下：
 *|---6bit的加密模式（CCCryptMode）,2bit的keytype（CCAESKeyType+1）---|
 *
 ***********************************************************************/
typedef struct CCMMFHeader{
    uint16_t version;
    //CCFHeaderSize_g + contentSize
    int64_t dataSize;
    uint8_t cryptorInfo;
    uint8_t hashKey[CC_SHA256_DIGEST_LENGTH];
//    uint8_t extra[CCMMFHeaderSize_g - CCMMFHeaderOffsetKeyHash - CC_SHA256_DIGEST_LENGTH];
}CCMMFHeader_S;


/**********************************************************************
 *
 *|---128字节的校验信息---|---data---|
 *
 ***********************************************************************/
typedef struct CCMMFContent {
    uint8_t hashKey[CC_SHA256_DIGEST_LENGTH];
    uint8_t extra[CCMMFContentHeaderSize_g - CC_SHA256_DIGEST_LENGTH];
}CCMMFContent_S;


typedef enum {
    //没有错误
    CCMMFErrorNone                    = 0,
    //打开失败
    CCMMFErrorOpen                    = 1,
    //没有输入密码
    CCMMFErrorCryptKeyNone            = 2,
    //密码错误
    CCMMFErrorCryptKeyError           = 3,
    //内部错误，从TYPE_LS(1, 16)开始,密码长度错误
    CCMMFErrorCryptKeySizeError       = TYPE_LS(1, 16),
    //加密模式错误
    CCMMFErrorCryptModeError,
}CCMMFError_E;

class CCMMFileContext;

typedef CCMMFError_E (*PTR_CCMMF_func)(CCMMFileContext *fileContext);

class CCMMFileContext : public CCMMFile {
    bool _syncWritePlainContentData;
    struct CCMMFHeader _header;
    struct CCMMFContent _content;
    //加密器
    shared_ptr<CCAESCryptor> _sharedPtrCryptor;
    
    void _readFHeader();
    
    void _readFContent();
    
    void _updateDataSize(int64_t dataSize);
        
    void _updateCryptorInfo(CCCodeData *cryptKey);
    
    void _rollbackCryptorInfo(uint8_t cryptorInfo, uint8_t hashKey[CC_SHA256_DIGEST_LENGTH]);
    
    bool _createCryptor(CCCodeData *cryptKey, bool checkCryptKey, CCMMFError_E *error);
    
    CCMMFError_E _openDecrypt(CCCodeData *cryptKey);
public:
    CCMMFileContext(const string &filePath);
    
    virtual ~CCMMFileContext();
    
    CCMMFError_E open(CCCodeData *cryptKey, bool syncWritePlainContentData = NO);
    
    int64_t appendWriteData(CCCodeData *data, bool *isEncrypt);
    
    CCCodeData readData(int64_t offset, int32_t length);
    
    /*
     *默认从_sharedPtrPlainContentData进行encrypt，
     */
    CCMMFError_E fullEncrypt(CCCodeData *ptrPlainContentData = nullptr);
    
    CCMMFError_E fullDecrypt();
    
    CCMMFError_E updateCryptKey(CCCodeData *cryptKey, PTR_CCMMF_func didFullDecrypt = nullptr);
    
    bool ensureContentBufferSize(uint64_t bufferSize);
    
    bool ensureContentBufferAppendSize(uint64_t appendSize);
    
    bool close();
    
    bool haveCryptor() const {return (_sharedPtrCryptor.get() ? true : false);};
    
protected:
    //这个只是存储从文件mmap后解密后的contentData，主要是为了在decode的时候不需要生成NSData影响性能。
    shared_ptr<CCCodeData> _sharedPtrPlainContentData;
};
