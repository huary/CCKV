//
//  CCMMFileContext.m
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import "CCMMFileContext.h"

typedef enum {
    _CCHashTypeMD2         = 1,
    _CCHashTypeMD4         = 2,
    _CCHashTypeMD5         = 3,
    _CCHashTypeSHA1        = 4,
    _CCHashTypeSHA224      = 5,
    _CCHashTypeSHA256      = 6,
    _CCHashTypeSHA384      = 7,
    _CCHashTypeSHA512      = 8,
    _CCHashTypeSHA3        = 9,
}_CCHashType;

static inline void _hashForData(CCCodeData *data, _CCHashType hashType, CCCodeData &hash)
{
    int64_t dataSize = data->dataSize();
    if (dataSize == 0) {
        return;
    }
    int64_t pos = hash.currentSeek();
    uint8_t *ptr = hash.bytes() + pos;
    uint8_t length = 0;
    switch (hashType) {
        case _CCHashTypeSHA256: {
            length = CC_SHA256_DIGEST_LENGTH;
            if (hash.remSeekSize() < length) {
                return;
            }
            CC_SHA256(data->bytes(), (CC_LONG)dataSize, ptr);
            break;
        }
        case _CCHashTypeSHA512: {
            length = CC_SHA512_DIGEST_LENGTH;
            if (hash.remSeekSize() < length) {
                return;
            }
            CC_SHA512(data->bytes(), (CC_LONG)dataSize, ptr);
            break;
        }
        default:
            break;
    }
    hash.seekTo(pos + length);
}

static inline void _hashForDataInto(CCCodeData *data, _CCHashType hashType, CCMutableCodeData &hash)
{
    int64_t dataSize = data->dataSize();
    if (dataSize == 0) {
        return;
    }
    int64_t pos = hash.currentSeek();
    uint8_t *ptr = hash.bytes() + pos;
    uint8_t length = 0;
    switch (hashType) {
        case _CCHashTypeSHA256: {
            length = CC_SHA256_DIGEST_LENGTH;
            hash.ensureRemSeekSize(length);
            CC_SHA256(data->bytes(), (CC_LONG)dataSize, ptr);
            break;
        }
        case _CCHashTypeSHA512: {
            length = CC_SHA512_DIGEST_LENGTH;
            hash.ensureRemSeekSize(length);
            CC_SHA512(data->bytes(), (CC_LONG)dataSize, ptr);
            break;
        }
        default:
            break;
    }
    hash.seekTo(pos + length);
}

static inline void _hashCryptKey(CCCodeData *cryptKey, CCAESKeyType *keyType, CCMutableCodeData &hash)
{
    CCAESKeyType keyTypeTmp = CCAESKeyType128;
    int64_t cryptKeySize = cryptKey->dataSize();
    if (cryptKeySize == 0) {
        return;
    }
    _hashForDataInto(cryptKey, _CCHashTypeSHA512, hash);
    if (cryptKeySize >= CCAESKeySize256) {
        keyTypeTmp = CCAESKeyType256;
    }
    else if (cryptKeySize >= CCAESKeySize192) {
        keyTypeTmp = CCAESKeyType192;
    }
    else {
        keyTypeTmp = CCAESKeyType128;
    }
    if (keyType) {
        *keyType = keyTypeTmp;
    }
}


void CCMMFileContext::_readFHeader()
{
    _sharedPtrHeaderData->seek(CCDataSeekTypeSET);
    _header.version = _sharedPtrHeaderData->readLittleEndian16();
    _header.dataSize = _sharedPtrHeaderData->readLittleEndian64();
    _header.cryptorInfo = _sharedPtrHeaderData->readByte();
    _sharedPtrHeaderData->read(_header.hashKey, CC_SHA256_DIGEST_LENGTH);
    
    if (_header.dataSize <= 0) {
        _updateDataSize(_header.dataSize);
    }
}

void CCMMFileContext::_readFContent()
{
    _sharedPtrContentData->read((uint8_t*)&_content, CCMMFContentHeaderSize_g);
    _sharedPtrContentData->seekTo(_header.dataSize - CCMMFHeaderSize_g - CCMMFContentHeaderSize_g);
}

void CCMMFileContext::_updateDataSize(int64_t dataSize)
{
    if (dataSize < 0) {
        return;
    }
    
    _header.dataSize = dataSize;
    _sharedPtrHeaderData->seekTo(CCMMFHeaderOffsetDataSize);
    _sharedPtrHeaderData->writeLittleEndian64(dataSize);
}

void CCMMFileContext::_updateCryptorInfo(CCCodeData *cryptKey)
{
    int32_t size = sizeof(_header.hashKey);
    if (_sharedPtrCryptor.get() != nullptr) {
        CCAESKeyType keyType = _sharedPtrCryptor->getKeyType();
        CCCryptMode cryptMode = _sharedPtrCryptor->getCryptMode();
        _header.cryptorInfo = TYPE_OR(TYPE_LS(cryptMode, 2), TYPE_AND(keyType + 1, 3));
        _sharedPtrHeaderData->seekTo(CCMMFHeaderOffsetCryptor);
        _sharedPtrHeaderData->writeByte(_header.cryptorInfo);
        //这里的hashKey不可能为nil
        CCCodeData hash(_header.hashKey, size);
        _hashForData(cryptKey, _CCHashTypeSHA256, hash);
    }
    else {
        _header.cryptorInfo = 0;
        _sharedPtrHeaderData->seekTo(CCMMFHeaderOffsetCryptor);
        _sharedPtrHeaderData->writeByte(_header.cryptorInfo);
        
        memset(_header.hashKey, 0,  size);
    }
    _sharedPtrHeaderData->seekTo(CCMMFHeaderOffsetKeyHash);
    _sharedPtrHeaderData->writeBuffer(_header.hashKey, size);
}

void CCMMFileContext::_rollbackCryptorInfo(uint8_t cryptorInfo, uint8_t hashKey[CC_SHA256_DIGEST_LENGTH])
{
    _header.cryptorInfo = cryptorInfo;
    _sharedPtrHeaderData->seekTo(CCMMFHeaderOffsetCryptor);
    _sharedPtrHeaderData->writeByte(_header.cryptorInfo);
    
    int32_t size = sizeof(_header.hashKey);
    memcpy(_header.hashKey, hashKey, size);
    _sharedPtrHeaderData->seekTo(CCMMFHeaderOffsetKeyHash);
    _sharedPtrHeaderData->writeBuffer(_header.hashKey, size);
}

bool CCMMFileContext::_createCryptor(CCCodeData *cryptKey, bool checkCryptKey, CCMMFError_E *error)
{
    CCAESKeySize keySize = CCAESKeySize128;
    CCAESKeyType keyType = CCAESKeyType128;
    
    CCCryptMode cryptMode = CCCryptModeCFB;
    
    CCCodeData *key = nil;
    CCCodeData *vector = nil;
    uint8_t cryptorInfo = _header.cryptorInfo;
    int64_t hashKeyDataSize = 0;
    
    CCMutableCodeData hashKey(CC_SHA512_DIGEST_LENGTH);
    BOOL oldHave = false;
    if (cryptorInfo == 0) {
        _hashCryptKey(cryptKey, &keyType, hashKey);
    }
    else {
        oldHave = true;
        keyType = (CCAESKeyType)(TYPE_AND(cryptorInfo, 3) - 1);
        cryptMode = (CCCryptMode)TYPE_RS(cryptorInfo, 2);
        
        _hashForData(cryptKey, _CCHashTypeSHA512, hashKey);
        
        if (checkCryptKey) {
            
            CCMutableCodeData cryptKeyHash(CC_SHA256_DIGEST_LENGTH);
            
            _hashForDataInto(cryptKey, _CCHashTypeSHA256, cryptKeyHash);
            if (memcmp(cryptKeyHash.bytes(), _header.hashKey, CC_SHA256_DIGEST_LENGTH)) {
                //密码不一致
                if (error) {
                    *error = CCMMFErrorCryptKeyError;
                }
                goto CREATE_CRYPTOR_ERR_END;
            }
            
        }
    }
    
    hashKeyDataSize = hashKey.dataSize();
    keySize = AES_KEYSIZE_FROM_KEYTYPE(keyType);
    if (hashKeyDataSize < keySize) {
        if (error) {
            *error = (CCMMFError_E)CCMMFErrorCryptKeySizeError;
        }
        goto CREATE_CRYPTOR_ERR_END;
    }
    key = new CCMutableCodeData(keySize);
    key->writeBuffer(hashKey.bytes(), keySize);
    //只运行这几种流式加密的方式
    if (cryptMode != CCCryptModeCFB &&
        cryptMode != CCCryptModeCFB1 &&
        cryptMode != CCCryptModeCFB8 &&
        cryptMode != CCCryptModeOFB) {
        if (error) {
            *error = (CCMMFError_E)CCMMFErrorCryptModeError;
        }
        goto CREATE_CRYPTOR_ERR_END;
    }
    
    vector = new CCMutableCodeData(CCAESKeySize128);
    vector->writeBuffer(hashKey.bytes() + hashKeyDataSize - CCAESKeySize128, CCAESKeySize128);
    
    _sharedPtrCryptor = make_shared<CCAESCryptor>(key, keyType, vector, cryptMode);
    
    _updateCryptorInfo(cryptKey);
    
CREATE_CRYPTOR_ERR_END:
    if (key) {
        delete key;
    }
    if (vector) {
        delete vector;
    }
    return oldHave;
}

CCMMFError_E CCMMFileContext::_openDecrypt(CCCodeData *cryptKey)
{
    bool haveCryptKey = (cryptKey != NULL && cryptKey->dataSize() > 0);
    if (_header.cryptorInfo == 0 && haveCryptKey == false) {
        return CCMMFErrorNone;
    }
    /*
     *如果cryptorInfo>0表示有加密的，但是现在没有加密器和密钥，表示有错误
     *如果第一次启动，cryptor为NULL，但是cryptKey应该有数据
     *如果非第一次启动，CFKV内部会调用_loadFromFileWithCryptKey，此时可以为cryptKey为NULL，但是cryptor不能为NULL
     */
    
    CCAESCryptor *cryptor = _sharedPtrCryptor.get();
    if (_header.cryptorInfo > 0 && cryptor == NULL && haveCryptKey == false) {
        return CCMMFErrorCryptKeyNone;
    }
    
    uint8_t oldCryptorInfo = _header.cryptorInfo;
    uint8_t oldHashKey[CC_SHA256_DIGEST_LENGTH] = {0};
    memcpy(oldHashKey, _header.hashKey, sizeof(_header.hashKey));
    
    CCMMFError_E error = CCMMFErrorNone;
    
    BOOL doDecrypt = cryptor ? YES : NO;
    //如果为第一次启动，
    if (cryptor == NULL && haveCryptKey) {
        bool oldHave = _createCryptor(cryptKey, YES, &error);
        if (error) {
            if (error == CCMMFErrorCryptKeyError) {
                NSLog(@"密码错误，error=%@",@(error));
            }
            else if (error == CCMMFErrorCryptKeySizeError) {
                NSLog(@"密码长度错误，error=%@",@(error));
            }
            else if (error == CCMMFErrorCryptModeError) {
                NSLog(@"加密模式错误，error=%@",@(error));
            }
            else {
                NSLog(@"创建加密器错误，error=%@",@(error));
            }
            
            close();
            return error;
        }
        
        doDecrypt = oldHave;
    }
    
    if (doDecrypt) {
        error = fullDecrypt();
    }
    if (error) {
        _rollbackCryptorInfo(oldCryptorInfo, oldHashKey);
        close();
    }
    NSLog(@"密码错误，error=%d",error);
    return error;
}

CCMMFileContext::CCMMFileContext(const string &filePath) : CCMMFile(filePath, CCMMFHeaderSize_g)
{
}

CCMMFileContext::~CCMMFileContext()
{
    close();
}

CCMMFError_E CCMMFileContext::open(CCCodeData *cryptKey, bool syncWritePlainContentData)
{
    bool isOK = CCMMFile::open();
    if (!isOK) {
        return CCMMFErrorOpen;
    }
    _readFHeader();
    
    _readFContent();
    
    _sharedPtrPlainContentData = _sharedPtrContentData;
    
    _openDecrypt(cryptKey);
    
    if (_sharedPtrCryptor.get()) {
        _syncWritePlainContentData = syncWritePlainContentData;
    }
    else {
        _syncWritePlainContentData = true;
    }
    
    return CCMMFErrorNone;
}

int64_t CCMMFileContext::appendWriteData(CCCodeData *data, bool *isEncrypt)
{
    int64_t dataSize = data->dataSize();
    
    bool isOK = ensureContentBufferAppendSize(dataSize);
    if (!isOK) {
        return -1;
    }
    
    CCAESCryptor *cryptor = _sharedPtrCryptor.get();
    CCCodeData *contentData = _sharedPtrContentData.get();
    
    int64_t writeOffset = contentData->dataSize();
    bool crypt = NO;
    if (cryptor) {
        CCCodeData output(contentData->bytes() + writeOffset, dataSize);
        cryptor->crypt(CCCryptOperationEncrypt, data, &output);
        contentData->seekTo(writeOffset + dataSize);
        crypt = YES;
    }
    else {
        contentData->writeCodeData(data);
    }
    if (isEncrypt) {
        *isEncrypt = crypt;
    }
    return writeOffset;
}

CCCodeData CCMMFileContext::readData(int64_t offset, int32_t length)
{
    return CCCodeData(_sharedPtrPlainContentData->bytes() + offset, length);
}

CCMMFError_E CCMMFileContext::fullEncrypt(CCCodeData *ptrPlainContentData)
{
    if (_sharedPtrCryptor.get()) {
        CCCodeData *plain = _sharedPtrPlainContentData.get();
        if (ptrPlainContentData) {
            plain = new CCMutableCodeData(CCMMFContentHeaderSize_g + ptrPlainContentData->dataSize());
        }
        plain->writeBuffer((uint8_t*)&_content, CCMMFContentHeaderSize_g);
        if (ptrPlainContentData) {
            plain->writeBuffer(ptrPlainContentData->bytes(), ptrPlainContentData->dataSize());
        }
        
        int64_t dataSize = plain->dataSize();
        int64_t outSize = dataSize;
        
        ensureContentBufferSize(outSize);
        
        _sharedPtrCryptor->reset();
        _sharedPtrCryptor->crypt(CCCryptOperationEncrypt, plain, _sharedPtrContentData.get());
    }
    return CCMMFErrorNone;
}

CCMMFError_E CCMMFileContext::fullDecrypt()
{
    if (_sharedPtrCryptor.get()) {
        int64_t dataSize = _sharedPtrContentData->dataSize();
        int64_t outSize = dataSize;
        CCMutableCodeData *codeData = new CCMutableCodeData(outSize);
        
        _sharedPtrCryptor->reset();
        _sharedPtrCryptor->crypt(CCCryptOperationDecrypt, _sharedPtrContentData.get(), codeData);
        outSize = codeData->dataSize();
        if (outSize < CCMMFContentHeaderSize_g || dataSize != outSize || memcmp(codeData->bytes(), _header.hashKey, sizeof(_header.hashKey))) {
            
            _sharedPtrCryptor->reset();
            delete codeData;
            return CCMMFErrorCryptKeyError;
        }
        codeData->seekTo(outSize);
        
        memcpy((uint8_t*)&_content, codeData->bytes(), CCMMFContentHeaderSize_g);
        
        memset(codeData->bytes(), 0, CCMMFContentHeaderSize_g);
        
        _sharedPtrPlainContentData = shared_ptr<CCCodeData>(codeData);
        
    }
    return CCMMFErrorNone;
}

CCMMFError_E CCMMFileContext::updateCryptKey(CCCodeData *cryptKey, PTR_CCMMF_func didFullDecrypt)
{
    bool haveCryptKey = (cryptKey != NULL && cryptKey->dataSize() > 0);
    
    if (haveCryptKey == false && _header.cryptorInfo == 0) {
        return CCMMFErrorNone;
    }
    
    CCMutableCodeData hashKey(CC_SHA256_DIGEST_LENGTH);
    _hashForDataInto(cryptKey, _CCHashTypeSHA256, hashKey);
    if (memcmp(hashKey.bytes(), _header.hashKey, CC_SHA256_DIGEST_LENGTH) == 0) {
        return CCMMFErrorNone;
    }
    
    CCMMFError_E error = CCMMFErrorNone;
    int32_t backupTag = 1;
    _sharedPtrCryptor->markTag(backupTag);
    CCMutableCodeData backup(_sharedPtrContentData.get());
    int64_t backupDataSize = backup.dataSize();
    
    error = fullDecrypt();
    if (error) {
        NSLog(@"解密错误，error=%d",error);
        _sharedPtrCryptor->resetToTag(backupTag);
        return error;
    }
    
    if (didFullDecrypt) {
        error = didFullDecrypt(this);
        if (error) {
            _sharedPtrCryptor->resetToTag(backupTag);
            return error;
        }
    }
    
    shared_ptr<CCAESCryptor> oldCryptor;
    _sharedPtrCryptor.swap(oldCryptor);
    if (haveCryptKey) {
        uint8_t oldCryptorInfo = _header.cryptorInfo;
        uint8_t oldHashKey[CC_SHA256_DIGEST_LENGTH] = {0};
        memcpy(oldHashKey, _header.hashKey, CC_SHA256_DIGEST_LENGTH);
        
        _createCryptor(cryptKey, NO, &error);
        
        if (error) {
            _sharedPtrCryptor.swap(oldCryptor);
            _sharedPtrCryptor->resetToTag(backupTag);
            return error;
        }
        
        error = fullEncrypt();
        if (error) {
            _sharedPtrCryptor.swap(oldCryptor);
            _sharedPtrCryptor->resetToTag(backupTag);
            
            memcpy(_sharedPtrContentData->bytes(), backup.bytes(), backup.dataSize());
            _sharedPtrContentData->seekTo(backupDataSize);
            
            _rollbackCryptorInfo(oldCryptorInfo, oldHashKey);
            
            return error;
        }
    }
    else {
        //这里是根据cryptor来计算cryptorInfo的
        _updateCryptorInfo(cryptKey);
    }
    return error;
}

bool CCMMFileContext::ensureContentBufferSize(uint64_t bufferSize)
{
    if (_sharedPtrContentData->bufferSize() > bufferSize) {
        return true;
    }
    int64_t needSize = CCMMFHeaderSize_g + bufferSize;
    bool isOK = CCMMFile::truncate(needSize);
    _readFHeader();
    _readFContent();
    return isOK;
}


bool CCMMFileContext::ensureContentBufferAppendSize(uint64_t appendSize)
{
    int64_t needSize = _sharedPtrContentData->dataSize() + appendSize;
    if (_sharedPtrContentData->bufferSize() > needSize) {
        return true;
    }
    needSize = CCMMFHeaderSize_g + needSize;
    bool isOK = CCMMFile::truncate(needSize);
    _readFHeader();
    _readFContent();
    return isOK;
}


bool CCMMFileContext::close()
{
    _sharedPtrCryptor.reset();
    _sharedPtrPlainContentData.reset();
    
    CCMMFile::close();
    return true;
}

