//
//  CCFM.h
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <string>

using namespace std;

//File Map
class CCFM {
private:
    int _fd;
    uint8_t *_ptr;
    int64_t _size;
    string _filePath;
public:
    CCFM(const string &filePath);
    virtual ~CCFM();
    
    bool open();
    
    int64_t size() const {return _size;}
    
    bool updateSize(int64_t size);
    
    int64_t getFileSize();
    
    uint8_t *ptr() const { return _ptr;}
    
    string filePath() const { return _filePath;}
    
    bool close();
};
