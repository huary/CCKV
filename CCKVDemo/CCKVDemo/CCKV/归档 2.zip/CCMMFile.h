//
//  CCMMFile.h
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#include <string>
#import "CCFM.h"
#import "CCCodeData.h"

using namespace std;

//Memory Map File
class CCMMFile {
private:
    string _filePath;
    int32_t _contentOffset;
    CCFM *_fm;
    
public:
    CCMMFile(const string &filePath, int32_t contentOffset);
    
    virtual ~CCMMFile();
    
    bool open();
    
    int64_t size() const { return _fm->size();};
    
    bool truncate(int64_t size);
    
    bool close();
    
protected:
    shared_ptr<CCCodeData> _sharedPtrHeaderData;
    shared_ptr<CCCodeData> _sharedPtrContentData;
};
