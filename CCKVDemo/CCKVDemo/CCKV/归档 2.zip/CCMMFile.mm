//
//  CCMMFile.m
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import "CCMMFile.h"

#import <vector>
#import <sys/stat.h>

static inline bool _checkAndMakeDirectory(string &filepath)
{
    if (filepath.length() == 0) {
        return false;
    }
    vector<size_t> vec;
    string sub = filepath;
    while (access(sub.c_str(), F_OK) != F_OK) {
        vec.insert(vec.begin(), sub.length());
        size_t p = sub.find_last_of('/');
        sub = sub.substr(0,p);
    }
    
    size_t cnt = vec.size();
    for (int i = 0; i < cnt; ++i) {
        size_t p = vec[i];
        string sub = filepath.substr(0, p);
        mkdir(sub.c_str(), S_IRWXU);
    }
    return true;
    //    return access(filepath.c_str(), F_OK) == F_OK;
}

CCMMFile::CCMMFile(const string &filePath, int32_t contentOffset)
{
    _filePath = filePath;
    _contentOffset = contentOffset;
    _fm = new CCFM(filePath);
}

CCMMFile::~CCMMFile()
{
    if (_fm) {
        delete _fm;
        _fm = nullptr;
    }
    close();
}

bool CCMMFile::open()
{
    bool isOK = false;
    
    size_t p = _filePath.find_last_of('/');
    string dir = _filePath.substr(0, p);
    
    _checkAndMakeDirectory(dir);
    
    if (_fm) {
        isOK = _fm->open();
    }
    
    if (isOK) {
        uint8_t *ptr = _fm->ptr();
        int64_t size = _fm->size();
        _sharedPtrHeaderData = make_shared<CCCodeData>(ptr, _contentOffset);
        _sharedPtrContentData = make_shared<CCCodeData>(ptr + _contentOffset, size - _contentOffset);
    }
    return isOK;
}

bool CCMMFile::truncate(int64_t size)
{
    if (!_fm) {
        return false;
    }
    bool isOK = _fm->updateSize(size);
    if (isOK) {
        uint8_t *ptr = _fm->ptr();
        int64_t size = _fm->size();
        _sharedPtrHeaderData = make_shared<CCCodeData>(ptr, _contentOffset);
        _sharedPtrContentData = make_shared<CCCodeData>(ptr + _contentOffset, size - _contentOffset);
    }
    return isOK;
}

bool CCMMFile::close()
{
    _sharedPtrHeaderData.reset();
    _sharedPtrContentData.reset();
    if (_fm) {
        return _fm->close();
    }
    return true;
}
