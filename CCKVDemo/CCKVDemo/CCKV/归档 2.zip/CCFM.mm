//
//  CCFM.m
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import "CCFM.h"
#import <sys/mman.h>
#import <sys/stat.h>
#import <zlib.h>
#import "CCMacro.h"

static const int DEFAULT_PAGE_SIZE_s = getpagesize();
static const int MIN_MMAP_SIZE_s = DEFAULT_PAGE_SIZE_s;     //64KB
static const int ceilFlag_s = (DEFAULT_PAGE_SIZE_s & (DEFAULT_PAGE_SIZE_s - 1)) == 0;


CCFM::CCFM(const string &filePath) : _filePath(filePath)
{
    
}

CCFM::~CCFM()
{
    close();
}

bool CCFM::open()
{
    _fd = ::open(_filePath.c_str(), O_RDWR|O_CREAT, S_IRWXU);
    if (_fd < 0) {
        return false;
    }
    return updateSize(0);
}

bool CCFM::updateSize(int64_t size)
{
    if (size == 0) {
        size = getFileSize();
    }
    
    if (size < MIN_MMAP_SIZE_s) {
        size = MIN_MMAP_SIZE_s;
    }
    
    //取DEFAULT_PAGE_SIZE_s的整数倍
    if (ceilFlag_s) {
        if (size & (DEFAULT_PAGE_SIZE_s - 1)) {
            int64_t tmp = TYPE_NOT(DEFAULT_PAGE_SIZE_s - 1);
            size = (size & tmp) + DEFAULT_PAGE_SIZE_s;
        }
    }
    else {
        if (size % DEFAULT_PAGE_SIZE_s) {
            size = (size + DEFAULT_PAGE_SIZE_s - 1) / DEFAULT_PAGE_SIZE_s * DEFAULT_PAGE_SIZE_s;
        }
    }
    
    if (_ptr && _ptr != MAP_FAILED) {
        if (munmap(_ptr, (size_t)_size)) {
            return false;
        }
    }
    
    if (_size != size) {
        //这个函数涉及到IO操作，最影响性能
        if (ftruncate(_fd, size) != 0) {
            return false;
        }
    }
    
    uint8_t *newPtr = (uint8_t*)mmap(_ptr, (size_t)size, PROT_READ | PROT_WRITE, MAP_SHARED, _fd, 0);
    if (newPtr == NULL || newPtr == MAP_FAILED) {
        return false;
    }
    _ptr = newPtr;
    _size = size;
    return true;
}

int64_t CCFM::getFileSize()
{
    struct stat st = {};
    if (fstat(_fd, &st) == F_OK) {
        return st.st_size;
    }
    return -1;
}

bool CCFM::close()
{
    if (_ptr != NULL && _ptr != MAP_FAILED) {
        munmap(_ptr, (size_t)_size);
        _ptr = NULL;
        _size = 0;
    }
    if (_fd) {
        ::close(_fd);
        _fd = 0;
    }
    return true;
}


