//
//  CCBPTreeIndex.cpp
//  CCKVDemo
//
//  Created by yuan on 2020/2/19.
//  Copyright © 2020 yuan. All rights reserved.
//

#include "CCBPTreeIndex.hpp"
#include "CCBuffer.h"
#include "CCMutableBuffer.h"

static int16_t _CCBPTreeIndexHeaderLen_s    = 256;
static int16_t _CCBPTreeIndexPageSize_s     = 16384; //16KB
static int16_t _CCBPTreeIndexMinPageSize_s  = 4096; //4KB
static int16_t _CCBPTreeIndexMaxNodeCnt_s   = 1024;

/*B+树索引的header
 *|---2字节(version)---|---8字节(rootOffset的位置)---|---2字节(rootSize的大小)---|
 *
 */

typedef enum CCPageType{
    CCPageTypeLeaf  = 1 << 0,
    CCPageTypeRoot  = 1 << 1,
    CCPageTypeIndex = 1 << 2,
}CCPageType_E;

struct CCPage;

typedef struct CCPageNode {
    uint16_t indexOffset;
    uint8_t indexSize;
    //如果是叶子节点，value的值就是存储的data，否则就是孩子节点的位置
    uint64_t value;
}CCPageNode_S;


/*page的header
*|---1字节(pageType)---|---2字节(nodeCnt)---|---2字节(pageSize)---|---8字节(pageOffset)---|
*|---8字节(next,8字节(pageOffset))---|
*|---8字节(parent,8字节(pageOffset))---|
*|---8字节(brother,8字节(pageOffset))---|
*|---8字节(firstChild,8字节(pageOffset))---|
*|---剩余是索引---|
*/

typedef struct CCPage{
    CCPageType_E pageType;
    uint16_t nodeCnt;
    uint16_t lastNodeIdx;
    uint16_t pageSize;
    uint64_t pageOffset;
    //本来改B+树中的一个Page，由于一个page存放不完所有的数据
//    struct CCPage *next;
    //指向父类的page，只在内存有这个关系，实际不存储这个父类的指针
//    struct CCPage *parent;
    uint64_t parent;
    //兄弟page，在内存有这个关系，只有叶子page才存放兄弟page
//    struct CCPage *brother;
    uint64_t brother;
    //第一个孩子page
//    struct CCPage *firstChild;
    uint64_t firstChild;
    //所有的pageNode的数组
    struct CCPageNode *pageNodeList;
}CCPage_S;

typedef struct CCBPTreeIndexContext
{
    uint16_t version;
    uint16_t rootSize;
    uint64_t rootOffset;
    CCFileMap *fileMap;
    struct CCPage *root;
    CCBuffer *rootBuffer;
}CCBPTreeIndexContext_S;

void _readNextPage(CCBPTreeIndexContext_S *ctx, CCPage_S *page, uint64_t next)
{
    if (next <= 0) {
        return;
    }
    CCPageNode_S *ptr = (CCPageNode_S*)page->pageNodeList;
    ctx->fileMap->update(next, _CCBPTreeIndexMinPageSize_s);
    CCBuffer buffer = CCBuffer(ctx->fileMap->ptr(), _CCBPTreeIndexMinPageSize_s);
    uint16_t size = buffer.readLittleEndian16();
    uint64_t nextTmp = buffer.readLittleEndian64();
    int64_t cur = buffer.currentSeek();
    int64_t rem = size - cur;
    while (rem > 0) {
        uint8_t size = buffer.readByte();
        ptr[page->lastNodeIdx].indexSize = size;
        ptr[page->lastNodeIdx].indexOffset = buffer.currentSeek();
        cur = buffer.currentSeek() + size;
        buffer.seekTo(cur);
        ptr[page->lastNodeIdx].value = buffer.readLittleEndian64();
        rem = size - buffer.currentSeek();
        ++page->lastNodeIdx;
    }
    if (nextTmp > 0 && page->lastNodeIdx + 1 < page->nodeCnt) {
        _readNextPage(ctx, page, nextTmp);
    }
}

void _readPageNode(CCBPTreeIndexContext_S *ctx, CCPage_S *page ,CCBuffer *buffer, uint64_t next)
{
    CCPageNode_S *ptr = (CCPageNode_S*)calloc(_CCBPTreeIndexMaxNodeCnt_s, sizeof(CCPageNode_S));
    if (ptr) {
        int64_t cur = buffer->currentSeek();
        int64_t rem = page->pageSize - cur;
        while (rem > 0) {
            uint8_t size = buffer->readByte();
            ptr[page->lastNodeIdx].indexSize = size;
            ptr[page->lastNodeIdx].indexOffset = buffer->currentSeek();
            cur = buffer->currentSeek() + size;
            buffer->seekTo(cur);
            ptr[page->lastNodeIdx].value = buffer->readLittleEndian64();
            rem = page->pageSize - buffer->currentSeek();
            ++page->lastNodeIdx;
        }
        
        if (next > 0 && page->lastNodeIdx + 1 < page->nodeCnt) {
            _readNextPage(ctx, page, next);
        }
    }
    page->pageNodeList = ptr;
}

CCPage_S *_readPage(CCBPTreeIndexContext_S *ctx, uint16_t size)
{
    uint8_t *ptr = ctx->fileMap->ptr();
    CCBuffer buffer = CCBuffer(ptr, size);
    struct CCPage *page = (CCPage_S *)calloc(1, sizeof(CCPage_S));
    page->pageType = (CCPageType_E)buffer.readByte();
    page->nodeCnt = buffer.readLittleEndian16();
    page->pageSize = buffer.readLittleEndian16();
    page->pageOffset = buffer.readLittleEndian64();
    
    uint64_t next = buffer.readLittleEndian64();
    page->parent = buffer.readLittleEndian64();
    
    if (page->pageType == CCPageTypeLeaf) {
        page->brother = buffer.readLittleEndian64();
    }
    page->firstChild = buffer.readLittleEndian64();
    _readPageNode(ctx, page, &buffer, next);
    return page;
}

//CCPage_S *_lookInsertPage(CCBPTreeIndexContext_S *ctx, CCPage_S *page, uint8_t *index, uint8_t indexLen)
//{
//    ctx->fileMap->update(page->pageOffset, page->pageSize);
//
//    uint8_t *ptr = ctx->fileMap->ptr();
//
//    CCPageNode_S *list = page->pageNodeList;
//    uint16_t s = 0;
//    uint16_t e = page->nodeCnt - 1;
//    uint16_t m = (s + e) / 2;
//
//    if (page->pageType & CCPageTypeLeaf) {
//        if (memcmp(ptr + list[s].indexOffset, index, min(indexLen, list[s].indexSize)) > 0) {
//            return page;
//        }
//        else if (memcmp(ptr + list[e].indexOffset, index, min(indexLen, list[e].indexSize)) < 0) {
//            return page;
//        }
//    }
//
//    while (s + 1 < e) {
//        int r = memcmp(ptr + list[m].indexOffset, index, min(indexLen, list[m].indexSize));
//        if ( r < 0) {
//            e = m;
//        }
//        else if (r > 0) {
//            s = m;
//        }
//        else {
//            if (indexLen > list[m].indexSize) {
//                e = m;
//            }
//            else if (indexLen < list[m].indexSize) {
//                s = m;
//            }
//            else {
//                break;
//            }
//        }
//
//        m = (e + s)/2;
//    }
//
//    return nullptr;
//}


CCBPTreeIndex::CCBPTreeIndex(const string &indexFile)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S *)calloc(1, sizeof(CCBPTreeIndexContext_S));
    _ptrRBTreeIndexContext = ctx;
    CCFileMap *fileMap = new CCFileMap(indexFile);
    ctx->fileMap = fileMap;
    fileMap->open(_CCBPTreeIndexHeaderLen_s);
        
    CCBuffer buffer = CCBuffer(fileMap->ptr(), _CCBPTreeIndexHeaderLen_s);
    ctx->version = buffer.readLittleEndian16();
    int64_t offset = buffer.readLittleEndian64();
    uint16_t size = buffer.readLittleEndian16();
    if (size > 0) {
        ctx->rootOffset = offset;
        ctx->rootSize = size;
        fileMap->update(offset, size);
        ctx->rootBuffer = new CCMutableBuffer(size);
        ctx->rootBuffer->read(fileMap->ptr(), size);
        ctx->root = _readPage(ctx, size);
    }
}

CCBPTreeIndex::~CCBPTreeIndex()
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    if (ctx && ctx->fileMap) {
        ctx->fileMap->close();
        delete ctx->fileMap;
        ctx->fileMap = nullptr;
    }
    if (ctx && ctx->root) {
        if (ctx->root->pageNodeList) {
            free(ctx->root->pageNodeList);
            ctx->root->pageNodeList = nullptr;
        }
        free(ctx->root);
        ctx->root = nullptr;
    }
    if (ctx && ctx->rootBuffer) {
        delete ctx->rootBuffer;
        ctx->rootBuffer = nullptr;
    }
    if (ctx) {
        free(ctx);
        _ptrRBTreeIndexContext = nullptr;
    }
}



void CCBPTreeIndex::insertIndex(uint8_t *index, uint8_t indexLen)
{
//    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
//    if (ctx->root->nodeCnt) {
//
//    }
}


