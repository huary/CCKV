//
//  CCBPTreeIndex.hpp
//  CCKVDemo
//
//  Created by yuan on 2020/2/19.
//  Copyright © 2020 yuan. All rights reserved.
//

#ifndef CCBPTreeIndex_hpp
#define CCBPTreeIndex_hpp

#include <stdio.h>
#include <string>
#include "CCFileMap.hpp"

using namespace std;

class CCBPTreeIndex {
private:
    void *_ptrRBTreeIndexContext;
public:
    CCBPTreeIndex(const string &indexFile);
    
    virtual ~CCBPTreeIndex();
    
    void insertIndex(uint8_t *index, uint8_t indexLen);
};

#endif /* CCBPTreeIndex_hpp */
