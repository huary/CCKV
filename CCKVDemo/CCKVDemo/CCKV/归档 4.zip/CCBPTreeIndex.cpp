//
//  CCBPTreeIndex.cpp
//  CCKVDemo
//
//  Created by yuan on 2020/2/19.
//  Copyright © 2020 yuan. All rights reserved.
//

#include "CCBPTreeIndex.hpp"
#include "CCBuffer.h"
#include "CCMutableBuffer.h"
#include "CCFileMap.hpp"
#include "CCMacro.h"
#include "CCBase.h"
#include "CCArray.h"

//存储索引长度所占用的字节数(1字节)能表示索引长度为0-255
#define CCPAGE_NODE_IDX_SIZE_BYTES      (1)
#define CCPAGE_NODE_IDX_VALUE_BYTES     (8)
#define CCPAGE_OFFSET_BYTES             (8) //uint64_t 为8字节
#define CCPAGE_NODE_SIZE(PNODE)         ((PNODE)->indexSize + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES)
#define CCPAGE_NODE_OFFSET(PNODE)       ((PNODE)->indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES)
#define CCPAGE_NODE_END_OFFSET(PNODE)   ((PNODE)->indexOffset + (PNODE)->indexSize + CCPAGE_NODE_IDX_VALUE_BYTES)

#define CCPAGE_DEC_BUFFER(OFF,BF,BType)     CCBuffer *BF = ctx->rootBuffer; \
                                            uint8_t BType = CCBufferTypeRoot; \
                                            if (OFF != ctx->rootOffset) { \
                                                if (OFF != ctx->fileMap->offset()) { \
                                                    BF = ctx->fileMap->createMapBuffer(OFF, ctx->pageSize, CC_F_RDWR); \
                                                    if (BF) BType = CCBufferTypeCRT; \
                                                } \
                                                else { \
                                                    BF = new CCBuffer(ctx->fileMap->ptr(), ctx->pageSize); \
                                                    if (BF) BType = CCBufferTypeNew; \
                                                } \
                                            }

#define CCPAGE_FRE_BUFFER(BF, BType)        if (BF && BType == CCBufferTypeCRT) ctx->fileMap->destroyMapBuffer(BF); \
                                            else if (BF && BType == CCBufferTypeNew) delete BF; \
                                            BF = NULL;

#define CCPAGE_SIZE_FROM_FLAG(FLAG)     (1 << (FLAG & 31))
#define CCPAGE_IS_LEAF(PAGE)            ((PAGE->pageType & CCPageTypeLeaf) == CCPageTypeLeaf)

#define CCPAGE_NODE_AT_IDX(PAGE,IDX)    ((CCPageNode*)CCArrayGetValueAtIndex(PAGE->pageNodeArray, IDX))
#define CCSUBPAGE_AT_IDX(PAGE,IDX)      (((CCSubPage*)CCArrayGetValueAtIndex(PAGE->subPageArray, IDX)))
#define CCPAGE_CNT(PAGE)                CCArrayGetCount(PAGE->subPageArray)
#define CCNODE_CNT(PAGE)                CCArrayGetCount(PAGE->pageNodeArray)
#define IS_ROOT_PAGE(PAGE)              (PAGE->pageOffset == ctx->rootOffset)

//#define CCPage_Default_SIZE                 (16384)//16KB

static int16_t _CCBPTreeIndexHeaderLen_s    = 256;

//索引的长度,返回为0-255个字节
//typedef uint8_t CCIndexSize_T;
//page的size
typedef uint32_t CCPageSize_T;
//page的个数，最多由2^16-1个物理page页组成一个虚拟的page
typedef uint16_t CCPageCount_T;
//page中所含有的所有的node个数，最大为2^16-2
typedef uint16_t CCNodeCount_T;
//page相对整个文件的偏移量
typedef uint64_t CCPageOffset_T;
//索引的value，必须是uint64_t
//typedef uint64_t CCIndexValue_T;

static CCNodeCount_T _CCNodeListStepCnt_s = 128;
static CCPageCount_T _CCSubPageListStepCnt_s = 1;

typedef enum CCBufferType
{
    //rootbuffer,不需要delete和destroy
    CCBufferTypeRoot    = (1 << 0),
    //需要delete
    CCBufferTypeNew     = (1 << 1),
    //需要detroy
    CCBufferTypeCRT     = (1 << 2),
}CCBufferType_E;

typedef enum CCFindCode
{
    //查找错误
    CCFindCodeError     = -1,
    //查找OK
    CCFindCodeOK        = 0,
    //已经存在
    CCFindCodeExists    = 1,
}CCFindCode_E;

typedef enum CCHeaderOff
{
    CCHeaderOffVersion          = 0,
    CCHeaderOffPageNodeCnt      = 2,
    CCHeaderOffFlag             = 4,
    CCHeaderOffRootOffset       = 5,
    CCHeaderOffContentSize      = 13,
    CCHeaderOffFreePageOffset   = 21,
    CCHeaderOffEnd              = 29,
}CCHeaderOff_E;

typedef enum CCPageHeaderOff
{
    //next的offset(8)
    CCPageHeaderOffNext     = 0,
    //parent的offset(8),保留
    CCPageHeaderOffParent   = CCPageHeaderOffNext + CCPAGE_OFFSET_BYTES,
    //firstChild的offset(8)
    CCPageHeaderOffFChild   = CCPageHeaderOffParent + CCPAGE_OFFSET_BYTES,
    //brother的offset(8)
    CCPageHeaderOffBrother  = CCPageHeaderOffFChild + CCPAGE_OFFSET_BYTES,
    //pageType的offset(1)
    CCPageHeaderOffPType    = CCPageHeaderOffBrother + CCPAGE_OFFSET_BYTES,
    //索引的offset
    CCPageHeaderOffIndex    = CCPageHeaderOffPType + sizeof(CCIndexSize_T),
}CCPageHeaderOff_E;

typedef enum CCPageType{
    CCPageTypeNone  = 0,
    CCPageTypeLeaf  = 1 << 0,
    CCPageTypeRoot  = 1 << 1,
    CCPageTypeIndex = 1 << 2,
}CCPageType_E;

struct CCPage;

typedef struct CCPageNode {
    CCPageSize_T indexOffset;
    CCIndexSize_T indexSize;
    //如果是叶子节点，value的值就是存储的data，否则就是孩子节点的位置
    CCIndexValue_T value;
}CCPageNode_S;

typedef struct CCSubPage
{
    CCNodeCount_T sIdx;
    CCNodeCount_T eIdx;
//    CCPageCount_T startIdx;
//    CCPageCount_T endIdx;
//    CCPageSize_T size;
    CCPageSize_T remSize;
//    CCPageSize_T nodeStartOffset;
//    CCPageSize_T nodeEndOffset;
    CCPageOffset_T offset;
}CCSubPage_S;

typedef struct CCPathNode {
    CCPageOffset_T offset;
    CCNodeCount_T parentSlotIdx;
    struct CCPathNode *parent;
}CCPathNode_S;

/*page的header
 *|---8字节(next,8字节(pageOffset))---|
 *|---8字节(parent,8字节(pageOffset))---|
 *|---8字节(firstChild,8字节(pageOffset))---|
 *|---8字节(brother,8字节(pageOffset))---|
 *|---1字节(pageType)---|
 *|---剩余是索引---|
*/
typedef struct CCPage{
    CCPageType_E pageType;
    //这个nodeCnt是总数
//    CCNodeCount_T nodeCnt;
    //这个pageCnt是指含有多少个物理页
//    CCPageCount_T pageCnt;
    //subPageList的大小
//    CCPageCount_T subPageListSize;
    //pageNodeList的大小
//    CCNodeCount_T pageNodeListSize;
    //在父类中的idx
    CCNodeCount_T parentNodeSlotIdx;
    //当前page的offset
    CCPageOffset_T pageOffset;
    //父page，保留
    CCPageOffset_T parent;
    //兄弟page
    CCPageOffset_T brother;
    //第一个孩子page
    CCPageOffset_T firstChild;
    
//    struct CCPage *ptr_parent;
    struct CCPathNode *pNode;
    
    //所有的pageNode的数组
//    struct CCPageNode *pageNodeList;
    PCCArray_S pageNodeArray;
    //所有的subPage的数据
    PCCArray_S subPageArray;
//    struct CCSubPage *subPageList;
}CCPage_S;

typedef struct CCPageFind {
    //nodeIdx为-1表示已经存在这个索引
    CCFindCode_E fcd;
    CCNodeCount_T nodeIdx;
    CCPageCount_T subPageIdx;
    CCIndexValue_T value;
    struct CCPage *page;
}CCPageFind_S;


/*B+树索引的header
*|---2字节(version)---|---2字节(pageNodeCnt)---|---1字节flag(其中最低5表示组成的值表示pageSize的2^exp,如是16，那么pageSize=2^16=32KB,高3位组成的值表示B+树有多少+1层，如果值是5，表示有6层，最大可以表示8层)---|
*|---8字节(rootOffset的位置)---|---8字节(contentSize)---|---8字节(freePageOffset的位置)---|
*
*/
typedef struct CCBPTreeIndexContext
{
    uint16_t version;
    CCNodeCount_T pageNodeCnt;
    CCPageSize_T pageSize;
//    uint8_t level;
    uint8_t flag;
    bool destroyRootBuffer;
    CCPageOffset_T rootOffset;
    CCPageOffset_T contentSize;
    CCPageOffset_T freePageOffset;
    CCFileMap *fileMap;
    struct CCPage *root;
    struct CCPage *current;
    CCBuffer *headBuffer;
    CCBuffer *rootBuffer;
}CCBPTreeIndexContext_S, *PCCBPTreeIndexContext_S;

static inline CCCount expandArrayCapacity(PCCArray_S array, CCCount curCnt, CCCount addCnt, CCCount maxCnt) {
    CCCount cap = array ? CCArrayGetCapacity(array) : 0;
    CCCount featureCnt = cap;
    if (curCnt >= cap) {
        featureCnt = curCnt + addCnt;
    }
    return MIN(featureCnt, maxCnt);
}

//static inline CCNodeCount_T calPageNodeCount(CCBPTreeIndexContext_S *ctx, CCPage_S *page)
//{
//    CCNodeCount_T nodeCnt = 0;
//    CCCount cap = CCArrayGetCapacity(page->pageNodeArray);
//    if (page->nodeCnt == cap) {
//        nodeCnt = page->nodeCnt + _CCNodeListStepCnt_s;
//    }
//    else {
//        nodeCnt = cap > 0 ?:_CCNodeListStepCnt_s;
//    }
//    return MIN(nodeCnt, ctx->pageNodeCnt);
//}

//static inline CCPageCount_T calSubPageCount(CCBPTreeIndexContext_S *ctx, CCPage_S *page)
//{
//    CCPageCount_T pageCnt = 0;
//    CCCount cap = CCArrayGetCapacity(page->subPageArray);
//    if (page->pageCnt == cap) {
//        pageCnt = page->pageCnt + _CCSubPageListStepCnt_s;
//    }
//    else {
//        pageCnt = cap > 0 ?: _CCSubPageListStepCnt_s;
//    }
//    return pageCnt;
//}

//static inline bool resizeArray(PCCArray_S array, CCCount capacity, bool shrink) {
//
//}

static inline PCCArray_S createArray(CCCount capacity)
{
    CCArrayContext ctx;
    ctx.retain = NULL;
    ctx.release = NULL;
    ctx.equal = NULL;
    CCArrayOption_U option;
    option.option = 0;
    PCCArray_S array = CCArrayCreate(NULL, NULL, 0, &ctx, option);
    CCArraySetCapacity(array, capacity);
    return array;
}

static inline void resizePageNodeArray(CCBPTreeIndexContext_S *ctx, CCPage_S *page, bool shrink)
{
    if (page->pageNodeArray) {
        PCCArray_S array = page->pageNodeArray;
        CCCount curCnt = CCArrayGetCount(array);
        CCCount capacity = CCArrayGetCapacity(array);
        CCNodeCount_T featureCnt = expandArrayCapacity(array, curCnt, _CCNodeListStepCnt_s, ctx->pageNodeCnt);
        if ((shrink && featureCnt < capacity) || featureCnt > capacity) {
            CCArraySetCapacity(array, featureCnt);
        }
    }
    else {
        page->pageNodeArray = createArray(_CCNodeListStepCnt_s);
    }
    
//    CCPageNode_S *ptr = page->pageNodeList;
//    CCNodeCount_T cnt = calPageNodeCount(ctx, page);
//    if (ptr == nullptr) {
//        ptr = (CCPageNode_S*)calloc(cnt, sizeof(CCPageNode_S));
//        if (ptr == nullptr) {
//            return false;
//        }
//        page->pageNodeList = ptr;
//        page->pageNodeListSize = cnt;
//    }
//    else {
//        if ((shrink && cnt < page->pageNodeListSize) || cnt > page->pageNodeListSize) {
//            ptr = (CCPageNode_S*)realloc(ptr, cnt * sizeof(CCPageNode_S));
//            if (!ptr) {
//                return false;
//            }
//            page->pageNodeList = ptr;
//            page->pageNodeListSize = cnt;
//        }
//    }
//    return true;
}

static inline void resizeSubPageArray(CCBPTreeIndexContext_S *ctx, CCPage_S *page, bool shrink)
{
    if (page->subPageArray) {
        PCCArray_S array = page->subPageArray;
        CCCount curCnt = CCArrayGetCount(array);
        CCCount capacity = CCArrayGetCapacity(array);
        CCPageCount_T featureCnt = expandArrayCapacity(array, curCnt, _CCSubPageListStepCnt_s, CCCountMax);
        if ((shrink && featureCnt < capacity) || featureCnt > capacity) {
            CCArraySetCapacity(array, featureCnt);
        }
    }
    else {
        page->subPageArray = createArray(_CCSubPageListStepCnt_s);
    }
//    CCSubPage_S *ptr = page->subPageList;
//    CCPageCount_T cnt = calSubPageCount(ctx, page);
//    if (ptr == nullptr) {
//        ptr = (CCSubPage_S*)calloc(cnt, sizeof(CCSubPage_S));
//        if (ptr == nullptr) {
//            return false;
//        }
//        page->subPageList = ptr;
//        page->subPageListSize = cnt;
//    }
//    else {
//        if ((shrink && cnt < page->subPageListSize) || cnt > page->subPageListSize) {
//            ptr = (CCSubPage_S *)realloc(ptr, cnt * sizeof(CCSubPage_S));
//            if (!ptr) {
//                return false;
//            }
//            page->subPageList = ptr;
//            page->subPageListSize = cnt;
//        }
//    }
//    return true;
}

static void readNextPage(CCBPTreeIndexContext_S *ctx, CCPage_S *page, CCNodeCount_T fromIdx, CCPageOffset_T next)
{
    if (page == nullptr || next <= 0) {
        return;
    }
    CCPageSize_T pageSize = ctx->pageSize;
    
    CCBuffer *buffer = ctx->fileMap->createMapBuffer(next, pageSize, CC_F_READ);
    if (buffer == nullptr) {
        return;
    }
    buffer->seekTo(CCPageHeaderOffNext);
    CCPageOffset_T nextTmp = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffIndex);
    CCPageSize_T cur = (CCPageSize_T)buffer->currentSeek();
    CCPageSize_T rem = pageSize - cur;
    PCCArray_S array = page->pageNodeArray;
    while (rem > 0) {
        CCIndexSize_T size = buffer->readByte();
        if (size == 0) {
            break;
        }
        
        CCPageNode_S *node = (CCPageNode_S*)calloc(1, sizeof(CCPageNode_S));
        if (!node) {
            break;
        }
        
        node->indexSize = size;
        CCPageSize_T offset = (CCPageSize_T)buffer->currentSeek();
        node->indexOffset = offset;
        buffer->seekTo(offset + size);
        node->value = buffer->readLittleEndian64();
        rem = pageSize - (CCPageSize_T)buffer->currentSeek();
        
        if (CCArrayGetCount(array) >= CCArrayGetCapacity(array)) {
            resizePageNodeArray(ctx, page, false);
        }
        else {
            CCArrayAppendValue(page->pageNodeArray, (uintptr_t)node);
        }

    }
    ctx->fileMap->destroyMapBuffer(buffer);
    
    CCCount nodeCnt = CCArrayGetCount(page->pageNodeArray);
    
    CCSubPage_S *subPage = (CCSubPage_S*)calloc(1, sizeof(CCSubPage_S));
    if (!subPage) {
        return;
    }
    subPage->sIdx = fromIdx;
    subPage->eIdx = nodeCnt > 0 ? nodeCnt - 1 : 0;
    subPage->remSize = rem;
    subPage->offset = next;
    
    resizeSubPageArray(ctx, page, false);

    bool readNext = false;
    if (nextTmp > 0) {
        readNext = true;
    }
    if (readNext) {
        readNextPage(ctx, page, fromIdx, nextTmp);
    }
}

static void readPageNode(CCBPTreeIndexContext_S *ctx, CCPage_S *page, CCBuffer *buffer, CCPageOffset_T next)
{
    if (page == nullptr) {
        return;
    }
    resizePageNodeArray(ctx, page, false);
    CCPageSize_T rem = (CCPageSize_T)buffer->remSize();
    PCCArray_S array = page->pageNodeArray;
    while (rem > 0) {
        CCIndexSize_T size = buffer->readByte();
        if (size == 0) {
            break;
        }
        
        CCPageNode_S *node = (CCPageNode_S*)calloc(1, sizeof(CCPageNode_S));
        if (!node) {
            break;
        }
        
        node->indexSize = size;
        CCPageSize_T offset = (CCPageSize_T)buffer->currentSeek();
        node->indexOffset = offset;
        buffer->seekTo(offset + size);
        node->value = buffer->readLittleEndian64();
        rem = (CCPageSize_T)buffer->remSize();
        
        if (CCArrayGetCount(array) >= CCArrayGetCapacity(array)) {
            resizePageNodeArray(ctx, page, false);
        }
        else {
            CCArrayAppendValue(page->pageNodeArray, (uintptr_t)node);
        }
    }
    bool readNext = false;
    if (next > 0) {
        readNext = true;
    }
    
    CCCount nodeCnt = CCArrayGetCount(page->pageNodeArray);
    
    CCSubPage_S *subPage = (CCSubPage_S*)calloc(1, sizeof(CCSubPage_S));
    if (!subPage) {
        return;
    }
    subPage->sIdx = 0;
    subPage->eIdx = nodeCnt > 0 ? nodeCnt - 1 : 0;
    subPage->remSize = rem;
    subPage->offset = page->pageOffset;
    
    resizeSubPageArray(ctx, page, false);
    
    CCArrayAppendValue(page->subPageArray, (uintptr_t)subPage);

    if (readNext) {
        readNextPage(ctx, page, (CCNodeCount_T)nodeCnt, next);
    }
}

static CCPage_S *readPage(CCBPTreeIndexContext_S *ctx, CCPageOffset_T offset, bool newPage, bool readNode)
{
    CCPageSize_T pageSize = ctx->pageSize;
    bool newBuffer = false;
    
    CCBuffer *buffer = nullptr;
    if (offset == ctx->rootOffset) {
        buffer = ctx->rootBuffer;
    }
    else {
        newBuffer = true;
        buffer = ctx->fileMap->createMapBuffer(offset, pageSize, CC_F_READ);
        if (buffer == nullptr) {
            return nullptr;
        }
    }
    CCPageOffset_T next = 0;
    CCPage_S *page = nullptr;
    if (newPage) {
        page = (CCPage_S *)calloc(1, sizeof(CCPage_S));
        if (page == nullptr) {
            goto CC_READ_PAGE_END;
        }
    }
    else {
        if (ctx->current == nullptr) {
            page = (CCPage_S *)calloc(1, sizeof(CCPage_S));
            if (page == nullptr) {
                goto CC_READ_PAGE_END;
            }
            ctx->current = page;
        }
        else {
            page = ctx->current;
        }
    }
    page->pageOffset = offset;
    buffer->seekTo(CCPageHeaderOffNext);
    next = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffParent);
    page->parent = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffFChild);
    page->firstChild = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffBrother);
    page->brother = buffer->readLittleEndian64();
    buffer->seekTo(CCPageHeaderOffPType);
    page->pageType = (CCPageType_E)buffer->readByte();
    if (readNode) {
        buffer->seekTo(CCPageHeaderOffIndex);
        readPageNode(ctx, page, buffer, next);
    }
CC_READ_PAGE_END:
    if (newBuffer) {
        ctx->fileMap->destroyMapBuffer(buffer);
    }
    return page;
}

void freePage(CCBPTreeIndexContext_S *ctx, CCPage_S *page)
{
    if (page && page->pageNodeArray) {
        CCArrayDeallocate(page->pageNodeArray);
        page->pageNodeArray = NULL;
    }
    if (page && page->subPageArray) {
        CCArrayDeallocate(page->subPageArray);
        page->subPageArray = NULL;
    }
    if (page) {
        free(page);
    }
}

static void readRootPage(CCBPTreeIndexContext_S *ctx)
{
    CCPageSize_T pageSize = ctx->pageSize;
    CCPageOffset_T rootOffset = ctx->rootOffset;
    if (rootOffset < ctx->headBuffer->bufferSize()) {
        uint8_t *ptr = ctx->headBuffer->bytes() + rootOffset;
        CCPageSize_T size = (CCPageSize_T)(pageSize - rootOffset);
        ctx->rootBuffer = new CCBuffer(ptr, size);
        if (ctx->rootBuffer == nullptr) {
            return;
        }
        CCPage_S *page = ctx->root;
        if (page == nullptr) {
            page = (CCPage_S *)calloc(1, sizeof(CCPage_S));
            if (page == nullptr) {
                return;
            }
            ctx->root = page;
        }
        page->pageOffset = rootOffset;
        CCPageOffset_T next = ctx->rootBuffer->readLittleEndian64();
        page->parent = ctx->rootBuffer->readLittleEndian64();
        page->firstChild = ctx->rootBuffer->readLittleEndian64();
        page->brother = ctx->rootBuffer->readLittleEndian64();
        page->pageType = (CCPageType_E)ctx->rootBuffer->readByte();
        readPageNode(ctx, page, ctx->rootBuffer, next);
    }
    else {
        if (ctx->rootBuffer && ctx->destroyRootBuffer) {
            ctx->fileMap->destroyMapBuffer(ctx->rootBuffer);
            ctx->rootBuffer = nullptr;
            ctx->destroyRootBuffer = false;
        }
        if (ctx->root) {
            if (ctx->current == nullptr) {
                ctx->current = ctx->root;
                ctx->root = nullptr;
            }
//            else {
//                freePage(ctx, ctx->root);
//                ctx->root = nullptr;
//            }
        }
        
        ctx->rootBuffer = ctx->fileMap->createMapBuffer(rootOffset, pageSize, CC_F_RDWR);
        if (ctx->rootBuffer == nullptr) {
            return;
        }
        ctx->destroyRootBuffer = true;
        readPage(ctx, rootOffset, false, true);
        if (ctx->root) {
            freePage(ctx, ctx->root);
            ctx->root = nullptr;
        }
        ctx->root = ctx->current;
        //如果这里不把current设置为nullptr,其他的地方也用current来读取的话，那么会导致数据不一致。
        ctx->current = nullptr;
    }
}

static PCCBPTreeIndexContext_S CCBPTreeIndexContextCreate(PCCAllocator_S allocator, const string &indexFile, CCPageCount_T pageNodeCnt, CCPageSize_T pageSize)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S *)calloc(1, sizeof(CCBPTreeIndexContext_S));
    CCFileMap *fileMap = new CCFileMap(indexFile);
    ctx->fileMap = fileMap;
    fileMap->open(CC_F_RDWR);
    
    int64_t fileSize = ctx->fileMap->fileSize();
    CCPageSize_T headerLen = MAX(_CCBPTreeIndexHeaderLen_s,pageSize);
    
    CCBuffer *header = fileMap->createMapBuffer(0, headerLen, CC_F_RDWR);
    if (header == nullptr) {
        return nullptr;
    }
    ctx->headBuffer = header;
    
    if (fileSize > 0) {
        ctx->version = header->readLittleEndian16();
        ctx->pageNodeCnt = header->readLittleEndian16();
        uint8_t flag = header->readByte();
        ctx->flag = flag;
        ctx->pageSize = CCPAGE_SIZE_FROM_FLAG(flag);
        ctx->rootOffset = header->readLittleEndian64();
        ctx->contentSize = header->readLittleEndian64();
        ctx->freePageOffset = header->readLittleEndian64();
    }
    else {
        CCPageSize_T pageSize = (CCPageSize_T)header->bufferSize();
        uint8_t flag = TYPEUINT_BITS_N(pageSize);
        ctx->version = 1.0;
        ctx->pageNodeCnt = pageNodeCnt;
        ctx->flag = flag;
        ctx->pageSize = CCPAGE_SIZE_FROM_FLAG(flag);
        ctx->rootOffset = header->bufferSize();
        ctx->contentSize = header->bufferSize();
        ctx->freePageOffset = 0;
        
        header->seekTo(CCHeaderOffVersion);
        header->writeLittleEndian16(ctx->version);
        header->seekTo(CCHeaderOffPageNodeCnt);
        header->writeLittleEndian16(ctx->pageNodeCnt);
        header->seekTo(CCHeaderOffFlag);
        header->writeByte(ctx->flag);
        header->seekTo(CCHeaderOffRootOffset);
        header->writeLittleEndian64(ctx->rootOffset);
        header->seekTo(CCHeaderOffContentSize);
        header->writeLittleEndian64(ctx->contentSize);
        header->seekTo(CCHeaderOffFreePageOffset);
        header->writeLittleEndian64(ctx->freePageOffset);
    }
    readRootPage(ctx);
    
    return ctx;
}

static CCPageFind_S lookupPage(CCBPTreeIndexContext_S *ctx, CCPathNode_S *pNode, CCPageOffset_T offset, uint8_t levelIdx, CCIndex_T *index, CCIndexSize_T indexLen, bool leaf)
{
    CCPage_S *page = nullptr;
    if ((offset == 0 && levelIdx == 0 ) || offset == ctx->rootOffset) {
        page = ctx->root;
    }
    if (!page) {
        readPage(ctx, offset, false, true);
        page = ctx->current;
    }
    page->pNode = pNode;
    CCPageFind f;
    f.page = page;
    f.nodeIdx = 0;
    PCCArray_S pageNodeArray = page->pageNodeArray;
    CCCount nodeCnt = CCArrayGetCount(pageNodeArray);
    if (nodeCnt == 0) {
        return f;
    }
    
    PCCArray_S subPageArray = page->subPageArray;
    CCCount subPageCnt = CCArrayGetCount(subPageArray);
    
    CCPageSize_T pageSize = ctx->pageSize;
    CCPageCount_T ps = 0;
    CCPageCount_T pe = subPageCnt-1;
    while (ps <= pe) {
        CCPageCount_T pIdx = (ps + pe)/2;
        CCSubPage *subPage = (CCSubPage*)CCArrayGetValueAtIndex(subPageArray, pIdx);;
        CCPageOffset_T offset = subPage->offset;
        
        ctx->fileMap->read(offset, pageSize);
        uint8_t *ptr = ctx->fileMap->ptr();
        
        
//        CCPageNode_S *ns = &page->pageNodeList[subPage->sIdx];
        CCPageNode_S *ns = (CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, subPage->sIdx);
        int r = memcmp(index, ptr + ns->indexOffset, MIN(indexLen, ns->indexSize));
        
        //index < ns->index
        if (r < 0 || (r == 0 && indexLen < ns->indexSize)) {
            pe = pIdx - 1;
        }
        //index == ns->index
        else if (r == 0 && indexLen == ns->indexSize) {
            f.fcd = CCFindCodeExists;
            f.nodeIdx = subPage->sIdx;
            f.subPageIdx = pIdx;
            break;
        }
        //index > ns->index
        else {
//            CCPageNode_S *ne = &page->pageNodeList[subPage->eIdx];
            CCPageNode_S *ne = (CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, subPage->eIdx);
            r = memcmp(index, ptr + ne->indexOffset, MIN(indexLen, ne->indexSize));
            if (r < 0 || (r == 0 && indexLen < ns->indexSize)) {
                //就在此page中寻找
                f.subPageIdx = pIdx;
                CCNodeCount_T i = subPage->sIdx;
                CCNodeCount_T j = subPage->eIdx;
                while (i <= j) {
                    CCNodeCount_T m = (i + j)/2;
//                    CCPageNode *t = &page->pageNodeList[m];
                    CCPageNode *t = (CCPageNode*)CCArrayGetValueAtIndex(pageNodeArray, m);
                    r = memcmp(index, ptr + t->indexOffset, MIN(indexLen, t->indexSize));
                    if (r < 0 || (r == 0 && indexLen < t->indexSize)) {
                        j = m - 1;
                    }
                    else if (r == 0 && indexLen == t->indexSize) {
                        f.fcd = CCFindCodeExists;
                        f.nodeIdx = m;
                        break;
                    }
                    else {
                        i = m + 1;
                    }
                    //当i>=j时break
                    if (i >= j) {
                        if (i == j) {
                            ++i;
                        }
                        f.fcd = CCFindCodeOK;
                        f.nodeIdx = i;
                        break;
                    }
                }
                break;
            }
            else if (r == 0 && indexLen == ne->indexSize) {
                f.fcd = CCFindCodeExists;
                f.nodeIdx = subPage->eIdx;
                f.subPageIdx = pIdx;
                break;
            }
            else {
                ps = pIdx + 1;
            }
            //当ps>=pe时break
            if (ps >= pe) {
                if (ps == pe) {
                    ++ps;
                }
                f.fcd = CCFindCodeOK;
//                f.nodeIdx = page->subPageList[ps].sIdx;
                f.nodeIdx = ((CCSubPage_S*)CCArrayGetValueAtIndex(subPageArray, ps))->sIdx;
                f.subPageIdx = ps;
                break;
            }
        }
    }
    
    CCPageOffset_T nextPageOffset = 0;
    CCNodeCount_T slotIdx = 0;
    if (f.fcd == CCFindCodeOK) {
        if (f.nodeIdx >= 1) {
            slotIdx = f.nodeIdx;
//            nextPageOffset = page->pageNodeList[f.nodeIdx - 1].value;
            nextPageOffset = ((CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, f.nodeIdx-1))->value;
        }
        else {
            slotIdx = 0;
            nextPageOffset = page->firstChild;
        }
    }
    else {
        slotIdx = f.nodeIdx;
//        nextPageOffset = page->pageNodeList[f.nodeIdx].value;
        nextPageOffset = ((CCPageNode_S*)CCArrayGetValueAtIndex(pageNodeArray, f.nodeIdx))->value;
    }
    f.value = nextPageOffset;
    
    if (leaf && nextPageOffset > 0 && (page->pageType & CCPageTypeLeaf) != CCPageTypeLeaf) {
        struct CCPathNode *pInfoTmp = (CCPathNode_S*)malloc(sizeof(CCPathNode_S));
        if (pInfoTmp) {
            pInfoTmp->offset = page->pageOffset;
            pInfoTmp->parentSlotIdx = slotIdx;
            pInfoTmp->parent = pNode;
            return lookupPage(ctx, pInfoTmp, nextPageOffset, levelIdx + 1, index, indexLen, leaf);
        }
    }
    return f;
}

static inline CCPageOffset_T createNewPageOffset(CCBPTreeIndexContext_S *ctx)
{
    if (ctx->freePageOffset > 0) {
        CCPageOffset_T freePageOffset = ctx->freePageOffset;
        CCBuffer *buffer = ctx->fileMap->createMapBuffer(freePageOffset, ctx->pageSize, CC_F_RDWR);
        if (buffer) {
            buffer->seekTo(CCPageHeaderOffNext);
            CCPageOffset_T next = buffer->readLittleEndian64();
            memset(buffer->bytes() + CCPageHeaderOffIndex, 0, ctx->pageSize - CCPageHeaderOffIndex);
            ctx->fileMap->destroyMapBuffer(buffer);
            ctx->freePageOffset = next;
            ctx->headBuffer->seekTo(CCHeaderOffFreePageOffset);
            ctx->headBuffer->writeLittleEndian64(ctx->freePageOffset);
            return freePageOffset;
        }
    }
    CCPageOffset_T newPageOffset = ctx->contentSize;
    ctx->contentSize += ctx->pageSize;
    ctx->headBuffer->seekTo(CCHeaderOffContentSize);
    ctx->headBuffer->writeLittleEndian64(ctx->contentSize);
//    CCBuffer *buffer = ctx->fileMap->createMapBuffer(newPageOffset, ctx->pageSize, CC_F_RDWR);
//    ctx->fileMap->destroyMapBuffer(buffer);
    return newPageOffset;
}

static inline void addFreePageOffset(CCBPTreeIndexContext_S *ctx, CCPageOffset_T freeOffset)
{
    if (freeOffset <= 0) {
        return;
    }
    CCPageOffset_T freePageOffset = ctx->freePageOffset;
    CCBuffer *buffer = ctx->fileMap->createMapBuffer(freeOffset, ctx->pageSize, CC_F_RDWR);
    if (buffer == nullptr) {
        return;
    }
    buffer->seekTo(CCPageHeaderOffNext);
    buffer->writeLittleEndian64(freePageOffset);
    ctx->fileMap->destroyMapBuffer(buffer);
    ctx->freePageOffset = freeOffset;
    ctx->headBuffer->seekTo(CCHeaderOffFreePageOffset);
    ctx->headBuffer->writeLittleEndian64(ctx->freePageOffset);
}

static inline CCPageCount_T getPageIdxFromNodeIdx(CCBPTreeIndexContext_S *ctx, CCPage *page, CCNodeCount_T nodeIdx)
{
    CCPageCount_T pageIdx = 0;
    PCCArray_S subPageArray = page->subPageArray;
    CCPageCount_T pageCnt = CCArrayGetCount(subPageArray);
    if (pageCnt == 1) {
        return 0;
    }
    for (pageIdx = 0; pageIdx < pageCnt; ++pageIdx) {
//        CCSubPage *sub = &page->subPageList[pageIdx];
        CCSubPage *sub = (CCSubPage*)CCArrayGetValueAtIndex(subPageArray, pageIdx);
        if (nodeIdx >= sub->sIdx && nodeIdx <= sub->eIdx) {
            return pageIdx;
        }
    }
    return pageIdx;
}

static inline bool ensureSubPageRemSize(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCPageSize_T needSize, CCNodeCount_T maxMoveIdx, CCPageSize_T newPagePrevFreeSize)
{
    CCPageSize_T pageSize = ctx->pageSize;
    PCCArray_S subPageArray = page->subPageArray;
//    CCSubPage *sub = &page->subPageList[subPageIdx];
    CCSubPage *sub = (CCSubPage*)CCArrayGetValueAtIndex(subPageArray, subPageIdx);
    CCPageOffset_T subOffset = sub->offset;
    if (sub->remSize >= needSize) {
        return true;
    }
    CCPageCount_T endIdx = sub->eIdx;
    //2.1计算需要从后面copy几个index，value出去
    CCPageSize_T cpSize = 0;
    CCPageSize_T addSize = 0;
    CCNodeCount_T copyItemCnt = 0;
    CCPageSize_T remSize = sub->remSize;
    
    PCCArray_S pageNodeArrray = page->pageNodeArray;
    
    while (remSize < needSize && endIdx >= maxMoveIdx) {
        CCPageNode *pageNode = (CCPageNode*)CCArrayGetValueAtIndex(pageNodeArrray, endIdx);
//        addSize = CCPAGE_NODE_SIZE(page->pageNodeList[endIdx]);
        addSize = CCPAGE_NODE_SIZE(pageNode);
        cpSize += addSize;
        remSize += addSize;
        --endIdx;
        ++copyItemCnt;
    }
//    endIdx = endIdx + 1;
    CCPageNode *pageNode = (CCPageNode*)CCArrayGetValueAtIndex(pageNodeArrray, endIdx + 1);
//    CCPageSize_T copyFrom =  CCPAGE_NODE_OFFSET(page->pageNodeList[endIdx + 1]);
    CCPageSize_T copyFrom = CCPAGE_NODE_OFFSET(pageNode);
    CCPageSize_T newSize = cpSize;
    CCPageSize_T nextSubIndexOffset = 0;
    if (remSize < needSize) {
        newSize = cpSize + newPagePrevFreeSize;
        nextSubIndexOffset = newPagePrevFreeSize;
    }
    CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
    bool result = false;
    bool createNewPage = true;
    CCPageOffset_T nextOffset = 0;
    CCPageCount_T nextSubPageIdx = subPageIdx + 1;
    CCPageCount_T pageCnt = CCArrayGetCount(subPageArray);
    if (nextSubPageIdx < pageCnt) {
//        CCSubPage *nextSub = &page->subPageList[nextSubPageIdx];
        CCSubPage *nextSub = (CCSubPage*)CCArrayGetValueAtIndex(subPageArray, nextSubPageIdx);
        CCPageSize_T nextSubPageRemSize = nextSub->remSize;
        if (nextSubPageRemSize > newSize) {
            createNewPage = false;
//            CCBuffer *nextBuffer = ctx->fileMap->createMapBuffer(nextSub->offset, pageSize, CC_F_RDWR);
            CCPAGE_DEC_BUFFER(nextSub->offset, nextBuffer, nextBufferType);
            if (!nextBuffer) {
                goto ENSURE_SUBPAGE_REMSIZE_END;
            }
            uint8_t *ptr = nextBuffer->bytes() + CCPageHeaderOffIndex;
            memmove(ptr + newSize, ptr, pageSize - nextSub->remSize - CCPageHeaderOffIndex);
            memset(ptr, 0, newSize);
            nextBuffer->seekTo(CCPageHeaderOffIndex + nextSubIndexOffset);
            nextBuffer->writeBuffer(buffer->bytes() + copyFrom, cpSize);
            memset(buffer->bytes() + copyFrom, 0, cpSize);
//            ctx->fileMap->destroyMapBuffer(nextBuffer);
            CCPAGE_FRE_BUFFER(nextBuffer,nextBufferType);
            nextSub->remSize -= newSize;
            nextSub->sIdx -= copyItemCnt;
        }
        else {
            nextOffset = nextSub->offset;
        }
    }
    sub->eIdx = endIdx;
    sub->remSize = remSize;
    
    if (createNewPage) {
        CCPageOffset_T nextNewPageOffset = createNewPageOffset(ctx);
        //修改当前subPage的next
        buffer->seekTo(CCPageHeaderOffNext);
        buffer->writeLittleEndian64(nextNewPageOffset);
        
        //更改新的subPage的next
//        CCBuffer *nextBuffer = ctx->fileMap->createMapBuffer(nextNewPageOffset, pageSize, CC_F_RDWR);
        CCPAGE_DEC_BUFFER(nextNewPageOffset, nextBuffer, nextBufferType);
        if (!nextBuffer) {
            goto ENSURE_SUBPAGE_REMSIZE_END;
        }
        
        nextBuffer->seekTo(CCPageHeaderOffNext);
        nextBuffer->writeLittleEndian64(nextOffset);
        nextBuffer->seekTo(CCPageHeaderOffIndex + nextSubIndexOffset);
        nextBuffer->writeBuffer(buffer->bytes() + copyFrom, cpSize);
        memset(buffer->bytes() + copyFrom, 0, cpSize);
//        ctx->fileMap->destroyMapBuffer(nextBuffer);
        CCPAGE_FRE_BUFFER(nextBuffer, nextBufferType);
        
//        calSubPageList(ctx, page, false);
//        if (nextSubPageIdx < page->pageCnt) {
//            CCSubPage_S *ptr = &page->subPageList[nextSubPageIdx];
//            memmove(ptr + 1, ptr, (page->pageCnt - nextSubPageIdx + 1) * sizeof(CCSubPage_S));
//        }
//        ++page->pageCnt;
//        page->subPageList[nextSubPageIdx].sIdx = endIdx + 1;
//        page->subPageList[nextSubPageIdx].eIdx = endIdx + copyItemCnt;
//        page->subPageList[nextSubPageIdx].remSize = pageSize - newSize - CCPageHeaderOffIndex;
//        page->subPageList[nextSubPageIdx].offset = nextNewPageOffset;
        
        
        resizeSubPageArray(ctx, page, false);
        CCSubPage *subPage = (CCSubPage*)calloc(1, sizeof(CCSubPage));
        if (!subPage) {
            goto  ENSURE_SUBPAGE_REMSIZE_END;
        }
        subPage->sIdx = endIdx + 1;
        subPage->eIdx = endIdx + copyItemCnt;
        subPage->remSize = pageSize - newSize - CCPageHeaderOffIndex;
        subPage->offset = nextNewPageOffset;
        CCArrayInsertValueAtIndex(subPageArray, nextSubPageIdx, (uintptr_t)subPage);
    }

    result = true;
ENSURE_SUBPAGE_REMSIZE_END:
    CCPAGE_FRE_BUFFER(buffer, bufType);
    return result;
}

static void insertIndexIntoNotFullPage(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCNodeCount_T nodeIdx,CCIndexValue_T prevIndexValue, CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    PCCArray_S pageNodeArray = page->pageNodeArray;
    CCNodeCount_T pageNodeCnt = CCArrayGetCount(pageNodeArray);
    if (pageNodeCnt >= ctx->pageNodeCnt) {
        return;
    }
    
    PCCArray_S subPageArray = page->subPageArray;
//    CCSubPage *sub = &page->subPageList[subPageIdx];
    CCSubPage *sub = (CCSubPage*)CCArrayGetValueAtIndex(subPageArray, subPageIdx);
    CCPageCount_T endIdx = sub->eIdx;
    CCPageOffset_T offset = sub->offset;
    CCPageSize_T needSize = indexLen + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES;
    
    ensureSubPageRemSize(ctx, page, subPageIdx, needSize, nodeIdx, needSize);
    bool remSizeEnough = true;
    if (sub->remSize < needSize) {
        remSizeEnough = false;
//        offset = page->subPageList[subPageIdx + 1].offset;
        offset = ((CCSubPage*)CCArrayGetValueAtIndex(subPageArray, subPageIdx + 1))->offset;
    }
    
    CCPAGE_DEC_BUFFER(offset, buffer, bufType);
    
    if (offset == ctx->rootOffset) {
        if (ctx->root->pageType == CCPageTypeNone) {
            ctx->root->pageType = (CCPageType_E)(CCPageTypeRoot | CCPageTypeLeaf);
            buffer->seekTo(CCPageHeaderOffPType);
            buffer->writeByte(ctx->root->pageType);
        }
    }
    
    if (prevIndexValue > 0 && (pageNodeCnt == 0 || nodeIdx == 0)) {
        if (nodeIdx == 0 && indexValue == 0) {
            indexValue = page->firstChild;
        }
        page->firstChild = prevIndexValue;
        buffer->seekTo(CCPageHeaderOffFChild);
        buffer->writeLittleEndian64(prevIndexValue);
    }
    
    CCPageSize_T endOff = 0;
    if (remSizeEnough) {
        endIdx = sub->eIdx;
//        endOff = endIdx == 0 ? CCPageHeaderOffIndex : CCPAGE_NODE_END_OFFSET(page->pageNodeList[endIdx]);
        endOff = endIdx == 0 ? CCPageHeaderOffIndex : CCPAGE_NODE_END_OFFSET((CCPageNode*)CCArrayGetValueAtIndex(pageNodeArray, endIdx));
        if (endIdx >= nodeIdx && endIdx > 0) {
//            CCPageSize_T offsetTmp = CCPAGE_NODE_OFFSET(page->pageNodeList[nodeIdx]);
            CCPageSize_T offsetTmp = CCPAGE_NODE_OFFSET((CCPageNode*)CCArrayGetValueAtIndex(pageNodeArray, nodeIdx));
            uint8_t *ptr = buffer->bytes() + offsetTmp;
            CCPageSize_T move = endOff - offsetTmp;
            memmove(ptr + needSize, ptr, move);
            buffer->seekTo(offsetTmp);
        }
        else {
            buffer->seekTo(endOff);
        }
        buffer->writeByte(indexLen);
        buffer->writeBuffer(index, indexLen);
        buffer->writeLittleEndian64(indexValue);
    }
    else {
        endOff = CCPageHeaderOffIndex;
        buffer->seekTo(CCPageHeaderOffIndex);
        buffer->writeByte(indexLen);
        buffer->writeBuffer(index, indexLen);
        buffer->writeLittleEndian64(indexValue);
    }

    CCPAGE_FRE_BUFFER(buffer, bufType);
    
    if (page == ctx->root) {
        CCPageNode *insert = (CCPageNode*)calloc(1, sizeof(CCPageNode));
        if (!insert) {
            return;
        }
        insert->indexOffset = endOff;
        insert->indexSize = indexLen;
        insert->value = indexValue;
        CCArrayInsertValueAtIndex(pageNodeArray, nodeIdx, (uintptr_t)insert);
    }
}

static int insertIndex(CCBPTreeIndexContext_S *ctx, CCPageOffset_T pageOffset, CCIndexValue_T prevIndexValue, CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue, bool leaf)
{
    struct CCPageFind find = lookupPage(ctx, nullptr, pageOffset, 0, index, indexLen, leaf);
    if (find.fcd == CCFindCodeExists) {
        return find.fcd;
    }
    if (find.page == nullptr) {
        return -1;
    }
    CCPage_S *page = find.page;
    CCPageSize_T pageSize = ctx->pageSize;
    
    PCCArray_S pageNodeArray = page->pageNodeArray;
    CCNodeCount_T nodeCnt = CCArrayGetCount(pageNodeArray);
    if (nodeCnt < ctx->pageNodeCnt) {
        insertIndexIntoNotFullPage(ctx, page, find.subPageIdx, find.nodeIdx, prevIndexValue, index, indexLen, indexValue);
    }
    else {
        //进行分裂
        bool isLeafPage = (page->pageType & CCPageTypeLeaf) == CCPageTypeLeaf;
        CCNodeCount_T mid = ctx->pageNodeCnt >> 1;
        CCNodeCount_T prevCnt = mid;
        CCNodeCount_T insertIntoParentIdx = prevCnt;
        bool copyFromPrev = false;
        bool isInsertPrev = false;
        //1.找出分裂的位置
        /*
         *如果是奇数个，偶数个时进行分裂
         *1、如果是叶子节点分裂的话，两边各一半，将左边最大的index copy到父节点
         *2、如果是索引节点分裂，左边pageNodeCnt/2-1，右边pageNodeCnt/2，将左边最大的index移动到父节点
         */
        if (IS_ODD_NUM(ctx->pageNodeCnt)) {
            if (find.nodeIdx < mid) {
                isInsertPrev = true;
            }
            else {
                prevCnt += 1;
            }
            insertIntoParentIdx = prevCnt - 1;
            copyFromPrev = true;
        }
        else {
            /*
             *如果是偶数个，奇数时进行分裂
             *1、如果是叶子节点分裂的话，左边pageNodeCnt/2，右边是ctx->pageNodeCnt - pageNodeCnt/2,将右边的最小索引copy到父节点
             *2、如果是索引节点分裂的话，左右两边都是pageNodeCnt/2，将中间的节点移动到父节点中
             */
            if (find.nodeIdx < mid) {
                prevCnt -= 1;
                isInsertPrev = true;
            }
            insertIntoParentIdx = prevCnt;
        }
        
        //2. 计算父类的offset
        CCPageOffset_T parent = 0;
        bool newParentOffset = false;
        if (page->pNode) {
            parent = page->pNode->offset;
        }
        if (parent == 0) {
            newParentOffset = true;
            parent = createNewPageOffset(ctx);
        }

        //3. 修改当前的page
        bool deleteBuffer = false;
        CCBuffer *buffer = ctx->rootBuffer;
        if (page->pageOffset != ctx->rootOffset) {
            ctx->fileMap->update(page->pageOffset, pageSize);
            buffer = new CCBuffer(ctx->fileMap->ptr(), pageSize);
            deleteBuffer = true;
        }
        if (buffer == nullptr) {
            if (newParentOffset) {
                addFreePageOffset(ctx, parent);
            }
            return -1;
        }
        //3.1修改pageType
        //如果pageType就是root，那就是修改为index
        if (page->pageType == CCPageTypeRoot) {
            page->pageType = CCPageTypeIndex;
            buffer->seekTo(CCPageHeaderOffPType);
            buffer->writeByte(page->pageType);
        }
        //如果pageType包含root，那么这个page就即使root也是leaf(叶子)，那么就将该page修改leaf page
        else if (page->pageType & CCPageTypeRoot) {
            page->pageType = CCPageTypeLeaf;
            buffer->seekTo(CCPageHeaderOffPType);
            buffer->writeByte(page->pageType);
        }
        
        //3.2修改brother
        bool newBrotherOffset = false;
        CCPageOffset_T brother = 0;
        CCPageOffset_T brotherNextOffset = 0;
        CCPageCount_T nextSubPageIdx = getPageIdxFromNodeIdx(ctx, page, prevCnt);
//        CCSubPage *split = &page->subPageList[nextSubPageIdx];
        CCSubPage  *split = CCSUBPAGE_AT_IDX(page,nextSubPageIdx);
        if (split->sIdx == prevCnt) {
            brother = split->offset;
        }
        else {
            newBrotherOffset = true;
            brother = createNewPageOffset(ctx);
//            if (nextSubPageIdx + 1 < page->pageCnt) {
//                brotherNextOffset = page->subPageList[nextSubPageIdx + 1].offset;
//            }
            if (nextSubPageIdx + 1 < CCArrayGetCount(page->subPageArray)) {
//                brotherNextOffset = page->subPageList[nextSubPageIdx + 1].offset;
                brotherNextOffset = CCSUBPAGE_AT_IDX(page, nextSubPageIdx + 1)->offset;
            }
        }
        if (isLeafPage) {
            buffer->seekTo(CCPageHeaderOffBrother);
            buffer->writeLittleEndian64(brother);
        }
        
        //3.3修改next
        CCPageOffset_T prevOffset = 0;
        CCSubPage *prevSubPage = nullptr;
        if (newBrotherOffset) {
            prevOffset = split->offset;
            prevSubPage = split;
        }
        else {
            CCPageCount_T prevSubPageIdx = 0;
            if (nextSubPageIdx >= 1) {
                prevSubPageIdx = nextSubPageIdx - 1;
            }
//            CCSubPage *prev = &page->subPageList[prevSubPageIdx];
            CCSubPage *prev = CCSUBPAGE_AT_IDX(page, prevSubPageIdx);
            prevOffset = prev->offset;
            prevSubPage = prev;
        }
        
        CCBuffer *prevBuffer = nullptr;
        bool destroyPrevBuffer = false;
        if (prevOffset != page->pageOffset) {
            prevBuffer = ctx->fileMap->createMapBuffer(prevOffset, pageSize, CC_F_RDWR);
            destroyPrevBuffer = true;
        }
        else {
            prevBuffer = buffer;
        }
        if (prevBuffer == nullptr) {
            if (newBrotherOffset) {
                addFreePageOffset(ctx, brother);
            }
            if (newParentOffset) {
                addFreePageOffset(ctx, parent);
            }
            if (deleteBuffer && buffer) {
                delete buffer;
            }
            return -1;
        }
        prevBuffer->seekTo(CCPageHeaderOffNext);
        prevBuffer->writeLittleEndian64(0);
        
        //3.4 copy 需要插入到parent的index，value
        bool useCurIndex = false;
        CCPageSize_T insertIntoParentIndexSize = 0;
        if (insertIntoParentIdx == find.nodeIdx) {
            useCurIndex = true;
            insertIntoParentIndexSize = indexLen + CCPAGE_NODE_IDX_VALUE_BYTES;
        }
        else {
//            insertIntoParentIndexSize = page->pageNodeList[insertIntoParentIdx].indexSize + CCPAGE_NODE_IDX_VALUE_BYTES;
            insertIntoParentIndexSize = CCPAGE_NODE_AT_IDX(page,insertIntoParentIdx)->indexSize + CCPAGE_NODE_IDX_VALUE_BYTES;
        }
        CCMutableBuffer insertIntoParentIndex = CCMutableBuffer(insertIntoParentIndexSize);
        if (useCurIndex) {
            insertIntoParentIndex.writeBuffer(index, indexLen);
            insertIntoParentIndex.writeLittleEndian64(indexValue);
        }
        
        //4.修改brother的page
        //索引节点第一个孩子节点
        CCPageOffset_T indexPageFirstChild = indexValue;
        CCBuffer *brotherBuffer = ctx->fileMap->createMapBuffer(brother, ctx->pageSize, CC_F_RDWR);
        if (brotherBuffer == nullptr) {
            if (newBrotherOffset) {
                addFreePageOffset(ctx, brother);
            }
            if (newParentOffset) {
                addFreePageOffset(ctx, parent);
            }
            if (deleteBuffer && buffer) {
                delete buffer;
            }
            if (destroyPrevBuffer && prevBuffer) {
                ctx->fileMap->destroyMapBuffer(prevBuffer);
            }
            return -1;
        }
        if (newBrotherOffset) {
            //4.1 计算需要copy到insertIntoParentIndex的数据
            CCPageCount_T cpIdx = prevCnt;
            if (useCurIndex == false) {
//                uint8_t *ptr = prevBuffer->bytes() + page->pageNodeList[insertIntoParentIdx].indexOffset;
                uint8_t *ptr = prevBuffer->bytes() + CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx)->indexOffset;
                insertIntoParentIndex.read(ptr, insertIntoParentIndexSize);
                if (!isLeafPage) {
                    cpIdx = prevCnt + 1;
                    memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, insertIntoParentIndexSize + CCPAGE_NODE_IDX_SIZE_BYTES);
                }
                CCPageOffset_T off = insertIntoParentIndexSize - CCPAGE_NODE_IDX_VALUE_BYTES;
                insertIntoParentIndex.seekTo(off);
                indexPageFirstChild = insertIntoParentIndex.readLittleEndian64();
                insertIntoParentIndex.seekTo(off);
                insertIntoParentIndex.writeLittleEndian64(brother);
            }
            
            brotherBuffer->bzero();
            brotherBuffer->seekTo(CCPageHeaderOffNext);
            brotherBuffer->writeLittleEndian64(brotherNextOffset);
            
            //判断是否有数据需要copy到brotherBuffer
            if (cpIdx <= prevSubPage->eIdx) {
//                CCPageSize_T sOff = CCPAGE_NODE_OFFSET(page->pageNodeList[cpIdx]);
                CCPageSize_T sOff = CCPAGE_NODE_OFFSET(CCPAGE_NODE_AT_IDX(page, cpIdx));
//                CCPageSize_T eOff = CCPAGE_NODE_END_OFFSET(page->pageNodeList[split->eIdx]);
                CCPageSize_T eOff = CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, split->eIdx));
                if (eOff > sOff) {
                    CCPageSize_T cp = eOff - sOff;
                    uint8_t *ptr = prevBuffer->bytes() + sOff;
                    brotherBuffer->seekTo(CCPageHeaderOffIndex);
                    brotherBuffer->read(ptr, cp);
                    memset(ptr, 0, cp);
                }
            }
        }
        else {
            //如果不是新的brother，那就是原来的split的subPage
            if (useCurIndex == false) {
                uint8_t *ptr = nullptr;
                if (copyFromPrev) {
//                    ptr = prevBuffer->bytes() + page->pageNodeList[insertIntoParentIdx].indexOffset;
                    ptr = prevBuffer->bytes() + CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx)->indexOffset;
                }
                else {
//                    ptr = brotherBuffer->bytes() + page->pageNodeList[insertIntoParentIdx].indexOffset;
                    ptr = brotherBuffer->bytes() + CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx)->indexOffset;
                }
                insertIntoParentIndex.read(ptr, insertIntoParentIndexSize);
                if (!isLeafPage) {
                    memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, insertIntoParentIndexSize + CCPAGE_NODE_IDX_SIZE_BYTES);
                    if (!copyFromPrev) {
                        //将后面的往前面移动
                        ptr = brotherBuffer->bytes() + CCPageHeaderOffIndex;
                        if (insertIntoParentIdx < split->eIdx) {
//                            CCPageSize_T cpSize = CCPAGE_NODE_END_OFFSET(page->pageNodeList[split->eIdx]) - CCPAGE_NODE_END_OFFSET(page->pageNodeList[insertIntoParentIdx]);
                            CCPageSize_T cpSize = CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, split->eIdx)) - CCPAGE_NODE_END_OFFSET(CCPAGE_NODE_AT_IDX(page, insertIntoParentIdx));
                            memmove(ptr, ptr + insertIntoParentIndexSize, cpSize);
                            memset(ptr + cpSize, 0, ctx->pageSize - cpSize);
                        }
                    }
                }
                CCPageOffset_T off = insertIntoParentIndexSize - CCPAGE_NODE_IDX_VALUE_BYTES;
                insertIntoParentIndex.seekTo(off);
                indexPageFirstChild = insertIntoParentIndex.readLittleEndian64();
                insertIntoParentIndex.seekTo(off);
                insertIntoParentIndex.writeLittleEndian64(brother);
            }
        }
        if (isLeafPage == false) {
            brotherBuffer->seekTo(CCPageHeaderOffFChild);
            brotherBuffer->writeLittleEndian64(indexPageFirstChild);
        }
        brotherBuffer->seekTo(CCPageHeaderOffBrother);
        brotherBuffer->writeLittleEndian64(page->brother);
        brotherBuffer->seekTo(CCPageHeaderOffPType);
        brotherBuffer->writeByte(page->pageType);
        page->brother = brother;
        
        if (deleteBuffer && buffer) {
            delete buffer;
        }
        if (brotherBuffer) {
            ctx->fileMap->destroyMapBuffer(brotherBuffer);
        }
        if (destroyPrevBuffer && prevBuffer) {
            ctx->fileMap->destroyMapBuffer(prevBuffer);
        }
        
        if (isLeafPage || (isLeafPage == false && useCurIndex == false)) {
            //在前半段插入
            if (isInsertPrev) {
                //TODO:
//                page->nodeCnt = prevCnt;
//                page->pageCnt = nextSubPageIdx;
                CCPageCount_T subPageIdx = getPageIdxFromNodeIdx(ctx, page, find.nodeIdx);
                insertIndexIntoNotFullPage(ctx, page, subPageIdx, find.nodeIdx, 0, index, indexLen, indexValue);
            }
            else {
                //在后半段插入
                //TODO:
//                CCNodeCount_T nodeCnt = page->nodeCnt - prevCnt;
//                CCPageCount_T pageCnt = page->pageCnt - nextSubPageIdx;
//                memmove(page->pageNodeList, page->pageNodeList + prevCnt, nodeCnt * sizeof(CCPageNode_S));
//                memset(page->pageNodeList + nodeCnt, 0, prevCnt * sizeof(CCPageNode_S));
//
//                memmove(page->subPageList, page->subPageList + nextSubPageIdx, pageCnt * sizeof(CCSubPage_S));
//                memset(page->subPageList + pageCnt, 0, nextSubPageIdx * sizeof(CCSubPage_S));
//
//                page->nodeCnt = nodeCnt;
//                page->pageCnt = pageCnt;
                CCPageCount_T subPageIdx = getPageIdxFromNodeIdx(ctx, page, find.nodeIdx) - nextSubPageIdx;
                insertIndexIntoNotFullPage(ctx, page, subPageIdx, find.nodeIdx, 0, index, indexLen, indexValue);
            }
            
            //5. 如果分裂的是root节点，修改ctx的root，rootOffset，rootBuffer
            if (page->pageOffset == ctx->rootOffset) {
                ctx->rootOffset = parent;
                ctx->headBuffer->seekTo(CCHeaderOffRootOffset);
                ctx->headBuffer->writeLittleEndian64(ctx->rootOffset);
                readRootPage(ctx);
            }
            
            //在父节点中插入
            if (useCurIndex) {
                insertIndex(ctx, parent, page->pageOffset, index, indexLen, brother, NO);
            }
            else {
                uint8_t *indexTmp = insertIntoParentIndex.bytes();
                insertIndex(ctx, parent, page->pageOffset, indexTmp, insertIntoParentIndexSize - CCPAGE_NODE_IDX_VALUE_BYTES, brother, NO);
            }
        }
        else {
            //userCurIndex为true,且leafPage为false
            //5. 如果分裂的是root节点，修改ctx的root，rootOffset，rootBuffer
            if (page->pageOffset == ctx->rootOffset) {
                ctx->rootOffset = parent;
                ctx->headBuffer->seekTo(CCHeaderOffRootOffset);
                ctx->headBuffer->writeLittleEndian64(ctx->rootOffset);
                readRootPage(ctx);
            }
            insertIndex(ctx, parent, page->pageOffset, index, indexLen, brother, NO);
        }
    }
    return 0;
}

//返回left的brother的offset，通过rightBrother返回rightBrother
static CCPageOffset_T findBrother(CCBPTreeIndexContext_S *ctx, CCPageOffset_T parent, CCNodeCount_T slotIdx, CCPageOffset_T *rightBrother, CCPage_S **ptr_parentPage)
{
    if (parent == 0) {
        return 0;
    }
    CCPageOffset_T lBrother = 0;
    CCPageOffset_T rBrother = 0;
    CCPage *parentPage = ctx->root;
    CCPAGE_DEC_BUFFER(parent, buffer, bufType)
    if (parent != ctx->rootOffset) {
        parentPage = readPage(ctx, parent, true, true);
    }
//    CCNodeCount_T cnt = parentPage->nodeCnt;
    CCNodeCount_T cnt = CCNODE_CNT(parentPage);
    if (slotIdx == 0) {
        lBrother = 0;//parentPage->firstChild;
        if (cnt > 0) {
//            rBrother = parentPage->pageNodeList[0].value;
            rBrother = CCPAGE_NODE_AT_IDX(parentPage, 0)->value;
        }
    }
    else {
        CCNodeCount_T lIdx = slotIdx - 1;
        if (lIdx == 0) {
            lBrother = parentPage->firstChild;
        }
        else if (lIdx > 0 && lIdx <= cnt) {
//            lBrother = parentPage->pageNodeList[lIdx - 1].value;
            lBrother = CCPAGE_NODE_AT_IDX(parentPage, lIdx - 1)->value;
        }
        
        if (slotIdx >= 0 && slotIdx < cnt) {
//            rBrother = parentPage->pageNodeList[slotIdx].value;
            rBrother = CCPAGE_NODE_AT_IDX(parentPage, slotIdx)->value;
        }
    }
    CCPAGE_FRE_BUFFER(buffer, bufType);
    if (rightBrother) {
        *rightBrother = rBrother;
    }
    
    if (ptr_parentPage) {
        *ptr_parentPage = parentPage;
    }
    else {
        if (parentPage != ctx->root) {
            freePage(ctx, parentPage);
        }
    }
    return lBrother;
}

static inline bool updateIndexFromPage(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCNodeCount_T nodeIdx, CCIndex_T *index, CCIndexSize_T indexSize, CCIndexValue_T indexValue, bool updateIndexValue)
{
    CCPageSize_T pageSize = ctx->pageSize;
//    CCSubPage *sub = &page->subPageList[subPageIdx];
    CCSubPage *sub = CCSUBPAGE_AT_IDX(page, subPageIdx);
    CCPageOffset_T subOffset = sub->offset;
//    CCIndexSize_T indexSizeOld = page->pageNodeList[nodeIdx].indexSize;
    CCIndexSize_T indexSizeOld = CCPAGE_NODE_AT_IDX(page, nodeIdx)->indexSize;
//    CCPageSize_T indexOffset = page->pageNodeList[nodeIdx].indexOffset;
    CCPageSize_T indexOffset = CCPAGE_NODE_AT_IDX(page, nodeIdx)->indexOffset;
    
    if (indexSizeOld == indexSize) {
        CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
        if (buffer == nullptr) {
            return false;
        }

        buffer->seekTo(indexOffset);
        buffer->writeBuffer(index, indexSize);
        if (updateIndexValue) {
            buffer->writeLittleEndian64(indexValue);
        }
        CCPAGE_FRE_BUFFER(buffer, bufType);
    }
    else if (indexSizeOld > indexSize) {
        CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
        if (buffer == nullptr) {
            return false;
        }
        CCPageSize_T diff = indexSizeOld - indexSize;
        CCPageSize_T off = indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES;
        CCPageSize_T endOff = indexOffset + indexSizeOld + CCPAGE_NODE_IDX_VALUE_BYTES;
        uint8_t *endPtr = buffer->bytes() + endOff;
        CCIndexValue_T indexValueTmp = indexValue;
        if (!updateIndexValue) {
            buffer->seekTo(off + CCPAGE_NODE_IDX_SIZE_BYTES + indexSizeOld);
            indexValueTmp = buffer->readLittleEndian64();
            uint8_t *ptr = buffer->bytes() + off;
            memset(ptr, 0, CCPAGE_NODE_IDX_SIZE_BYTES + indexSizeOld + CCPAGE_NODE_IDX_VALUE_BYTES);
        }
        buffer->seekTo(off);
        buffer->writeByte(indexSize);
        buffer->writeBuffer(index, indexSize);
        buffer->writeLittleEndian64(indexValueTmp);
        CCPageSize_T mvCnt = pageSize - sub->remSize - endOff;
        if (mvCnt > 0) {
            memmove(endPtr - diff, endPtr, mvCnt);
            memset(endPtr + mvCnt - diff, 0, diff);
        }
        
        CCPAGE_FRE_BUFFER(buffer, bufType);
    }
    else {
        CCPageSize_T diff = indexSize - indexSizeOld;
        CCPageSize_T needSize = CCPAGE_NODE_IDX_SIZE_BYTES + indexSize + CCPAGE_NODE_IDX_VALUE_BYTES;
        ensureSubPageRemSize(ctx, page, subPageIdx, needSize, nodeIdx, diff);
        bool remSizeEnough = true;
        if (sub->remSize < needSize) {
            remSizeEnough = false;
//            subOffset = page->subPageList[nodeIdx + 1].offset;
            subOffset = CCSUBPAGE_AT_IDX(page, nodeIdx + 1)->offset;
        }
        
        CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
        if (buffer == nullptr) {
            return false;
        }
        
        CCIndexValue_T indexValueTmp = indexValue;
        
        if (remSizeEnough) {
            if (!updateIndexValue) {
                buffer->seekTo(indexOffset + indexSizeOld);
                indexValueTmp = buffer->readLittleEndian64();
            }
            CCPageSize_T endOff = pageSize - sub->remSize;
            CCPageSize_T nodeEndOff = indexOffset + indexSizeOld + CCPAGE_NODE_IDX_VALUE_BYTES;
            uint8_t *ptr = nullptr;
            if (endOff > nodeEndOff) {
                ptr = buffer->bytes() + nodeEndOff;
                memmove(ptr + diff, ptr, endOff - nodeEndOff);
            }
            ptr = buffer->bytes() + indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES;
            memset(ptr, 0, CCPAGE_NODE_IDX_SIZE_BYTES + indexSize + CCPAGE_NODE_IDX_VALUE_BYTES);
            buffer->seekTo(indexOffset - CCPAGE_NODE_IDX_SIZE_BYTES);
            buffer->writeByte(indexSize);
            buffer->writeBuffer(index, indexSize);
            buffer->writeLittleEndian64(indexValueTmp);
        }
        else {
            buffer->seekTo(CCPageHeaderOffIndex);
            buffer->writeByte(indexSize);
            buffer->writeBuffer(index, indexSize);
            buffer->writeLittleEndian64(indexValueTmp);
        }
        CCPAGE_FRE_BUFFER(buffer, bufType);
    }
    return 0;
}

static int updateIndex(CCBPTreeIndexContext_S *ctx, CCPageOffset_T pageOffset, CCIndex_T *index, CCIndexSize_T indexSize, CCIndexValue_T indexValue, bool leaf)
{
    struct CCPageFind find = lookupPage(ctx, nullptr, pageOffset, 0, index, indexSize, leaf);
    if (find.fcd != CCFindCodeExists) {
        //表示不存在
        return CCFindCodeOK;
    }
    if (find.page == nullptr) {
        return CCFindCodeOK;
    }
    CCPage_S *page = find.page;
    
    updateIndexFromPage(ctx, page, find.subPageIdx, find.nodeIdx, index, indexSize, indexValue, true);
    return CCFindCodeOK;
}

static inline bool deleteIndexFromPage(CCBPTreeIndexContext_S *ctx, CCPage *page, CCPageCount_T subPageIdx, CCNodeCount_T nodeIdx)
{
    CCPageSize_T pageSize = ctx->pageSize;
//    CCSubPage *sub = &page->subPageList[subPageIdx];
    CCSubPage *sub = CCSUBPAGE_AT_IDX(page, subPageIdx);
    CCPageOffset_T subOffset = sub->offset;
    CCPAGE_DEC_BUFFER(subOffset, buffer, bufType);
    if (buffer == nullptr) {
        return false;
    }
    
    if (nodeIdx == 0) {
//        page->firstChild = page->pageNodeList[nodeIdx].value;
        page->firstChild = CCPAGE_NODE_AT_IDX(page, nodeIdx)->value;
        CCPAGE_DEC_BUFFER(page->pageOffset, pageBuffer, pageBufType);
        pageBuffer->seekTo(CCPageHeaderOffFChild);
        pageBuffer->writeLittleEndian64(page->firstChild);
        CCPAGE_FRE_BUFFER(pageBuffer, pageBufType);
    }
    
    CCPageNode *node = CCPAGE_NODE_AT_IDX(page, nodeIdx);
//    CCPageSize_T size = CCPAGE_NODE_SIZE(page->pageNodeList[nodeIdx]);
    CCPageSize_T size = CCPAGE_NODE_SIZE(node);
//    CCPageSize_T offset = CCPAGE_NODE_OFFSET(page->pageNodeList[nodeIdx]);
    CCPageSize_T offset = CCPAGE_NODE_OFFSET(node);
    CCPageSize_T endOffset = pageSize - sub->remSize;
    uint8_t *ptr = buffer->bytes() + offset;
    memset(ptr, 0, size);
    CCPageSize_T mvSize = endOffset - size - offset;
    if (mvSize > 0) {
        memmove(ptr, ptr + size, mvSize);
        memset(ptr + mvSize, 0, size);
    }
//    TODO:
//    --page->nodeCnt;
//    if (IS_ROOT_PAGE(page)) {
    CCArrayRemoveValueAtIndex(page->pageNodeArray, nodeIdx);
//    }
    CCPAGE_FRE_BUFFER(buffer, bufType);
    return true;
}

int deleteIndex(CCBPTreeIndexContext_S *ctx, CCPageOffset_T pageOffset, CCIndex_T *index, CCIndexSize_T indexLen, bool leaf)
{
    struct CCPageFind find = lookupPage(ctx, nullptr, pageOffset, 0, index, indexLen, leaf);
    if (find.fcd != CCFindCodeExists) {
        //表示不存在
        return CCFindCodeOK;
    }
    if (find.page == nullptr) {
        return CCFindCodeOK;
    }
    CCPage_S *page = find.page;
    CCNodeCount_T minCnt = (ctx->pageNodeCnt + 1)/2;
    if (CCNODE_CNT(page) > minCnt) {
        deleteIndexFromPage(ctx, page, find.subPageIdx, find.nodeIdx);
    }
    else {
        //1. 获取是否叶子节点
        bool isLeafPage = CCPAGE_IS_LEAF(page);
        //2. 获取父节点
        CCNodeCount_T slotIdx = 0;
        CCPageOffset_T parent = 0;
        bool findBrother = false;
        if (page->pNode) {
            parent = page->pNode->offset;
            slotIdx = page->pNode->parentSlotIdx;
            findBrother = true;
        }
        //3. 查找左右兄弟节点
        CCPageOffset_T rBrother = 0;
        CCPageOffset_T lBrother = 0;
        CCPage_S *parentPage = nullptr;
        if (findBrother) {
            lBrother = ::findBrother(ctx, parent, slotIdx, &rBrother, &parentPage);
        }
        //4. 删除当前节点
        deleteIndexFromPage(ctx, page, find.subPageIdx, find.nodeIdx);
        
        CCNodeCount_T parentNodeIdx = slotIdx > 0 ? slotIdx - 1 : 0;
        CCPageCount_T parentSubPageIdx = getPageIdxFromNodeIdx(ctx, parentPage, parentNodeIdx);
        //5. 判断兄弟节点的情况
        if (lBrother > 0) {
            CCPage *lPage = readPage(ctx, lBrother, true, true);
//            CCSubPage *lastSub = &lPage->subPageList[lPage->pageCnt - 1];
            CCSubPage *lastSub = (CCSubPage*)CCArrayGetLastValue(lPage->subPageArray);
            CCPAGE_DEC_BUFFER(lastSub->offset, lastBuffer, lastBufferType);
            //5.1如果兄弟节点有富裕，从兄弟节点借一个节点过来，否则和兄弟节点合并
            if (lPage->nodeCnt > minCnt) {
                CCNodeCount_T eIdx = lPage->nodeCnt - 1;
                /*
                 *5.1.1如果是叶子节点，
                 * (1)、将兄弟最后一个节点插入到本page第一位；
                 * (2)、将父节点的索引值更新为借过来兄弟节点的索引;
                 * (3)、将从兄弟节点借过来的节点清空
                 *5.1.2如果是索引节点
                 * (1)、将父节点的索引值更新到本page的第一位；
                 * (2)、将兄弟节点的最后一个节点索引替换父节点的索引
                 * (3)、将兄弟节点的最后一个节点清空
                 */
                if (isLeafPage) {
                    //(1)、将兄弟最后一个节点插入到本page第一位
                    CCIndexSize_T indexSize = lPage->pageNodeList[eIdx].indexSize;
                    CCPageSize_T indexOffset = lPage->pageNodeList[eIdx].indexOffset;
                    CCIndexValue_T indexValue = lPage->pageNodeList[eIdx].value;
                    uint8_t *ptr = lastBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, 0, 0, 0, ptr, indexSize, indexValue);
                    //(2)、更新父节点的index的值
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    //(3)、将兄弟节点借过来的index清空
                    memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, indexSize + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES);
                }
                else {
                    //(1)将父节点的索引值更新到本page的第一位；
                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    
                    CCIndexSize_T indexSize = parentPage->pageNodeList[parentNodeIdx].indexSize;
                    CCPageSize_T indexOffset = parentPage->pageNodeList[parentNodeIdx].indexOffset;
                    CCIndexValue_T indexValue = page->firstChild;
                    CCIndexValue_T prevIndexValue = lPage->pageNodeList[eIdx].value;
                    uint8_t *ptr = parentSubBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, 0, 0, prevIndexValue, ptr, indexSize, indexValue);
                    
                    //(2)将兄弟节点的最后一个节点索引替换父节点的索引
                    indexSize = lPage->pageNodeList[eIdx].indexSize;
                    indexOffset = lPage->pageNodeList[eIdx].indexOffset;
                    ptr = lastBuffer->bytes() + indexOffset;
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    //(3)将兄弟节点的最后一个节点清空
                    memset(ptr - CCPAGE_NODE_IDX_SIZE_BYTES, 0, indexSize + CCPAGE_NODE_IDX_SIZE_BYTES + CCPAGE_NODE_IDX_VALUE_BYTES);
                    
                    CCPAGE_FRE_BUFFER(parentSubBuffer, parentSubBufferType);
                }
                
                //如果最后一个page没有节点后,将最后的一个page回收
                if (lastSub->eIdx == lastSub->sIdx && lPage->pageCnt > 1) {
                    CCSubPage *last = &lPage->subPageList[lPage->pageCnt - 2];
                    CCPAGE_DEC_BUFFER(last->offset, lastTmp, lastType);
                    lastTmp->seekTo(CCPageHeaderOffNext);
                    lastTmp->writeLittleEndian64(0);
                    CCPAGE_FRE_BUFFER(lastTmp, lastType);
                    addFreePageOffset(ctx, last->offset);
                    --lPage->pageCnt;
                }
                --lastSub->eIdx;
            }
            else {
                //5.2 进行合并
                /*
                 *5.2.1如果是叶子节点，
                 * (1)、将当前节点和兄弟节点合并为一个page
                 * (2)、将父节点删除;
                 *5.2.2如果是索引节点
                 * (1)、将父节点下移
                 * (2)、将当前节点、父节点和兄弟节点合并为一个page
                 * (3)、将父节点清空
                 */
                
                if (isLeafPage) {
                    //(1)、将当前节点和兄弟节点合并为一个page
                    lastBuffer->seekTo(CCPageHeaderOffNext);
                    lastBuffer->writeLittleEndian64(page->pageOffset);
                    
                    CCPAGE_DEC_BUFFER(lPage->pageOffset, firstBuffer, firstBufferType);
                    firstBuffer->seekTo(CCPageHeaderOffBrother);
                    firstBuffer->writeLittleEndian64(page->brother);
                    CCPAGE_FRE_BUFFER(firstBuffer, firstBufferType);
                    //(2)、将父节点删除
                    CCIndexSize_T parentIndexSize = parentPage->pageNodeList[parentNodeIdx].indexSize;
                    CCPageSize_T parentIndexOffset = parentPage->pageNodeList[parentNodeIdx].indexOffset;

                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    CCIndex_T *parentIndex = parentSubBuffer->bytes() + parentIndexOffset;
                    deleteIndex(ctx, parent, parentIndex, parentIndexSize, NO);
                    CCPAGE_FRE_BUFFER(parentSubBuffer, parentSubBufferType);
                    //TODO：修改内存数据
                }
                else {
                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentBufferType);
                    
                    //(1)、将父节点下移；
                    CCIndexSize_T indexSize = parentPage->pageNodeList[parentNodeIdx].indexSize;
                    CCPageSize_T indexOffset = parentPage->pageNodeList[parentNodeIdx].indexOffset;
                    CCIndexValue_T indexValue = page->firstChild;
                    uint8_t *ptr = parentSubBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, lPage, lPage->pageCnt - 1, lPage->nodeCnt, 0, ptr, indexSize, indexValue);
                    
                    //(2)、将当前节点、父节点和兄弟节点合并为一个page
                    lastBuffer->seekTo(CCPageHeaderOffNext);
                    lastBuffer->writeLittleEndian64(page->pageOffset);
                    
                    //(3)、将父节点清空
                    deleteIndex(ctx, parent, ptr, indexSize, NO);

                    CCPAGE_FRE_BUFFER(parentSubBuffer, parentBufferType);

                    //TODO：修改内存数据
                }
                //如果父节点没有节点后，将父节点回收，当前节点为叶子节点和root节点
                if (parentPage->nodeCnt == 0) {
                    addFreePageOffset(ctx, parentPage->pageOffset);
                    lPage->pageType = (CCPageType_E)(CCPageTypeLeaf | CCPageTypeRoot);

                    CCPAGE_DEC_BUFFER(lPage->pageOffset, tmpBuf, tmpBufType);
                    tmpBuf->seekTo(CCPageHeaderOffPType);
                    tmpBuf->writeByte(lPage->pageType);
                    CCPAGE_FRE_BUFFER(tmpBuf, tmpBufType);
                }
            }
            CCPAGE_FRE_BUFFER(lastBuffer, lastBufferType);
            freePage(ctx, lPage);
        }
        else {
            //6.判断右兄弟节点的情况
            CCPage *rPage = readPage(ctx, rBrother, true, true);
            CCSubPage *firstSub = &rPage->subPageList[0];
            CCPAGE_DEC_BUFFER(firstSub->offset, firstBuffer, firstBufferType);
            //6.1如果兄弟节点有富裕，从兄弟节点借一个节点过来，否则和兄弟节点合并
            if (rPage->nodeCnt > minCnt) {
                CCNodeCount_T sIdx = 0;
                CCPageCount_T pIdx = page->pageCnt - 1;
                CCNodeCount_T nIdx = page->nodeCnt - 1;
                /*
                 *6.1.1如果是叶子节点，
                 * (1)、将兄弟第一个节点插入到本page最后一位；
                 * (2)、将父节点的索引值更新为借过来兄弟节点的索引;
                 * (3)、将从兄弟节点借过来的节点清空
                 *6.1.2如果是索引节点
                 * (1)、将父节点的索引值更新到本page的最后一位；
                 * (2)、将兄弟节点的第一个节点索引替换父节点的索引
                 * (3)、将兄弟节点的第一个节点清空
                 */
                if (isLeafPage) {
                    //(1)、将兄弟第一个节点插入到本page最后一位；
                    CCIndexSize_T indexSize = rPage->pageNodeList[sIdx].indexSize;
                    CCPageSize_T indexOffset = rPage->pageNodeList[sIdx].indexOffset;
                    CCIndexValue_T indexValue = rPage->pageNodeList[sIdx].value;
                    uint8_t *ptr = firstBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, pIdx, nIdx, 0, ptr, indexSize, indexValue);
                    //(2)、将父节点的索引值更新为借过来兄弟节点的索引;
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    //(3)、将从兄弟节点借过来的节点清空
                    deleteIndexFromPage(ctx, rPage, 0, 0);
                }
                else {
                    //(1)、将父节点的索引值更新到本page的最后一位；
                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    
                    CCIndexSize_T indexSize = parentPage->pageNodeList[parentNodeIdx].indexSize;
                    CCPageSize_T indexOffset = parentPage->pageNodeList[parentNodeIdx].indexOffset;
                    CCIndexValue_T indexValue = page->firstChild;
                    
                    uint8_t *ptr = parentSubBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, pIdx, nIdx, 0, ptr, indexSize, indexValue);
                    //(2)、将兄弟节点的第一个节点索引替换父节点的索引
                    indexSize = rPage->pageNodeList[0].indexSize;
                    indexOffset = rPage->pageNodeList[0].indexOffset;
                    ptr = firstBuffer->bytes() + indexOffset;
                    updateIndexFromPage(ctx, parentPage, parentSubPageIdx, parentNodeIdx, ptr, indexSize, 0, false);
                    //(3)、将兄弟节点的第一个节点清空
                    deleteIndexFromPage(ctx, rPage, 0, 0);
                    
                    CCPAGE_FRE_BUFFER(parentSubBuffer, parentSubBufferType);
                }
                
                //如果第一个page没有节点后,将第一个page回收，也可以不回收，不进行回收，因为有可能前面page的brother指向此firstPage
                ++firstSub->sIdx;
//                if (firstSub->sIdx > firstSub->eIdx) {
//                    CCSubPage *first = &rPage->subPageList[1];
//                    CCPAGE_DEC_BUFFER(first->offset, firstSubBuffer, fistType);
//                    CCPAGE_FRE_BUFFER(firstSubBuffer, fistType);
//                }
            }
            else {
                //6.2 进行合并
                /*
                 *6.2.1如果是叶子节点，
                 * (1)、将当前节点和兄弟节点合并为一个page
                 * (2)、将父节点删除
                 *6.2.2如果是索引节点
                 * (1)、将父节点下移
                 * (2)、将当前节点、父节点和兄弟节点合并为一个page
                 * (3)、将父节点删除
                 */
                
                CCPageOffset_T lastSubOff = page->subPageList[page->pageCnt - 1].offset;
                
                if (isLeafPage) {
                    // (1)、将当前节点和兄弟节点合并为一个page
                    CCPageOffset_T off = page->subPageList[0].offset;
                    CCPAGE_DEC_BUFFER(off, bufferTmp, bufferTmpType);
                    bufferTmp->seekTo(CCPageHeaderOffBrother);
                    bufferTmp->writeLittleEndian64(rPage->brother);

                    if (off == lastSubOff) {
                        bufferTmp->seekTo(CCPageHeaderOffNext);
                        bufferTmp->writeLittleEndian64(rPage->pageOffset);
                        CCPAGE_FRE_BUFFER(bufferTmp, bufferTmpType);
                    }
                    else {
                        CCPAGE_FRE_BUFFER(bufferTmp, bufferTmpType);
                        CCPAGE_DEC_BUFFER(lastSubOff, lastSubBuffer, lastSubBufferType);
                        lastSubBuffer->seekTo(CCPageHeaderOffNext);
                        lastSubBuffer->writeLittleEndian64(rPage->pageOffset);
                        CCPAGE_FRE_BUFFER(lastSubBuffer, lastSubBufferType);
                    }

                    //(2)、将父节点删除
                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    CCIndexSize_T parentIndexSize = parentPage->pageNodeList[parentNodeIdx].indexSize;
                    CCPageSize_T parentIndexOffset = parentPage->pageNodeList[parentNodeIdx].indexOffset;
                    
                    CCPAGE_DEC_BUFFER(parentSubOff, parentSubBuffer, parentSubBufferType);
                    
                    CCIndex_T *parentIndex = parentSubBuffer->bytes() + parentIndexOffset;
                    deleteIndex(ctx, parent, parentIndex, parentIndexSize, NO);
                    
                    CCPAGE_FRE_BUFFER(parentSubBuffer, parentSubBufferType);
                }
                else {
                    CCPageOffset_T parentSubOff = parentPage->subPageList[parentSubPageIdx].offset;
                    CCPAGE_DEC_BUFFER(parentSubOff, parentBuffer, parentBufferType);
                    // (1)、将父节点下移
                    CCIndexSize_T indexSize = parentPage->pageNodeList[parentNodeIdx].indexSize;
                    CCPageSize_T indexOffset = parentPage->pageNodeList[parentNodeIdx].indexOffset;
                    CCIndexValue_T indexValue = page->firstChild;
                    uint8_t *ptr = parentBuffer->bytes() + indexOffset;
                    insertIndexIntoNotFullPage(ctx, page, page->pageCnt - 1, page->nodeCnt, 0, ptr, indexSize, indexValue);
                    CCPAGE_FRE_BUFFER(parentBuffer, parentBufferType);

                    //(2)、将当前节点、父节点和兄弟节点合并为一个page
                    CCPAGE_DEC_BUFFER(lastSubOff, lastSubBuffer, lastSubBufferType);
                    lastSubBuffer->seekTo(CCPageHeaderOffNext);
                    lastSubBuffer->writeLittleEndian64(rPage->pageOffset);
                    CCPAGE_FRE_BUFFER(lastSubBuffer, lastSubBufferType);
                    
                    //(3)、将父节点删除
                    deleteIndex(ctx, parent, ptr, indexSize, NO);
                }
                
                if (parentPage->nodeCnt == 0) {
                    addFreePageOffset(ctx, parentPage->pageOffset);
                    page->pageType = (CCPageType_E)(CCPageTypeLeaf | CCPageTypeRoot);

                    CCPAGE_DEC_BUFFER(page->pageOffset, tmpBuf, tmpBufType);
                    tmpBuf->seekTo(CCPageHeaderOffPType);
                    tmpBuf->writeByte(page->pageType);
                    CCPAGE_FRE_BUFFER(tmpBuf, tmpBufType);
                }
            }
            CCPAGE_FRE_BUFFER(firstBuffer, firstBufferType);
            freePage(ctx, rPage);
        }
        freePage(ctx, parentPage);
    }
    return 0;
}

CCBPTreeIndex::CCBPTreeIndex(const string &indexFile)
{
    _ptrRBTreeIndexContext = CCBPTreeIndexContextCreate(nullptr, indexFile, 1024, 0);
//    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S *)calloc(1, sizeof(CCBPTreeIndexContext_S));
//    _ptrRBTreeIndexContext = ctx;
//    CCFileMap *fileMap = new CCFileMap(indexFile);
//    ctx->fileMap = fileMap;
//    fileMap->open(CC_F_RDWR);
//
//    int64_t fileSize = ctx->fileMap->fileSize();
//
//    CCBuffer *header = fileMap->createMapBuffer(0, _CCBPTreeIndexHeaderLen_s, CC_F_RDWR);
//    if (header == nullptr) {
//        return;
//    }
//    ctx->headBuffer = header;
//
//    if (fileSize > 0) {
//        ctx->version = header->readLittleEndian16();
//        ctx->pageNodeCnt = header->readLittleEndian16();
//        uint8_t flag = header->readByte();
//        ctx->flag = flag;
////        ctx->level = (flag >> 5) + 1;
//        ctx->pageSize = CCPAGE_SIZE_FROM_FLAG(flag);
//        ctx->rootOffset = header->readLittleEndian64();
//        ctx->contentSize = header->readLittleEndian64();
//        ctx->freePageOffset = header->readLittleEndian64();
//    }
//    else {
//        CCPageSize_T pageSize = (CCPageSize_T)header->bufferSize();
//        uint8_t flag = TYPEUINT_BITS_N(pageSize);
//        ctx->version = 1.0;
//        ctx->pageNodeCnt = 1024;
//        ctx->flag = flag;
////        ctx->level = (flag >> 5) + 1;
//        ctx->pageSize = CCPAGE_SIZE_FROM_FLAG(flag);
//        ctx->rootOffset = header->bufferSize();
//        ctx->contentSize = header->bufferSize();
//        ctx->freePageOffset = 0;
//
//        header->seekTo(CCHeaderOffVersion);
//        header->writeLittleEndian16(ctx->version);
//        header->seekTo(CCHeaderOffPageNodeCnt);
//        header->writeLittleEndian16(ctx->pageNodeCnt);
//        header->seekTo(CCHeaderOffFlag);
//        header->writeByte(ctx->flag);
//        header->seekTo(CCHeaderOffRootOffset);
//        header->writeLittleEndian64(ctx->rootOffset);
//        header->seekTo(CCHeaderOffContentSize);
//        header->writeLittleEndian64(ctx->contentSize);
//        header->seekTo(CCHeaderOffFreePageOffset);
//        header->writeLittleEndian64(ctx->freePageOffset);
//    }
//    readRootPage(ctx);
}

CCBPTreeIndex::CCBPTreeIndex(const string &indexFile, CCIndexSize_T indexLen)
{
    CCNodeCount_T nodeCnt = 1024;
    CCPageSize_T pageSize = nodeCnt * indexLen;
    pageSize = MAX(pageSize, defaultPageSize_g);
    _ptrRBTreeIndexContext = CCBPTreeIndexContextCreate(nullptr, indexFile, nodeCnt, pageSize);
}

CCBPTreeIndex::CCBPTreeIndex(const string &indexFile, CCUInt16_t pageNodeCount, CCIndexSize_T indexLen)
{
    CCPageSize_T pageSize = pageNodeCount * indexLen;
    pageSize = MAX(pageSize, defaultPageSize_g);
    _ptrRBTreeIndexContext = CCBPTreeIndexContextCreate(nullptr, indexFile, pageNodeCount, pageSize);
}

CCBPTreeIndex::~CCBPTreeIndex()
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    if (ctx && ctx->fileMap) {
        ctx->fileMap->close();
        delete ctx->fileMap;
        ctx->fileMap = nullptr;
    }
    if (ctx && ctx->root != ctx->current) {
        freePage(ctx, ctx->root);
        ctx->root = nullptr;
    }
    if (ctx && ctx->current) {
        freePage(ctx, ctx->current);
        ctx->current = nullptr;
    }
//    if (ctx && ctx->rootBuffer) {
//        delete ctx->rootBuffer;
//        ctx->rootBuffer = nullptr;
//    }
    if (ctx) {
        free(ctx);
        _ptrRBTreeIndexContext = nullptr;
    }
}

int CCBPTreeIndex::selectIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T *indexValue)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    struct CCPageFind find = lookupPage(ctx, nullptr, ctx->rootOffset, 0, index, indexLen, true);
    if (indexValue) {
        *indexValue = find.value;
    }
    return find.fcd == CCFindCodeExists ? 0 : 1;
}

int CCBPTreeIndex::insertIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    return ::insertIndex(ctx, ctx->rootOffset, 0, index, indexLen, indexValue, true);
}

int CCBPTreeIndex::deleteIndex(CCIndex_T *index, CCIndexSize_T indexLen)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    ::deleteIndex(ctx, ctx->rootOffset, index, indexLen, true);
    return 0;
}

int CCBPTreeIndex::updateIndex(CCIndex_T *index, CCIndexSize_T indexLen, CCIndexValue_T indexValue)
{
    struct CCBPTreeIndexContext *ctx = (CCBPTreeIndexContext_S*)_ptrRBTreeIndexContext;
    ::updateIndex(ctx, ctx->rootOffset, index, indexLen, indexValue, true);
    return 0;
}



