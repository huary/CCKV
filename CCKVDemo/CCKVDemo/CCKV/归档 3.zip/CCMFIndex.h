//
//  CCMFIndex.h
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCMMFileContext.h"

typedef enum CCMFIndexOffset {
    CCMFIndexOffsetItemCnt      = CCMMFHeaderOffsetKeyHash + CC_SHA256_DIGEST_LENGTH,
    CCMFIndexOffsetValidItemCnt = CCMFIndexOffsetItemCnt + 8,
}CCMFIndexOffset_E;

typedef struct CCMFIndexItem {
    uint64_t index;
    uint32_t hash;
    uint32_t extra;
}CCMFIndexItem_S;

typedef struct CCMFIndexHeader {
    uint64_t itemCnt;
    uint64_t validItemCnt;
}CCMFIndexHeader_S;


class CCMFIndexObject {
private:
    uint64_t itemIndex;
    friend class CCMFIndex;
public:
    CCMFIndexItem item;
};


/**********************************************************************
 *Memory File Index
 *不加密
 ***********************************************************************/
class CCMFIndex : public CCMMFileContext, CCMFIndexObject {
//    dispatch_semaphore_t _lock;
    
    uint64_t _cursor;
    
    struct CCMFIndexHeader _indexHeader;
        
    void _readIndexHeader();
    
    CCMFIndexObject *_readNextIndex();
public:
    
    CCMFIndex(const string &filePath);
    
    virtual ~CCMFIndex();
    
    CCMMFError_E open();
    
    //需要释放返回的CCMFIndexObject
    CCMFIndexObject *nextIndex();
    
    bool appendIndexItem(CCMFIndexObject *index);
    
    bool deleteIndexItem(CCMFIndexObject *index);
    
    bool updateIndexItem(CCMFIndexObject *index);
    
    bool close();
};
