//
//  CCMFIndex.m
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import "CCMFIndex.h"

void CCMFIndex::_readIndexHeader()
{
    _sharedPtrHeaderData->seekTo(CCMFIndexOffsetItemCnt);
    _indexHeader.itemCnt = _sharedPtrHeaderData->readLittleEndian64();
    _indexHeader.validItemCnt = _sharedPtrHeaderData->readLittleEndian64();
}

CCMFIndexObject *CCMFIndex::_readNextIndex()
{
    
    CCMFIndexObject *index = new CCMFIndexObject();
    
    int32_t step = sizeof(CCMFIndexItem_S);
    while (_cursor < _sharedPtrPlainContentData->dataSize()) {
        index->itemIndex = _cursor;
        
        _sharedPtrPlainContentData->seekTo(_cursor);
        
        index->item.index = _sharedPtrPlainContentData->readLittleEndian64();
        if (index->item.index > 0) {
            index->item.hash = _sharedPtrPlainContentData->readLittleEndian32();
            index->item.extra = _sharedPtrPlainContentData->readLittleEndian32();
            break;
        }
        else {
            _cursor += step;
        }
    }
    
    if (index->item.index == 0) {
        return NULL;
    }
    _cursor += step;
    _sharedPtrPlainContentData->seekTo(_cursor);
    
    return index;
}

CCMFIndex::CCMFIndex(const string &filePath) : CCMMFileContext(filePath)
{
//    _lock = dispatch_semaphore_create(1);
    _cursor = CCMMFContentHeaderSize_g;
}

CCMFIndex::~CCMFIndex()
{

}

CCMMFError_E CCMFIndex::open()
{
    CCMMFError_E error = CCMMFileContext::open(nullptr);
    _readIndexHeader();
    return error;
}

CCMFIndexObject* CCMFIndex::nextIndex()
{
    return _readNextIndex();
}

bool CCMFIndex::appendIndexItem(CCMFIndexObject *index)
{
    if (index == NULL) {
        return false;
    }
    
    int32_t size = sizeof(CCMFIndexItem_S);
    CCMutableCodeData codeData(size);
    codeData.writeLittleEndian64(index->item.index);
    codeData.writeLittleEndian32(index->item.hash);
    codeData.writeLittleEndian32(index->item.extra);
    index->itemIndex = _sharedPtrContentData->currentSeek();
    CCMMFileContext::appendWriteData(&codeData, NULL);
    return true;
}

bool CCMFIndex::deleteIndexItem(CCMFIndexObject *index)
{
    if (index == NULL) {
        return false;
    }
    
    int64_t cursor = index->itemIndex;
    _sharedPtrPlainContentData->seekTo(cursor);
    
    CCMutableCodeData codeData(8);
    codeData.writeLittleEndian64(0);
    CCMMFileContext::appendWriteData(&codeData, NULL);
    
    return true;
}

bool CCMFIndex::updateIndexItem(CCMFIndexObject *index)
{
    if (index == NULL) {
        return false;
    }
    int64_t cursor = index->itemIndex;
    _sharedPtrPlainContentData->seekTo(cursor);
    
    int32_t size = sizeof(CCMFIndexItem_S);

    CCMutableCodeData codeData(size);
    
    codeData.writeLittleEndian64(index->item.index);
    codeData.writeLittleEndian32(index->item.hash);
    codeData.writeLittleEndian32(index->item.extra);
    
    CCMMFileContext::appendWriteData(&codeData, NULL);
    return true;
}

bool CCMFIndex::close()
{
    CCMMFileContext::close();
    return true;
}
