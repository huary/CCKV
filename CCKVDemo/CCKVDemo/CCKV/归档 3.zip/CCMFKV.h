//
//  CCMFKV.h
//  CCKVDemo
//
//  Created by yuan on 2019/10/19.
//  Copyright © 2019 yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCMMFileContext.h"

class CCMFKV : public CCMMFileContext {
public:
    
};
